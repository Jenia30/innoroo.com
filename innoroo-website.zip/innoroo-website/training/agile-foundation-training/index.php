<!DOCTYPE html>
<html class="full" lang="en">

<head>
    <!--Updated On 17-07-2018 MI
meta tag updated-->
    <title>INNOVATION ROOTS | Training | Agile Foundation Training | 2018 </title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!--Description Tag Meta Start-->
    <!--Updated for 17.07.18 version MI-->
    <meta name="description" content="Register for a 2 days Agile Foundation training and learn valuable tips and techniques to implement AFT in the software development teams and smoothen the testing process. Register today!">
    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">

    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../../inc/assets/css/main.css" rel="stylesheet" />
    <script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
    <link rel="shortcut icon" type=image/x-icon href=../../inc/assets/img/favicon.ico>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>
    <script type=text/javascript>
        document.oncontextmenu = new Function("return false");
        document.onselectstart = new Function("return false");
        if (window.sidebar) {
            document.onmousedown = new Function("return false");
            document.onclick = new Function("return true");
            document.oncut = new Function("return false");
            document.oncopy = new Function("return false");
            document.onpaste = new Function("return false")
        };

    </script>
    <!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
    <style>
        .nav-tabs>li {
            float: left;
            margin-bottom: -5px;
            border-bottom: transparent
        }
        .agilef_color{background-color: #f73939}
    </style>
</head>

<body>
    <?php include('../../includes/header.php'); ?>
    <section class="section_margin_gen_training section_training_banner agilef_color">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-9 col-xs-12">
                    <h2 class="sectionTitle class_font">Agile Foundation Training</h2>
                    <h3 class="sectionSubtitle class_font">[ Lay the Foundation for Launching Agile Teams ]</h3>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Overview
                    </h2>
                    <p class="para_training">
                        The two-day Agile Foundation training introduces participants to the essential values, principles and practices of Agile software development. Participants will get the understanding of Agile and gain essential skills to start adapting Agile method in their respective projects. They will also get foundation laid for launching Agile teams.Participants will develop clarity about delivering in incremental and iterative ways towards valuable outcomes, faster to the market, with better quality through continuous improvement. This course helps participants to gain experience on the foundation concepts of Agile through hands-on learning activities.


                    </p>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training section_training_requirements">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-hourglass-half fa_training fa-2x" aria-hidden=true></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Duration</h5>
                        <h6 class="training_requirement_title1">2 Days (16 Hours)</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-clock-o fa_training fa-2x" aria-hidden=true></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Timing</h5>
                        <h6 class="training_requirement_title1">9:00 AM to 6:00 PM Each Day (1 Hour break in between)</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-user-o fa_training fa-2x" aria-hidden=true></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Trainer</h5>
                        <h6 class="training_requirement_title1">Agile Expert</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-group fa_training fa-2x" aria-hidden=true></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Batch Size</h5>
                        <h6 class="training_requirement_title1">25 participants</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-id-badge fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Participants Profile</h5>
                        <h6 class="training_requirement_title1">Beginner & Intermediate</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-check-circle-o fa_training fa-2x" aria-hidden=true></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Prerequisite</h5>
                        <h6 class="training_requirement_title1">None</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-language fa_training fa-2x" aria-hidden=true></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Course Delivery Language</h5>
                        <h6 class="training_requirement_title1">English</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <span class="glyphicon glyphicon-blackboard fa_training fa-2x"></span>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Approach of Delivery</h5>
                        <h6 class="training_requirement_title1">Mix of theory & workshop sessions – predominantly hands-on</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-graduation-cap fa_training fa-2x" aria-hidden=true></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Certification Details</h5>
                        <h6 class="training_requirement_title1">Attendees receive the ‘Certificate of Participation’ for workshop signed by the Trainer.
                        </h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-university fa_training fa-2x" aria-hidden=true></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Accreditation Institute</h5>
                        <h6 class="training_requirement_title1">INNOVATION ROOTS Academy</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-handshake-o fa_training fa-2x" aria-hidden=true></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Commercials & Logistics</h5>
                        <h6 class="training_requirement_title1">Please contact us for quotation</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                       <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                            <img src="../../inc/assets/img/training/brochure.png" alt="Brochure">
                        </div>
                        <div class="col-sm-11 col-xs-11">
                            <h5 class="training_requirement_title1">Training Brochure</h5>
                            <h6 class="training_requirement_title1">For complete details 
                            <a data-toggle="modal" data-target="#myModal" style="margin-top: 16px;font-size: 14px; cursor:pointer"> Download Brochure </a>
                            </h6>
                        </div>
                   </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Agenda
                    </h2>
                    <ul>
                        <li class="training_li_list">Origin & History of Agile Software Development and various Agile Methods like XP, Scrum, Kanban and others
                        </li>
                        <li class="training_li_list">Benefits of Agile Software Development and why Agile?
                        </li>
                        <li class="training_li_list">Agile Manifesto; Four Values and Twelve Principles </li>
                        <li class="training_li_list">Difference between Agile and Classic Software Development Mindset and Culture</li>
                        <li class="training_li_list">Agile Software Development Simulation Game with PDCA Cycle </li>
                        <li class="training_li_list">Agile Practices - Adaptive Planning, Backlog Prioritisation, Collaborative Development, Iterative & Incremental Delivery, Early Feedback, Limiting Batch Size, Visual Boards, Definition of Done and Timeboxing
                        </li>
                        <li class="training_li_list">Agile Teams - Cross-Functional Feature Teams, Self-Managing & Self-Organising teams</li>
                        <li class="training_li_list">Agile Planning Timebox - Vision, Roadmap, Release, Iteration and Daily</li>
                        <li class="training_li_list">Agile Iteration - Planning, Execution, Review and Retrospectives</li>
                        <li class="training_li_list">Agile Requirement - Feature, Epic, Theme and User Story </li>
                        <li class="training_li_list">Agile Estimation - Planning Poker relative Size Estimation
                        </li>
                        <li class="training_li_list">Agile Metrics - Cycle Time, Velocity and others </li>
                        <li class="training_li_list">Hands-on Agile Iteration Simulation</li>
                        <li class="training_li_list">Agile Case Study - A Leading Networking Firm’s Agile Transformation </li>
                        <li class="training_li_list">Agile Transformation Starting Roadmap</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Learning Objective
                    </h2>
                    <ul>
                        <li class="training_li_list">Participants will learn basics of Agile towards benefitting respective Projects</li>
                        <li class="training_li_list">Understand Agile essential concepts to be aware of its applicability</li>
                        <li class="training_li_list">Participants learn to practice essential Agile methods and apply them at work</li>
                        <li class="training_li_list">Participants learn to advocate the Agile transformation so that they can help other colleagues </li>
                        <li class="training_li_list">Understand on how to begin with Agile projects to innovate and achieve game-changing outcomes.</li>

                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Audience
                    </h2>
                    <ul>
                        <li class="training_li_list">Organizational Leaders, Managers and Team Members wanting to understand the value of Agile and work in an Agile environment
                        </li>
                        <li class="training_li_list">Project Managers, Scrum Masters, Product Owners, Senior-level Managers and Leaders </li>
                        <li class="training_li_list">Any one new to Agile</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Course Deliverables
                    </h2>
                    <ul>
                        <li class="training_li_list">Attendees will get a participant handbook of training material with in person two-day training full of learning and activities.
                        </li>

                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section class="contact_us_bg_page no-margin-bottom margin_top_contact">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="contact_training_title1">Want to Participate?</h2>
                    <h4 class="contact_training_title2">You can reach us to book a in-house class</h4>
                    <a href="../../about/contact/" class="training_contact">Contact</a>
                </div>
            </div>
        </div>
    </section>
    <?php include('../../includes/footer.php'); ?>
    
    
    
     <!--Start modal for Brochure-->    
<form method="post" action="" style="margin:0px;">

            <div class="container">
                
                    <div class="modal fade" id="myModal" role="dialog">
                    <div class="modal-dialog">

                        <!-- Modal content-->
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">DOWNLOAD AGILE FOUNDATION TRAINING BROCHURE</h4>
                            </div>
                            
                            <div class="col-sm-9 col-xs-12 modal-body">
                                <div class="col-sm-12 col-xs-12 form_space">
                                    <div class="col-sm-12 col-xs-12">
                                        <label><strong>Name<sup>*</sup></strong></label>
                                    </div>
                                    <div class="col-sm-12 col-xs-12">
                                        <span class="col-sm-6 col-xs-12 padding0">
                            <input name="fname" id="fname" value="" type="text"  required><br /> 
                            <label>Fist Name</label>
                                </span>
                                        <span class="col-sm-6 col-xs-12 padding0">
                            <input name="lname" id="lname" value="" type="text" required><br />
                            <label>Last Name</label>
                                </span>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-xs-12 form_space">
                                    <div class="col-sm-12 col-xs-12">
                                        <label><strong>EMAIL<sup>*</sup></strong></label>
                                    </div>
                                    <div class="col-sm-12 col-xs-12">
                                        <span class="col-sm-12 col-xs-12 padding0">
                            <input name="email" id="email1" value="" type="email"  required><br />
                                            <label>Email Address</label>
                                </span>

                                    </div>
                                </div>
                                <div class="col-sm-12 col-xs-12 form_space">
                                    <div class="col-sm-12 col-xs-12">
                                        <label><strong>Phone Number<sup>*</sup></strong></label>
                                    </div>
                                    <div class="col-sm-12 col-xs-12">
                                        <span class="col-sm-6 col-xs-12 padding0">
                            <input name="area" id="area1" value="" pattern="^([0-9]{2})$" type="text" required><br /> 
                            <label>Area Code</label>
                                </span>

                                        <span class="col-sm-6 col-xs-12 padding0">
                            <input name="phone" id="contact" value="" type="text" pattern="^[(]{0,1}[0-9]{3}[)]{0,1}[-\s\.]{0,1}[0-9]{3}[-\s\.]{0,1}[0-9]{4}$" required><br />
                            <label>Phone Number</label>
                                </span>
                                    </div>
                                </div>
                            </div>
                                
                            <div class="modal-footer clear knowMore">
                               <div class="g-recaptcha" data-sitekey="6LdLUWUUAAAAAP2nRx0zyS-deo5dYMdLJ9vOuk2U"></div>
                               <input id="submit" onclick="myFunction()" name="submit" type="submit" value="submit" class="btn">
                            </div>
                            
                            
                            
                        </div>

                    </div>
                </div>
               
            </div> 
</form>
       <!--Start modal for Brochure-->
    
    
    
    <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
        window.purechatApi = {
            l: [],
            t: [],
            on: function() {
                this.l.push(arguments);
            }
        };
        (function() {
            var done = false;
            var script = document.createElement('script');
            script.async = true;
            script.type = 'text/javascript';
            script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
            document.getElementsByTagName('HEAD').item(0).appendChild(script);
            script.onreadystatechange = script.onload = function(e) {
                if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
                    var w = new PCWidget({
                        c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
                        f: true
                    });
                    done = true;
                }
            };
        })();

    </script>
    <!--end pure chat-->

</body>

</html>



<?php
   if(isset($_POST['submit'])) {
   $email_to = "contact@innovationroots.com";
    $email_subject = "Your email subject line";
 
    function died($error) {
        // your error code can go here
        echo "We are very sorry, but there were error(s) found with the form you submitted. ";
        echo "These errors appear below.<br /><br />";
        echo $error."<br /><br />";
        echo "Please go back and fix these errors.<br /><br />";
        die();
    }
 
 
    // validation expected data exists
    if(!isset($_POST['fname']) ||
        !isset($_POST['lname']) ||
        !isset($_POST['email']) ||
        !isset($_POST['phone']) ||
        !isset($_POST['area'])) {
        died('We are sorry, but there appears to be a problem with the form you submitted.');       
    }
 
     
 
    $first_name = $_POST['fname']; // required
    $last_name = $_POST['lname']; // required
    $email_from = $_POST['email']; // required
    $telephone = $_POST['phone']; // not required
    $area_code = $_POST['area']; // required
 
    $error_message = "";
    $email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';
 
    $email_message = "Registration Details of User for Agile Foundation Training .\n\n";
 
     
    function clean_string($string) {
      $bad = array("content-type","bcc:","to:","cc:","href");
      return str_replace($bad,"",$string);
    }
 
     
 
    $email_message .= "First Name: ".clean_string($first_name)."\n";
    $email_message .= "Last Name: ".clean_string($last_name)."\n";
    $email_message .= "Email: ".clean_string($email_from)."\n";
    $email_message .= "Telephone: ".clean_string($telephone)."\n";
    $email_message .= "Area Code: ".clean_string($area_code)."\n";
 
// create email headers
$headers = 'From: '.$email_from."\r\n".
'Reply-To: '.$email_from."\r\n" .
'X-Mailer: PHP/' . phpversion();
@mail($email_to, $email_subject, $email_message, $headers);
   
   
   
   ?>
   <script type="text/javascript">
   
     
        var fname = document.getElementById("fname").value;
        
      window.location ="http://www.innoroo.com/brochure/agile-foundation-training.pdf";
 
  
      </script>
   <?php
   
   }
   ?>