<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Title Tag Meta Start -->
    <!-- Updated on 23.07.18 version JB -->
    <title>INNOVATION ROOTS | Events | Kanban Coaching Professional Masterclass</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Description Tag Meta Start -->
    <!-- Updated on 23.07.18 version JB-->
    <meta name="description" content="Kanban Coaching Professional Masterclass is a five days professional training specially intended to teach you how to use Kanban coaching tools such as STATIK, the Kanban Lens, the Kanban Litmus Test, the Agile Decision Filter, and Lean Decision Filter.">
    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
    <META NAME="ROBOTS" CONTENT="INDEX, FOLLOW"></META>

    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
    <link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../../inc/assets/css/main.css" rel="stylesheet" />
    <script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>
    <script type=text/javascript>
        document.oncontextmenu = new Function("return false");
        document.onselectstart = new Function("return false");
        if (window.sidebar) {
            document.onmousedown = new Function("return false");
            document.onclick = new Function("return true");
            document.oncut = new Function("return false");
            document.oncopy = new Function("return false");
            document.onpaste = new Function("return false")
        };

    </script>
    <!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
</head>

<body>
    <?php include('../../includes/header.php'); ?>
    <section class="section_margin_gen_training section_training_banner kanban_class">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-9 col-xs-12">
                    <h2 class="sectionTitle class_font">Kanban Coaching Professional Masterclass</h2>
                    <h3 class="sectionSubtitle class_font">[ Become a Kanban Coach to lead successful Kanban Implementation ]</h3>
                </div>
                
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Overview
                    </h2>
                    <p class="para_training">
                        Kanban Coaching Professional is a combination of both Kanban Maturity Model and Kanban Leadership Coaching workshops. Kanban Maturity Model provides a road map to guide an organisation’s journey towards business agility and fit for purpose. This model is based on observed Kanban patterns and practices that helps coaches and managers to assess where they are in their organizational maturity and helps to improve handling of process and policies, fulfillment of desired outcomes for customer satisfaction, level of business agility and improvement practices in the first three days of workshop.
                    </p>
                    <p class="para_training">
                        In the next two days, focus will be on the leadership and cultural tools where  participants will learn to understand “First who, then why”, how to recognize identity and how its many facets are sources of resistance to change, also focuses on the psychology, social psychology and sociology of the workplace. You’ll learn how to see social behaviour, culture and leadership differently and how to use a collection of analysis tools to provide advice and guidance to leaders wishing to catalyse change as part of an evolutionary change and improvement initiative.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training section_training_requirements">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-hourglass-half fa_training fa-2x fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Duration</h5>
                        <h6 class="training_requirement_title1">5 Days (40 Hours)</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-clock-o fa_training fa-2x fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Timing</h5>
                        <h6 class="training_requirement_title1">9 AM to 6 PM Each day</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-user-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Presenter</h5>
                        <h6 class="training_requirement_title1">Accredited Kanban Trainer (AKT)</h6>
                    </div>
                </div>
                
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-group fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Batch Size</h5>
                        <h6 class="training_requirement_title1">Max 20-25 Participants</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-id-badge fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Participants Profile</h5>
                        <h6 class="training_requirement_title1">Experts</h6>
                    </div>
                </div>
                
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-tasks fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Prerequisite</h5>
                        <h6 class="training_requirement_title1">Prior knowledge or experience of Kanban. Recommend to read "Fit-For-Purpose" book by David J. Anderson & "Kanban Maturity Model" by David J. Anderson and Teodora Bozheva.</h6>
                    </div>
                </div>
                
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-language fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Course Delivery Language</h5>
                        <h6 class="training_requirement_title1">English</h6>
                    </div>
                </div>
                
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <span class="glyphicon glyphicon-blackboard fa_training fa-2x"></span>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Approach of Delivery</h5>
                        <h6 class="training_requirement_title1">Mix of theory & workshop sessions (Classroom Training)</h6>
                    </div>
                </div>
                
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-graduation-cap fa_training fa-2x " aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Certification Details</h5>
                        <h6 class="training_requirement_title1">Participants are required to complete 5 days of training together with practical field experience, essay, and a panel interview</h6>
                    </div>
                </div>
                
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-university fa_training fa-2x " aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Accreditation Institute</h5>
                        <h6 class="training_requirement_title1">Lean Kanban University</h6>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class=section_margin_gen_training>
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0 section-ul-bottom">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Agenda
                    </h2>
                    <h3 class="heading_trainings_sub" style=font-size:24px>
                        Kanban Maturity Model
                    </h3>
                    <ul>
                        <li class="training_li_list">Understand KMM levels</li>
                        <li class="training_li_list">KMM Architecture</li>
                        <li class="training_li_list">KMM and other models and methods- Lean/TPS, CMMI, Real World Risk Model</li>
                        <li class="training_li_list">Evolve organizational culture with KMM</li>
                        <li class="training_li_list">Fit-for-purpose organization</li>
                        <li class="training_li_list">Develope Organizational Agility</li>
                        <li class="training_li_list">Risk Management practices</li>
                        <li class="training_li_list">Develop an antifragile organization</li>
                        <li class="training_li_list">How to use KMM as a Kanban coach, Change agent, or Project Manager</li>
                    </ul>
                    <h3 class="heading_trainings_sub" style=font-size:24px>
                        Kanban Leadership Maturity
                    </h3>
                    <ul>
                        <li class="training_li_list">Understand Identity</li>
                        <li class="training_li_list">First Who, Then Why</li>
                        <li class="training_li_list">V'ger Concept</li>
                        <li class="training_li_list">Values and History</li>
                        <li class="training_li_list">Neuropsychology of change – how change is perceived in the brain</li>
                        <li class="training_li_list">Punctuated-Equilibrium and evolutionary change</li>
                        <ul class="no_margin">
                            <li class="training_li_list">Evolutionary relics</li>
                        </ul>
                        <li class="training_li_list">Understand corporate/organizational identities</li>
                        <li class="training_li_list">Zombies – the living dead (soulless businesses that lost their identities)</li>
                        <li class="training_li_list">Blizzard Sport case study</li>
                        <li class="training_li_list">Nemetschek Scia case study</li>
                        <li class="training_li_list">Sociology</li>
                        <ul class="no_margin">
                            <li class="training_li_list"><b>Social capital</b> – how to analyse it, how to recognize its effects on behaviour</li>
                            <li class="training_li_list"><b>Social cohesion</b> – how to analyse it, how to recognize its effects on behaviour</li>
                            <li class="training_li_list"><b>Social innovation</b> – how to assess liberal versus conservative behaviour, and how it affects behaviour</li>
                        </ul>
                        <li class="training_li_list">Visotech case study</li>
                        <li class="training_li_list">Tupalo case study</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Learning Objective
                    </h2>
                    <ul>
                        <li class="training_li_list">Learn how to use KMM together with other models and methods</li>
                        <li class="training_li_list">Learn how the KMM model helps Kanban Coaches, and Agile coaches to deeply delve into the Kanban practices</li>
                        <li class="training_li_list">Find out how Kanban not only relieves teams from overburdening task, but provides a support to improve and become more successful in market</li>
                        <li class="training_li_list">Understand the benefits and value of KMM for business</li>
                        <li class="training_li_list">Identify the reasons- 'why the team still lacks collaboration, and the stability required for on-time delivery?'</li>
                        <li class="training_li_list">Learn to keep focused on customers expectations and values</li>
                        <li class="training_li_list">Learn how to use the model to provide a roadmap for improvement and ideas for what to do next to catalyse the next level of evolutionary change and business improvement</li>
                        <li class="training_li_list">Learn the definition of "fit-for-purpose" and understand what it takes to evolve an organization that is fit-for-purpose</li>
                        <li class="training_li_list">Learn to analyse and model the social capital, social cohesion, and social innovation of the tribes in your workplace</li>
                        <li class="training_li_list">Explore tools, actions, behaviours and values to modify the sociology and culture in the workplace</li>
                        <li class="training_li_list">Learn leadership actions that encourage or discourage innovation and experimentation</li>
                        <li class="training_li_list">Learn how and when to use Kanban coaching tools such as STATIK, the Kanban Lens, the Kanban Litmus Test, the Agile Decision Filter, and the Lean Decision Filter</li>
                        <li class="training_li_list">Learn to construct your own leadership tools from first principles in order to drive cultural change</li>
                        <li class="training_li_list">Understand how to assess leadership maturity.</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Audience
                    </h2>
                    <ul>
                        <li class="training_li_list">Business Leaders, Team Leads, Executives</li>
                        <li class="training_li_list">Project Managers</li>
                        <li class="training_li_list">Service Managers</li>
                        <li class="training_li_list">Agile Coaches</li>
                        <li class="training_li_list">Kanban Practitioners</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Course Deliverables
                    </h2>
                    <ul>
                        <li class="training_li_list">Attendees will receive a certificate of completion from Lean Kanban University in digital format</li>
                        <li class="training_li_list">In person 5-day training full of learning and fun.</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section class="no-margin-bottom contact_us_bg_page margin_top_contact">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="contact_training_title1">Want to Participate?</h2>
                    <h4 class="contact_training_title2">You can reach us to book in-house class</h4>
                    <a href="../../about/contact/" class="training_contact">Contact</a>
                </div>
            </div>
        </div>
    </section>
    <?php include('../../includes/footer.php'); ?>

    <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
        window.purechatApi = {
            l: [],
            t: [],
            on: function() {
                this.l.push(arguments);
            }
        };
        (function() {
            var done = false;
            var script = document.createElement('script');
            script.async = true;
            script.type = 'text/javascript';
            script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
            document.getElementsByTagName('HEAD').item(0).appendChild(script);
            script.onreadystatechange = script.onload = function(e) {
                if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
                    var w = new PCWidget({
                        c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
                        f: true
                    });
                    done = true;
                }
            };
        })();

    </script>
    <!--end pure chat-->


</body>

</html>
