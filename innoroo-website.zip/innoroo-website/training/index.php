<!DOCTYPE html>
<html lang="en">

<head>

    <!--Updated On 07-07-2018 MI
meta tag updated-->
    <title>INNOVATION ROOTS | Training | We provide best Agile Consulting Services </title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--Description Tag Meta Start-->
    <!--Updated for 07.07.18 version MI-->
    <meta name="description" content="We are the Industry-best Agile Consultancy provider of  Management Coaching, Training, and Consultancy. Our motto is to help clients move towards 'Organisational Agility' with Agile, Process Improvement, Application Lifecycle.">
    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
    <META NAME="ROBOTS" CONTENT="INDEX, FOLLOW"></META>

    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->

    <link href="../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
    <link href="../inc/assets/css/bootstrap.min.css" rel="stylesheet" />
    <link type="text/css" rel="stylesheet" href="../inc/assets/css/newsletter_form.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../inc/assets/css/main.css" rel="stylesheet" />
    <script src="../inc/assets/js/modernizr.custom.83079.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="../inc/assets/img/favicon.ico">
    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>


    <!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->

    <script type="text/javascript">
        document.oncontextmenu = new Function("return false");
        document.onselectstart = new Function("return false");
        if (window.sidebar) {
            document.onmousedown = new Function("return false");
            document.onclick = new Function("return true");
            document.oncut = new Function("return false");
            document.oncopy = new Function("return false");
            document.onpaste = new Function("return false");
        }

    </script>

</head>

<body>

    <?php include('../includes/header.php'); ?>
    <section class="page-cover-half">
        <div class="container">
            <div class="page-cover-bg training-bg opacity-2"></div>
            <div class="page_center_caption">
                <h1 class="main_title">Training</h1>
                <div class="text_center_hr"></div>
                <h2 class="heading_sub_page">What we are good at</h2>
            </div>
        </div>
    </section>
    
    <section>
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12 padding0">
                    
                     <!--start Agile Basic Training Workshop start-->
                    <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                        <div class="training_listcard">
                            <div class="row">
                                <div class="col-md-5 col-xs-5 img_hover_training">
                                    <div class="hovereffect_training">
                                        <img class="img-responsive img_training" src="../inc/assets/img/agile-transformation/agile-overview.png" alt="Agile Basic" width="100%">
                                        <div class="overlay">
                                            <a href="agile-basics-training/">
                                                <p class="info">View</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xs-7">
                                    <p class="training_topic">
                                        Agile Basic Training
                                    </p>
                                    <p class="training_topic_sub">
                                        Half day course
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--end Agile Basic Training Workshop start -->
                    <!--Start Agile Essentials Training-->
                    <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                        <div class="training_listcard">
                            <div class="row">
                                <div class="col-md-5 col-xs-5 img_hover_training">
                                    <div class="hovereffect_training">
                                        <img class="img-responsive img_training" src="../inc/assets/img/agile-transformation/agile-essentials.png" alt="LKU" width="100%">
                                        <div class="overlay">
                                            <a href="agile-essentials-training/">
                                                <p class="info">View</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xs-7">
                                    <p class="training_topic">
                                        Agile Essentials Training

                                    </p>
                                    <p class="training_topic_sub">
                                        1 day course
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Agile Essentials Training-->
                    <!--start Agile Foundation Training Workshop start-->
                    <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                        <div class="training_listcard">
                            <div class="row">
                                <div class="col-md-5 col-xs-5 img_hover_training">
                                    <div class="hovereffect_training">
                                        <img class="img-responsive img_training" src="../inc/assets/img/agile-transformation/agile-foundation.png" alt="Agile Foundation" width="100%">
                                        <div class="overlay">
                                            <a href="agile-foundation-training/">
                                                <p class="info">View</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xs-7">
                                    <p class="training_topic">
                                        Agile Foundation Training
                                    </p>
                                    <p class="training_topic_sub">
                                        2 day course
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--end Agile Foundation Training Workshop start -->
                   
                </div>
            </div>
        </div>
    </section>
    
    <section class="blockLightGray">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12 padding0">

                    <!--start Design Thinking in Action Workshop start-->
                    <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                        <div class="training_listcard">
                            <div class="row">
                                <div class="col-md-5 col-xs-5 img_hover_training">
                                    <div class="hovereffect_training">
                                        <img class="img-responsive img_training" src="../inc/assets/img/training/dt.png" alt="Design Thinking in Action" width="100%">
                                        <div class="overlay">
                                            <a href="design-thinking-in-action/">
                                                <p class="info">View</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xs-7">
                                    <p class="training_topic">
                                        Design Thinking in Action Workshop
                                    </p>
                                    <p class="training_topic_sub">
                                        2 day course
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--end Design Thinking in Action Workshop start -->

                    <!--Start DevOps Foundation Course-->
                    <div class="col-md-4 col-sm-6 col-xs-12  margin_training_list_media">
                        <div class="training_listcard">
                            <div class="row">
                                <div class="col-md-5 col-xs-5 img_hover_training">
                                    <div class="hovereffect_training">
                                        <img class="img-responsive img_training" src="../inc/assets/img/training/devops.png" alt="DevOps" width="100%">
                                        <div class="overlay">
                                            <a href="devops-foundation-course/">
                                                <p class="info">View</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xs-7">
                                    <p class="training_topic">
                                        DevOps Foundation Course
                                    </p>
                                    <p class="training_topic_sub">
                                        2 day course
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Start DevOps Foundation Course-->

                    <!--Start Behavior Driven Development(BDD)-->
                    <div class="col-md-4 col-sm-6 col-xs-12  margin_training_list_media">
                        <div class="training_listcard">
                            <div class="row">
                                <div class="col-md-5 col-xs-5 img_hover_training">
                                    <div class="hovereffect_training">
                                        <img class="img-responsive img_training" src="../inc/assets/img/training/bdd.png" alt="SPC" width="100%">
                                        <div class="overlay">

                                            <a href="behavior-driven-development/">
                                                <p class="info">View</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xs-7">
                                    <p class="training_topic">
                                        Behavior Driven Development(BDD)
                                    </p>
                                    <p class="training_topic_sub">
                                        2 day course
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Start Behavior Driven Development(BDD)-->

                    <!--Start Product Management in Action Workshop-->
                    <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                        <div class="training_listcard">
                            <div class="row">
                                <div class="col-md-5 col-xs-5 img_hover_training">
                                    <div class="hovereffect_training">
                                        <img class="img-responsive img_training" src="../inc/assets/img/training/product_management.png" alt="Product Management in Action Workshop" width="100%">
                                        <div class="overlay">
                                            <a href="product-management-in-action-workshop/">
                                                <p class="info">View</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xs-7">
                                    <p class="training_topic">
                                        Product Management in Action Workshop
                                    </p>
                                    <p class="training_topic_sub">
                                        5 day course
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Product Management in Action Workshop-->

                    <!--Start Test Driven Development Workshop-->
                    <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                        <div class="training_listcard">
                            <div class="row">
                                <div class="col-md-5 col-xs-5 img_hover_training">
                                    <div class="hovereffect_training">
                                        <img class="img-responsive img_training" src="../inc/assets/img/training/tdd.png" alt="Test Driven Development Workshop" width="100%">
                                        <div class="overlay">
                                            <a href="test-driven-development-workshop/">
                                                <p class="info">View</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xs-7">
                                    <p class="training_topic">
                                        Test Driven Development Workshop
                                    </p>
                                    <p class="training_topic_sub">
                                        2 day course
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Test Driven Development Workshop-->
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12 padding0">

                    <!--Start SAFe 4.0 Scrum Master-->
                    <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                        <div class="training_listcard">
                            <div class="row">
                                <div class="col-md-5 col-xs-5 img_hover_training">
                                    <div class="hovereffect_training">
                                        <img class="img-responsive img_training" src="../inc/assets/img/training/safe_ssm.png" alt="SSM" width="100%">
                                        <div class="overlay">
                                            <a href="safe-scrum-master/">
                                                <p class="info">View</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xs-7">
                                    <p class="training_topic">
                                        SAFe&reg; 4.0 Scrum Master
                                    </p>
                                    <p class="training_topic_sub">
                                        2 day course
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End SAFe 4.0 Scrum Master-->

                    <!--Start SAFe 4.5 for Teams-->
                    <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                        <div class="training_listcard">
                            <div class="row">
                                <div class="col-md-5 col-xs-5 img_hover_training">
                                    <div class="hovereffect_training">
                                        <img class="img-responsive img_training" src="../inc/assets/img/training/safe_team.png" alt="SAFe for Teams" width="100%">
                                        <div class="overlay">
                                            <a href="safe-for-teams/">
                                                <p class="info">View</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xs-7">
                                    <p class="training_topic">
                                        SAFe&reg; 4.5 for Teams
                                    </p>
                                    <p class="training_topic_sub">
                                        2 day course
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End SAFe 4.5 for Teams-->

                    <!--Start SAFe 4.0 Advanced Scrum Master-->
                    <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                        <div class="training_listcard">
                            <div class="row">
                                <div class="col-md-5 col-xs-5 img_hover_training">
                                    <div class="hovereffect_training">
                                        <img class="img-responsive img_training" src="../inc/assets/img/training/safe_sasm.png" alt="SASM" width="100%">
                                        <div class="overlay">
                                            <a href="safe-advanced-scrum-master/">
                                                <p class="info">View</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xs-7">
                                    <p class="training_topic">
                                        SAFe&reg; 4.0 Advanced Scrum Master
                                    </p>
                                    <p class="training_topic_sub">
                                        2 day course
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End SAFe 4.0 Advanced Scrum Master-->

                    <!--Start Leading SAFe 4.5-->
                    <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                        <div class="training_listcard">
                            <div class="row">
                                <div class="col-md-5 col-xs-5 img_hover_training">
                                    <div class="hovereffect_training">
                                        <img class="img-responsive img_training" src="../inc/assets/img/training/safe_leadingsafe.png" alt="Leading Safe" width="100%">
                                        <div class="overlay">
                                            <a href="leading-safe/">
                                                <p class="info">View</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xs-7">
                                    <p class="training_topic">
                                        Leading SAFe&reg; 4.5
                                    </p>
                                    <p class="training_topic_sub">
                                        2 day course
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Leading SAFe 4.5-->

                    <!--Start SAFe 4.5 Product Owner/Product Manager-->
                    <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                        <div class="training_listcard">
                            <div class="row">
                                <div class="col-md-5 col-xs-5 img_hover_training">
                                    <div class="hovereffect_training">
                                        <img class="img-responsive img_training" src="../inc/assets/img/training/safe_pmpo.png" alt="PMPO" width="100%">
                                        <div class="overlay">
                                            <a href="safe-product-owner-product-manager/">
                                                <p class="info">View</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xs-7">
                                    <p class=training_topic>
                                        SAFe&reg; 4.5 Product Owner/Product Manager
                                    </p>
                                    <p class="training_topic_sub">
                                        2 day course
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End SAFe 4.5 Product Owner/Product Manager-->
                </div>
            </div>
        </div>
    </section>

    <section class="blockLightGray">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12 padding0">

                    <!--Start Team Kanban Practitioner-->
                    <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                        <div class="training_listcard">
                            <div class="row">
                                <div class="col-md-5 col-xs-5 img_hover_training">
                                    <div class="hovereffect_training">
                                        <img class="img-responsive img_training" src="../inc/assets/img/training/lku.png" alt="LKU" width="100%">
                                        <div class="overlay">
                                            <a href="team-kanban-practitioner/">
                                                <p class="info">View</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xs-7">
                                    <p class=training_topic>
                                        Team Kanban Practitioner
                                    </p>
                                    <p class="training_topic_sub">
                                        1 day course
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Team Kanban Practitioner-->

                    <!--Start Kanban System Design-->
                    <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                        <div class="training_listcard">
                            <div class="row">
                                <div class="col-md-5 col-xs-5 img_hover_training">
                                    <div class="hovereffect_training">
                                        <img class="img-responsive img_training" src="../inc/assets/img/training/lku.png" alt="LKU" width="100%">
                                        <div class="overlay">
                                            <a href="kanban-system-design/">
                                                <p class="info">View</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xs-7">
                                    <p class="training_topic">
                                        Kanban System Design
                                    </p>
                                    <p class="training_topic_sub">
                                        2 day course
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Kanban System Design-->
                </div>
            </div>
        </div>
    </section>
    

    <?php include('../includes/footer.php'); ?>

    <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
        window.purechatApi = {
            l: [],
            t: [],
            on: function() {
                this.l.push(arguments);
            }
        };
        (function() {
            var done = false;
            var script = document.createElement('script');
            script.async = true;
            script.type = 'text/javascript';
            script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
            document.getElementsByTagName('HEAD').item(0).appendChild(script);
            script.onreadystatechange = script.onload = function(e) {
                if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
                    var w = new PCWidget({
                        c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
                        f: true
                    });
                    done = true;
                }
            };
        })();

    </script>
    <!--end pure chat-->

</body>

</html>
