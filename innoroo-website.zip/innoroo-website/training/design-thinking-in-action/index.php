<!DOCTYPE html>
<html class=full lang=en>

<head>
    
    <!--Updated On 07-07-2018 MI
meta tag updated-->
    <title>INNOVATION ROOTS | Training | Design Thinking In Action | Design thinking certification workshop | 2018 </title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
     <!--Description Tag Meta Start-->
    <!--Updated for 07.07.18 version MI-->
    <meta name="description" content="This Design Thinking training is fully designed with the hands-on training modules for participants to learn Design Thinking and develop the skills needed in a “learning-by-doing” environment.">
    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">

    <!-- OPEN GRAPH META TAG STARTS -->	
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->

    <link href=https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css rel=stylesheet>
    <link type=text/css rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
    <link href="../../inc/assets/css/normalize-3.0.2.css rel=stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../../inc/assets/css/main.css" rel="stylesheet" />
    <script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>
    <script type=text/javascript>
        document.oncontextmenu = new Function("return false");
        document.onselectstart = new Function("return false");
        if (window.sidebar) {
            document.onmousedown = new Function("return false");
            document.onclick = new Function("return true");
            document.oncut = new Function("return false");
            document.oncopy = new Function("return false");
            document.onpaste = new Function("return false")
        };

    </script>
    <!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
    <style>
        .nav-tabs>li {
            float: left;
            margin-bottom: -5px;
            border-bottom: transparent
        }

    </style>
</head>

<body>
    <?php include('../../includes/header.php'); ?>
    <section class="section_margin_gen_training class_font section_training_banner dt_class">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-9 col-xs-12">
                    <h2 class="sectionTitle class_font">Design Thinking in Action</h2>
                    <h3 class="sectionSubtitle class_font">[Creative and Analytical approach to meet user needs ]</h3>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Overview
                    </h2>
                    <p class="para_training">
                        Design Thinking as a process, consists of both the aspects of Creativity and Problem Solving. It is identified as the primary engine behind great leadership qualities of both Analysis and Action towards identifying user needs.
                    </p>
                    <p class="para_training">
                        This two-day course focuses on Design Thinking principles and practices that aid and encourage the participants in innovative thinking and approaches. The participants will strengthen their Design Thinking and Design Management skills via hands-on creative workshops, interactive exercises, case studies, and lecture. They will also learn how to use and apply these capabilities and leverage them for both innovation and improved results.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training section_training_requirements">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-hourglass-half fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Duration</h5>
                        <h6 class="training_requirement_title1">2 Days (16 Hours)</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-clock-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Timing</h5>
                        <h6 class="training_requirement_title1">9 AM to 6 PM ( 1 Hour break in between)</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-user-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Trainer</h5>
                        <h6 class="training_requirement_title1">Design Thinking Expert</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-group fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Batch Size</h5>
                        <h6 class="training_requirement_title1">Maximum of 30</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-id-badge fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Participants Profile</h5>
                        <h6 class="training_requirement_title1">Beginner or Intermediate</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-check-circle-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Prerequisite</h5>
                        <h6 class="training_requirement_title1">None</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-language fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Course Delivery Language</h5>
                        <h6 class="training_requirement_title1">English</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="glyphicon glyphicon-blackboard fa_training fa-2x"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Approach of Delivery</h5>
                        <h6 class="training_requirement_title1">Mix of theory & workshop sessions (Classroom Training)</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-graduation-cap fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Certification Details</h5>
                        <h6 class="training_requirement_title1">Attendies receive the Certificate of Completion for ‘Design Thinking in Action’ workshop</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-university fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Accreditation Institute</h5>
                        <h6 class="training_requirement_title1">INNOVATION ROOTS Academy</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-handshake-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Commercials & Logistics</h5>
                        <h6 class="training_requirement_title1">Contact us for Quotations</h6>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Agenda
                    </h2>
                    <p class="para_training margin_btm_para_training">
                        The Design Thinking approach is taught to participants via an interactive-exercises driven workshop. In the long run, they learn the ability to navigate through, and successfully solve organizational problems. It consists of
                    </p>
                    <ul>
                        <li class="training_li_list">Overview to Design Thinking Framework</li>
                        <li class="training_li_list">Design Thinking Flow</li>
                        <li class="training_li_list"> The 6 Thinking Phases:
                            <ol>
                                <li class="training_li_list"><strong>Empathize:&nbsp;</strong>Conducting research about users needs, tastes and feelings</li>
                                <li class="training_li_list"><strong>Define:&nbsp;</strong>Combine the research and identify the problems</li>
                                <li class="training_li_list"><strong>Ideate:&nbsp;</strong>Brainstorm ideas, predictions and possibilities in regards to the process</li>
                                <li class="training_li_list"><strong>Prototype:&nbsp;</strong>Build a tactile, visible representation of your subset of ideas</li>
                                <li class="training_li_list"><strong>Test:&nbsp;</strong>Process to obtain feedback from users</li>
                                <li class="training_li_list"><strong>Implement:&nbsp;</strong>Put the vision into application and effect</li>
                            </ol>
                        </li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Learning Objective
                    </h2>
                    <ul>
                        <li class="training_li_list">Understand the fundamentals of Design Thinking</li>
                        <li class="training_li_list">Apply Design Thinking to deliver innovative products and services</li>
                        <li class="training_li_list">Create impact of business for a sustained period of time</li>
                        <li class="training_li_list">Build a culture of design and ideation within organization</li>
                        <li class="training_li_list">Gain the ability of Problem Solving and</li>
                        <li class="training_li_list">Implement Design Thinking to various contexts</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Audience
                    </h2>
                    <ul>
                        <li class="training_li_list">Product Owners and Product Managers</li>
                        <li class="training_li_list">Architects, Designers, Coders and Testers</li>
                        <li class="training_li_list">Marketing Managers, Strategy Innovators and Change Agents</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Course Deliverables
                    </h2>
                    <ul>
                        <li class="training_li_list">Attendees will receive the Certificate of Completion on ‘Design Thinking in Action’</li>
                        <li class="training_li_list">In person 2-day training full of learning and fun.</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section class="contact_us_bg_page no-margin-bottom margin_top_contact">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="contact_training_title1">Want to Participate?</h2>
                    <h4 class="contact_training_title2">You can reach us to book in-house class</h4>
                    <a href="../../about/contact/" class="training_contact">Contact</a>
                </div>
            </div>
        </div>
    </section>
    <?php include('../../includes/footer.php'); ?>

    <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
        window.purechatApi = {
            l: [],
            t: [],
            on: function() {
                this.l.push(arguments);
            }
        };
        (function() {
            var done = false;
            var script = document.createElement('script');
            script.async = true;
            script.type = 'text/javascript';
            script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
            document.getElementsByTagName('HEAD').item(0).appendChild(script);
            script.onreadystatechange = script.onload = function(e) {
                if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
                    var w = new PCWidget({
                        c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
                        f: true
                    });
                    done = true;
                }
            };
        })();

    </script>
    <!--end pure chat-->

</body>

</html>
