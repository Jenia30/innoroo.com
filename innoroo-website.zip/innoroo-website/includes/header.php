
<?php 

    echo '
    <header>
            <div class="container-fluid main">

                <nav class="navbar navbar-default navbar-fixed-top" style="position: fixed ;">
                    <div class="container">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle toggle_edit_mobile" data-toggle="collapse" data-target="#ir_nav">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span> 
                            </button>
                            <div class="navbar-brand">
                                <a href="http://innovationroots.com/">
                                <!--<img src="inc/assets/img/testimonial/Ir-logo-06" alt="Logo">-->
                                    <h2 class="logo-text">Innovation Roots</h2>
                                </a>
                            </div>
                            
                        </div>
                        <div class="collapse navbar-collapse" id="ir_nav">
                            <ul class="nav navbar-nav ul_list_header">
							
							<li ><a href="http://www.innovationroots.com/training/" class="li_list_header">Training</a></li>
                                <!--<li ><a href="" class="li_list_header">consulting</a></li>-->
                                 <li ><a href="http://www.innovationroots.com/events/" class="li_list_header">events</a></li>

                                <li ><a href="http://www.innovationroots.com/about/contact/" class="li_list_header">Contact</a></li>

                                <li ><a href="http://www.innovationroots.com/blog/" class="li_list_header">Blog</a></li>
                            </ul>
                        </div>
                    </div>
                </nav>

                <!--<section id="bg_home" class="bg_home_page">
                    <div class="inner">
                        <div class="content_bg_home">
                            <h1 class="feature_text1">We are Skill Development, Enhancement and Transfer Journeyman</h1>
                           
                        </div>
                    </div>
                </section>-->
                
                
            </div>
        </header>
       	
   ';

    ?>
