<!DOCTYPE html>
<html lang=en>

<head>

	<!-- Title Tag Meta Start -->
	<!-- Updated on 27.12.17 PP -->

	<title>Find out the upcoming Trainings and Certifications on Leading SAFe | Kanban |Scrum Master | Agile</title>

	<!-- Title Tag Meta End -->

	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- OPEN GRAPH META TAG STARTS -->
	<meta property='og:title' content='INNOVATION ROOTS' />
	<meta property="og:image" content="http://innovationroots.com/test.innoroo.com/inc/assets/img/agile-transformation/agile-transformation.png" />
	<meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
	<meta property="og:url" content="www.innoroo.com" />
	<!-- OPEN GRAPH META TAG ENDS -->
	<!-- Description Tag Meta Start -->
	<!-- Updated on 27.12.17 PP -->

	<meta name="description" content="Find our best-in-class trainings on SAFe, Kanban, and Scrum! Get registered with us to pass immediately">
	<!-- Description Tag Meta End -->

	<meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
	<META NAME="ROBOTS" CONTENT="INDEX, FOLLOW"></META>
	<link href="../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
	<link href="../inc/assets/css/bootstrap.min.css" rel="stylesheet" />
	<link type="text/css" rel="stylesheet" href="../inc/assets/css/newsletter_form.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="../inc/assets/css/main.css" rel="stylesheet" />
	<link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
	<script src="../inc/assets/js/modernizr.custom.83079.js"></script>
	<script type='text/javascript' data-cfasync='false'>
		window.purechatApi = {
			l: [],
			t: [],
			on: function() {
				this.l.push(arguments);
			}
		};
		(function() {
			var done = false;
			var script = document.createElement('script');
			script.async = true;
			script.type = 'text/javascript';
			script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
			document.getElementsByTagName('HEAD').item(0).appendChild(script);
			script.onreadystatechange = script.onload = function(e) {
				if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
					var w = new PCWidget({
						c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
						f: true
					});
					done = true;
				}
			};
		})();

	</script>


	<link rel="shortcut icon" type="image/x-icon" href="../inc/assets/img/favicon.ico">
	<script>
		(function(d, e, j, h, f, c, b) {
			d.GoogleAnalyticsObject = f;
			d[f] = d[f] || function() {
				(d[f].q = d[f].q || []).push(arguments)
			}, d[f].l = 1 * new Date();
			c = e.createElement(j), b = e.getElementsByTagName(j)[0];
			c.async = 1;
			c.src = h;
			b.parentNode.insertBefore(c, b)
		})(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
		ga("create", "UA-100332682-2", "auto");
		ga("send", "pageview");

	</script>
	
	<script type="text/javascript">
		document.oncontextmenu = new Function("return false");
		document.onselectstart = new Function("return false");
		if (window.sidebar) {
			document.onmousedown = new Function("return false");
			document.onclick = new Function("return true");

			document.oncut = new Function("return false");

			document.oncopy = new Function("return false");


			document.onpaste = new Function("return false");
		}

	</script>
	<!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
</head>

<body >
	<?php include('../includes/header.php');?>
	<section class="page-cover-half gmap">
		<div class="container">
			<div class="page_center_caption">
				<h1 class="main_title">Contact Us</h1>
				<div class="career_center_hr"></div>
				<h2 class="heading_sub_page">
					let&acute;s Get Together
				</h2>
			</div>
		</div>
	</section>
	<section class="contact-info-section">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="icon-text-block">
						<div class="icon-block-right">
							<i class="md-place"></i>
							<div class="block-text">
								<h6><strong>Registered Office</strong></h6>
								<p class="footer_font_add">No 43, Van Marg,<br /> Banapura, Madhya Pradesh,<br> India - 461221</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="icon-text-block">
						<div class="icon-block-right">
							<i class="md-place"></i>
							<div class="block-text">
								<h6><strong>Bengaluru Office</strong></h6>
								<p class="footer_font_add">
									No.94, 17/1, 2nd Floor, <br /> Ambalipura, Bellandur Gate, <br /> Sarjapura Main Road, <br />Bengaluru, Karnataka,<br> India - 560102
								</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="icon-text-block">
						<div class="icon-block-right">
							<i class="md-call"></i>
							<div class="block-text">
								<h6><strong>Phone</strong></h6>
								<p class="footer_font_add">
									+(91) - 8041489100
									<br /> +(91) - 99999 85600
								</p>
							</div>
						</div>
					</div>
					<div class="icon-text-block">
						<div class="icon-block-right">
							<i class="md-email"></i>
							<div class="block-text">
								<h6><strong>E-Mail</strong></h6>
								<p class="footer_font_add">community@innovationroots.com</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="icon-text-block">
						<div class="icon-block-right">
							<i class="md-schedule"></i>
							<div class="block-text">
								<h6><strong>Business Hours</strong></h6>
								<p class="footer_font_add">
									9:00 - 18:00 IST
									<br /> Monday - Friday
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="section">
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<h3>Send us a message</h3>
					<p>
						...for anything which has <span class=playfair>Agile</span> in it
					</p>
				</div>
				<div class="col-md-8">
					<div id="formSuccess" class="alert alert-success" role="alert" style="display:none">
						<p>
							<strong>Thank You!</strong>&nbsp;Your message has been sent successfully.<br/>
							<small>Someone from our team will respond to your query within 24 hrs.</small>
						</p>
					</div>
					<div class="contact-form-wrapper">
						<div class="contact-form">
							<form id="ir_contactForm" role="form" method="post" action="../inc/assets/mail/contact_mail.php">
								<div class="form-group">
									<label for="inputName" class="sr-only">Your Name</label>
									<input type="text" class="form-control" id="inputName" name="name" placeholder="Name*" required>
								</div>
								<div class="form-group">
									<label for="inputEmail" class="sr-only">Your Email</label>
									<input type="email" class="form-control" id="inputEmail" name="email" placeholder="Email*" required>
								</div>
								<div class="form-group">
									<label for="inputSubject" class="sr-only">Subject Line</label>
									<input type="text" class="form-control" id="inputSubject" name="subject" placeholder="Subject*" required>
								</div>
								<div class="form-group">
									<label for="inputMessage" class="sr-only">Your Message</label>
									<textarea class="form-control" name="message" rows="5" id="inputMessage" placeholder="Message*"></textarea>
								</div>
								<div class="checkbox">
									<label>
<input type="checkbox" id="inputCheckbox" name="newsletter"> Sign Me up for Newsletter!
</label>
									<p class="help-block text-small">No Spam mails, We promise!</p>
								</div>
								<br />
								<button type="submit" name="formSubmit" class="btn ibtn-primary btn-block">Submit</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php include('../includes/footer.php');?>
	<script type="text/javascript" src="../inc/assets/js/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="../inc/assets/js/bootstrap.min.js"></script>
	<script>
		var map;
		var mapMarkers = [{
			lat: 12.923212,
			lng: 77.674187,
			icon: "../inc/assets/img/misc/pin.png",
			title: "Office",
			infoWindow: {
				content: "<strong>Bangalore Office</strong><br>Bangalore, 560 103"
			}
		}];
		var initLatitude = 12.927343;
		var initLongitude = 77.674448;
		var styles = [{
			stylers: [{
				saturation: -100
			}, {
				lightness: -2
			}, {
				gamma: 1.25
			}]
		}];
		map = new GMaps({
			div: "#gmap",
			draggable: false,
			panControl: false,
			zoomControl: false,
			mapTypeControl: false,
			scaleControl: false,
			streetViewControl: false,
			overviewMapControl: false,
			scrollwheel: false,
			lat: initLatitude,
			lng: initLongitude,
			zoom: 16
		});
		map.addMarkers(mapMarkers);

	</script>
</body>

</html>
