<!--Updated On 28-03-2018GA
	Meta tag updated
-->

<!DOCTYPE html>
<html lang="en">

<head>
	<title>INNOVATION ROOTS | Events | Teams Agility Assessment Workshop Prashant MJ Pune 07 January 2017</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="In this session, we will come to know about what is Agility, characteristics of a high performing team, what is a team's perspective on agility and how to evaluate real-time scenarios to assess team's Agility.">
	<meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
    
    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->
    
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
	<link rel=stylesheet href=../../inc/assets/css/newsletter_form.css>
	<link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
	<link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
	<link rel="stylesheet" href="../../inc/assets/css/material-design-iconic-font.min.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="../../inc/assets/css/main.css" rel="stylesheet" />
	<script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
	<link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
	<script>
		(function(d, e, j, h, f, c, b) {
			d.GoogleAnalyticsObject = f;
			d[f] = d[f] || function() {
				(d[f].q = d[f].q || []).push(arguments)
			}, d[f].l = 1 * new Date();
			c = e.createElement(j), b = e.getElementsByTagName(j)[0];
			c.async = 1;
			c.src = h;
			b.parentNode.insertBefore(c, b)
		})(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
		ga("create", "UA-100332682-2", "auto");
		ga("send", "pageview");

	</script>
	
	<script type=text/javascript>
		document.oncontextmenu = new Function("return false");
		document.onselectstart = new Function("return false");
		if (window.sidebar) {
			document.onmousedown = new Function("return false");
			document.onclick = new Function("return true");
			document.oncut = new Function("return false");
			document.oncopy = new Function("return false");
			document.onpaste = new Function("return false")
		};
	</script>
</head>

<body>
	<?php include('../../includes/header.php'); ?>
    
    <!--start Register section-->
	<section class="section_margin_gen_training section_training_banner kanban_class">
		<div class="container">
			<div class="col-sm-12 col-xs-12 padding0">
				<div class="col-sm-9 col-xs-12">
					<h2 class="sectionTitle class_font">Team's Agility Assessment Workshop</h2>
					<h3 class="sectionSubtitle class_font">[ Prashant MJ | Consultant - <strong class="innoroo">INNOVATION ROOTS</strong> ]</h3>
				</div>
				<div class="col-sm-3 col-xs-12">
					<div class="reg_section_bg">
						<div class="reg_training_sec">
							<h4 class="reg_section">07 December 2016</h4>
							<h4 class="reg_section">11:00 AM - 12:00 PM IST</h4>
							<h4 class="reg_section"><b>Pune</b></h4>
						</div>
						<a class="training_register">CLOSED</a>
					</div>
				</div>

			</div>
		</div>
	</section>
    <!--end Register Section-->
    
    <!--start Presenter Details section-->
    <section class="agileMetrics1">
		<div class="container">
			<div class="col-sm-12 col-xs-12">
				<h2 class="sectionTitle">
					Presenter
				</h2>
				<div class="col-sm-12 col-xs-12 speakerDetailSection padd0">
					<div class="col-sm-2 col-sm-offset-0 col-xs-8 col-xs-offset-2 webinar-detail-img">
						<img src="../../inc/assets/img/events/prashant-mj-detail.png" width="100%" alt="Prashant MJ">
                        <p>( Consultant - <strong class="innoroo">INNOVATION ROOTS</strong> )</p>
					</div>
					<div class="col-sm-10 col-xs-12 speakerDetailPara">
						<p class="para_training">Prashant J. Mavinkare (Consultant, <strong class="innoroo">INNOVATION ROOTS</strong>) is an Enterprise Agile Transformation Consultant providing training, coaching and mentoring services to companies to gain business outcomes like quality, value, and continuous flow.</p>
                        <p class="para_training">He works with leaders who recognize the value in creating engaged, autonomous and creative teams. He offers coaching support to help them develop a culture of reflection and empowerment that helps create productive, mindful and motivated teams.</p>
                        <p class="para_training">He is actively contributing to Agile Network India community as an organizer of global conference Agile Gurugram (2016, 2017, 2018), Lean Kanban India (2015, 2016, 2017).</p>
				    </div>
				</div>
			</div>
		</div>
	</section>
    <!--end Presenter Details section-->
    
    <!--start Session Overview section-->
	<section class="agileMetrics grey-section">
		<div class="container">
			<div class="col-sm-12 col-xs-12">
				<h2 class="sectionTitle">Session Overview</h2>
				<p class="para_training">It's a great pleasure to announce Prashant MJ ( Consultant at <strong class="innoroo">INNOVATION ROOTS</strong>) as the presenter for the Scaling Agile India Day (SAI) meetup, held at Persistent Systems, Pune on January 7th 2017.</p>
                <p class="para_training">Organizations are moving towards agility, as Teams, and not as Individuals. The challenge is, agility is not suitable for every  organization but for tangible results we need to measure agility. The Big question is, 'How are we going to measure agility?'. Your ultimate measure of your project's success depends on how you constantly improve and adapt to new situations in different contexts.</p>
                <p class="para_training">In this one hour session, the presenter Prashant will discuss on what is Agility, characteristics of a high performing team, what is a team's perspective on agility and how to evaluate real-time scenarios to assess team's Agility. This session will give a clarity on Why, How, What, and When the team needs to be assessed.</p>
			</div>
		</div>
	</section>
    <!--end Session Overview section-->
    
    <!--start Learning Objective section-->
	<section class="agileMetrics">
		<div class="container">
			<div class="col-sm-12 col-xs-12">
				<h2 class="sectionTitle">
					Learning Objective
				</h2>
				<ul>
					<li class="training_li_list">Best Practices of agility to business</li>
					<li class="training_li_list">How to find if your organization is suited for agility?</li>
					<li class="training_li_list">How to build organization agility?</li>
                    <li class="training_li_list">How to measure Agility of teams?</li>
					<li class="training_li_list">Q & A session.</li>
				</ul>
			</div>
		</div>
	</section>
     <!--end Learning Objective section-->
    
     <!--start contact section-->	
	<section class="no-margin-bottom contact_us_bg_page margin_top_contact">
		<div class="container">
			<div class="col-sm-12 col-xs-12 padding0">
				<div class="col-sm-12 col-xs-12">
					<h2 class="contact_training_title1">Want to Participate?</h2>
					<h4 class="contact_training_title2">You can reach us to book in-house class</h4>
					<a href="../../about/contact/" class="training_contact">Contact</a>
				</div>
			</div>
		</div>
	</section>
     <!--end contact section-->
	<?php include('../../includes/footer.php'); ?>
    
     <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>
    <!--end pure chat-->
    
</body>

</html>
