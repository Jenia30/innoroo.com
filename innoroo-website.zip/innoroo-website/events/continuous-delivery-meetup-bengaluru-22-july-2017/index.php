<!DOCTYPE html>
<html lang="en">

<head>
    
    <!--Updated On 25-06-2018 MI
	Meta tag updated-->
	<title>INNOVATION ROOTS | Events | Continuous Delivery Meetup Bengaluru 22 July 2017 | Continuous delivery meetup | Bengaluru </title>
	<meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Description Tag Meta-->
    <!-- Updated on 25.06.18 version MI -->
	<meta name="description" content="The Learning objective of Continuous meetup Delivery also covers the concepts of Application Life Cycle Management, Test Data Management, and Application Requirements Management. To learn more, register at www.innovationroots.com!">
    
    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->
    
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
	<link rel=stylesheet href=../../inc/assets/css/newsletter_form.css>
	<link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
	<link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
	<link rel="stylesheet" href="../../inc/assets/css/material-design-iconic-font.min.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="//fonts.googleapis.com/css?family=Roboto+Slab:400,300,700|Open+Sans:700,400,300|Playfair+Display:400,400italic" rel=stylesheet />
	<link href="../../inc/assets/css/main.css" rel="stylesheet" />
	<script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
	<link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
	<script>
		(function(d, e, j, h, f, c, b) {
			d.GoogleAnalyticsObject = f;
			d[f] = d[f] || function() {
				(d[f].q = d[f].q || []).push(arguments)
			}, d[f].l = 1 * new Date();
			c = e.createElement(j), b = e.getElementsByTagName(j)[0];
			c.async = 1;
			c.src = h;
			b.parentNode.insertBefore(c, b)
		})(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
		ga("create", "UA-100332682-2", "auto");
		ga("send", "pageview");

	</script>
	
	<script type=text/javascript>
		document.oncontextmenu = new Function("return false");
		document.onselectstart = new Function("return false");
		if (window.sidebar) {
			document.onmousedown = new Function("return false");
			document.onclick = new Function("return true");
			document.oncut = new Function("return false");
			document.oncopy = new Function("return false");
			document.onpaste = new Function("return false")
		};
	</script>

	<!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
</head>

<body>
	<?php include('../../includes/header.php'); ?>
    
    <!--start Register section-->
	<section class="section_margin_gen_training section_training_banner agileMatrics_class">
		<div class="container">
			<div class="col-sm-12 col-xs-12 padding0">
				<div class="col-sm-9 col-xs-12">
					<h2 class="sectionTitle class_font">Continuous Delivery Meetup</h2>
					<h3 class="sectionSubtitle class_font">[ Accomplish a Quick, Safe and Frequent Software Delivery ]</h3>
				</div>
				<div class="col-sm-3 col-xs-12">
					<div class="reg_section_bg">
						<div class="reg_training_sec">
							<h4 class="reg_section">22 July 2017</h4>
							<h4 class="reg_section">9.00 am - 12:00 pm IST</h4>
							<h4 class="reg_section"><b>Bengaluru</b></h4>
						</div>
						<a class="training_register">CLOSED</a>
					</div>
				</div>

			</div>
		</div>
	</section>
    <!--end Register Section-->
    
   <!--start Session Overview section-->
	<section class="agileMetricsMeetup">
		<div class="container">
			<div class="col-sm-12 col-xs-12">
				<h2 class="sectionTitle">Overview</h2>
                <p class="para_training"><strong class="innoroo">INNOVATION ROOTS</strong> is glad to announce a new Meetup series on Continuous Delivery, which is going to be held on 22nd July 2017 at Hotel IBIS Bengaluru Techpark. The meetup delivers a comprehensive explanation on the core concepts of Continuous Delivery which are listed below. At the end of the meetup, audience will explore the know-how's of the Continuous Delivery approach through an interactive Q & A session.</p>
            </div>
		</div>
	</section>
    <!--end Session Overview section-->
    
    <!--start Learning Objective section-->
	<section class="agileMetrics">
		<div class="container">
			<div class="col-sm-12 col-xs-12">
				<h2 class="sectionTitle">
					Learning Objective
				</h2>
				<ul>
                    <li class="training_li_list">Application Lifecycle Management</li>
					<li class="training_li_list">Test Data Management</li>
                    <li class="training_li_list">Release Automation</li>
                    <li class="training_li_list">Application Requirements Management</li>
					<li class="training_li_list">Service Virtualization</li>
                    <li class="training_li_list">Performance Testing</li>
                    <li class="training_li_list">Q & A session.</li>
				</ul>
			</div>
        </div>
	</section>
     <!--end Learning Objective section-->
    
    <!--start contact section-->	
	<section class="no-margin-bottom contact_us_bg_page">
		<div class="container">
			<div class="col-sm-12 col-xs-12 padding0">
				<div class="col-sm-12 col-xs-12">
					<h2 class="contact_training_title1">Want to Participate?</h2>
					<h4 class="contact_training_title2">You can reach us to book in-house class</h4>
					<a href="../../about/contact/" class="training_contact">Contact</a>
				</div>
			</div>
		</div>
	</section>
    <!--end contact section-->
	<?php include('../../includes/footer.php'); ?>
    
     <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>
    <!--end pure chat-->
    
</body>

</html>
