<!DOCTYPE html>
<html lang="en">

<head>

    <!--Updated On 20-06-2018 MI
	Meta tag updated-->
    <title>INNOVATION ROOTS | Events | Kanban Maturity Model Masterclass David J Anderson And Teodora Bozheva Bengaluru 24-26 September 2018 | 2018's one of the best training on Kanban Maturity Masterclass </title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Description Tag Meta -->
    <!-- Updated on 20.06.18 version MI -->

    <meta name="description" content="You will become adept at learning the Kanban coaching tools such as STATIK, the Kanban Lens, the Kanban Litmus Test, the Agile Decision Filter in order to drive cultural change and Understand how to assess leadership maturity.">
    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
    <META NAME="ROBOTS" CONTENT="INDEX, FOLLOW"></META>

    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
    <link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../../inc/assets/css/main.css" rel="stylesheet" />
    <script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>
    <script type=text/javascript>
        document.oncontextmenu = new Function("return false");
        document.onselectstart = new Function("return false");
        if (window.sidebar) {
            document.onmousedown = new Function("return false");
            document.onclick = new Function("return true");
            document.oncut = new Function("return false");
            document.oncopy = new Function("return false");
            document.onpaste = new Function("return false")
        };

    </script>
</head>

<body>
    <?php include('../../includes/header.php'); ?>
    <section class="section_margin_gen_training section_training_banner kanban_class">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-9 col-xs-12">
                    <h2 class="sectionTitle class_font">Kanban Maturity Model Masterclass </h2>
                    <h3 class="sectionSubtitle class_font">[ Evolving Fit-for-Purpose Organizations ]</h3>
                </div>
                <div class="col-sm-3 col-xs-12">
                    <div class="reg_section_bg">
                        <div class="reg_training_sec">
                            <h4 class="reg_section">24 - 26 September 2018</h4>
                            <h4 class="reg_section">3 Day Workshop</h4>
                            <h4 class="reg_section"><b>Bengaluru</b></h4>
                        </div>
                        <a href="https://www.goeventz.com/event/kanban-maturity-model-kmm-workshop-2018/68985" class="training_register" target="_blank">REGISTER</a>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Overview
                    </h2>
                    <p class="para_training">
                        Kanban Maturity Model (KMM) provides a map to guide an organisational journey towards business agility and fitness for purpose. It also maps the typical Kanban practices as well as cultural value against 6 organizational maturity levels. Kanban Maturity Model is based on observed Kanban patterns and practices that helps coaches and managers to assess where they are in their organizational maturity.
                    </p>
                    <p class="para_training">
                        This model helps to improve handling of process and policies, fulfillment of desired outcomes for customer satisfaction, level of business agility and improvement practices. In addition to identifying the current level, the KMM provides guidance on recommended practices to achieve improvement goals.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training section_training_requirements">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-hourglass-half fa_training fa-2x fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Duration</h5>
                        <h6 class="training_requirement_title1">3 Days (24 Hours)</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-clock-o fa_training fa-2x fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Timing</h5>
                        <h6 class="training_requirement_title1">9 AM to 6 PM Each day</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-user-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Presenter</h5>
                        <h6 class="training_requirement_title1">David J Anderson & Teodora Bozheva</h6>
                    </div>
                </div>
                
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-group fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Batch Size</h5>
                        <h6 class="training_requirement_title1">Max 20-25 Participants</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-id-badge fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Participants Profile</h5>
                        <h6 class="training_requirement_title1">Intermediate or Experts</h6>
                    </div>
                </div>
                
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-tasks fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Prerequisite</h5>
                        <h6 class="training_requirement_title1">Participants are recommended to read the book Kanban Maturity Model by David J. Anderson and Teodora Bozheva, KMP Certification</h6>
                    </div>
                </div>
                
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-language fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Course Delivery Language</h5>
                        <h6 class="training_requirement_title1">English</h6>
                    </div>
                </div>
                
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <span class="glyphicon glyphicon-blackboard fa_training fa-2x"></span>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Approach of Delivery</h5>
                        <h6 class="training_requirement_title1">Mix of theory and workshop session (Classroom Training)</h6>
                    </div>
                </div>
                 
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-graduation-cap fa_training fa-2x " aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Certification Details</h5>
                        <h6 class="training_requirement_title1">This course plus the Kanban Leadership Maturity Masterclass satisfies the educational requirements toward the Kanban Coaching Professional (KCP)</h6>
                    </div>
                </div>
               
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-university fa_training fa-2x " aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Accreditation Institute</h5>
                        <h6 class="training_requirement_title1">Lean Kanban University</h6>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class=section_margin_gen_training>
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0 section-ul-bottom">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Agenda
                    </h2>
                    <ul>
                        <li class="training_li_list">Understand KMM levels</li>
                        <li class="training_li_list">KMM Architecture</li>
                        <li class="training_li_list">KMM and other models and methods - Lean/TPS, CMMI, Real World Risk Model</li>
                        <li class="training_li_list">Evolve organizational culture with KMM</li>
                        <li class="training_li_list">Fit-for-purpose organization</li>
                        <li class="training_li_list">Develop Organizational Agility</li>
                        <li class="training_li_list">Risk Management practices</li>
                        <li class="training_li_list">Develop an antifragile organization</li>
                        <li class="training_li_list">Learn to use KMM as a Kanban coach, Change agent, or Project Manager</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Learning Objective
                    </h2>
                    <ul>
                        <li class="training_li_list">Understand the breadth of general Kanban practices and the depth of specific practices, implement general practices such as Visualize and Limit WIP</li>
                        <li class="training_li_list">Understand the Organizational Maturity Model, mapping of specific Kanban practices and design patterns</li>
                        <li class="training_li_list">Learn the cultural values and leadership styles which enable evolution of organizational agility</li>
                        <li class="training_li_list">Understand the two failure modes of Kanban implementations - aborted start and false summit plateaus</li>
                        <li class="training_li_list">Discover which practices are appropriate at each maturity level to avoid these failure modes</li>
                        <li class="training_li_list">Learn how to use the model to provide a roadmap for improvement and ideas for what to do next to catalyse the next level of evolutionary change and business improvement</li>
                        <li class="training_li_list">Learn the definition of "fit-for-purpose" and understand what it takes to evolve an organization that is fit-for-purpose</li>
                        <li class="training_li_list">Learn how to use KMM together with other models and methods.</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Audience
                    </h2>
                    <ul>
                        <li class="training_li_list">Kanban coaches, Agile Practitioners</li>
                        <li class="training_li_list">Leaders, Business Managers</li>
                        <li class="training_li_list">Project and Service Managers, Team Leads</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Course Deliverables
                    </h2>
                    <ul>
                        <li class="training_li_list">In person 3-day training full of learning and fun</li>
                        <li class="training_li_list">This course satisfies one of the educational requirements toward the Kanban Coaching Professional (KCP).</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section class="no-margin-bottom contact_us_bg_page margin_top_contact">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="contact_training_title1">Want to Participate?</h2>
                    <h4 class="contact_training_title2">You can reach us to book in-house class</h4>
                    <a href="../../about/contact/" class="training_contact">Contact</a>
                </div>
            </div>
        </div>
    </section>
    <?php include('../../includes/footer.php'); ?>

    <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
        window.purechatApi = {
            l: [],
            t: [],
            on: function() {
                this.l.push(arguments);
            }
        };
        (function() {
            var done = false;
            var script = document.createElement('script');
            script.async = true;
            script.type = 'text/javascript';
            script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
            document.getElementsByTagName('HEAD').item(0).appendChild(script);
            script.onreadystatechange = script.onload = function(e) {
                if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
                    var w = new PCWidget({
                        c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
                        f: true
                    });
                    done = true;
                }
            };
        })();

    </script>
    <!--end pure chat-->


</body>

</html>
