<!-- Title Tag Meta Start -->
    <!-- Updated on 07.07.18 version MI -->


<!DOCTYPE html>
<html lang="en">

<head>
	<title>INNOVATION ROOTS | Events | Alternate Path for Transformation Workshop Priyank Pathak Bengaluru 11 December 2015 | LeanKanbanIndia | 2015 | Alternative Path for Transformation | Priyank Pathak </title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="This session will teaches how to resolve the challenges that you faced during Agile transformation and we will give you a solution on How to fix them.">
    
     <!-- Description Tag Meta Start -->
    <!-- Updated on 07.07.18 version MI -->
    
    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->
    
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
	<link rel=stylesheet href=../../inc/assets/css/newsletter_form.css>
	<link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
	<link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
	<link rel="stylesheet" href="../../inc/assets/css/material-design-iconic-font.min.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="../../inc/assets/css/main.css" rel="stylesheet" />
	<script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
	<link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
	<script>
		(function(d, e, j, h, f, c, b) {
			d.GoogleAnalyticsObject = f;
			d[f] = d[f] || function() {
				(d[f].q = d[f].q || []).push(arguments)
			}, d[f].l = 1 * new Date();
			c = e.createElement(j), b = e.getElementsByTagName(j)[0];
			c.async = 1;
			c.src = h;
			b.parentNode.insertBefore(c, b)
		})(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
		ga("create", "UA-100332682-2", "auto");
		ga("send", "pageview");

	</script>
	
	<script type=text/javascript>
		document.oncontextmenu = new Function("return false");
		document.onselectstart = new Function("return false");
		if (window.sidebar) {
			document.onmousedown = new Function("return false");
			document.onclick = new Function("return true");
			document.oncut = new Function("return false");
			document.oncopy = new Function("return false");
			document.onpaste = new Function("return false")
		};
	</script>
</head>

<body>
	<?php include('../../includes/header.php'); ?>
    
    <!--start Register section-->
	<section class="section_margin_gen_training section_training_banner kanban_class">
		<div class="container">
			<div class="col-sm-12 col-xs-12 padding0">
				<div class="col-sm-9 col-xs-12">
					<h2 class="sectionTitle class_font">Alternative Path for Transformation Workshop</h2>
					<h3 class="sectionSubtitle class_font">[ Priyank Pathak | Curator - <strong class="innoroo">INNOVATION ROOTS</strong> ]</h3>
				</div>
				<div class="col-sm-3 col-xs-12">
					<div class="reg_section_bg">
						<div class="reg_training_sec">
							<h4 class="reg_section">11 December 2015</h4>
							<h4 class="reg_section">2:40 PM - 3:40 PM IST</h4>
							<h4 class="reg_section"><b>Bengaluru</b></h4>
						</div>
						<a class="training_register">CLOSED</a>
					</div>
				</div>

			</div>
		</div>
	</section>
    <!--end Register Section-->
    
    <!--start Presenter Details section-->
    <section class="agileMetrics1">
		<div class="container">
			<div class="col-sm-12 col-xs-12">
				<h2 class="sectionTitle">
					Presenter
				</h2>
				<div class="col-sm-12 col-xs-12 speakerDetailSection padd0">
					<div class="col-sm-2 col-sm-offset-0 col-xs-8 col-xs-offset-2 webinar-detail-img">
						<img src="../../inc/assets/img/events/priyank-pathak-detail.png" width="100%">
                        <p>( Curator - <strong class="innoroo">INNOVATION ROOTS</strong> )</p>
					</div>
					<div class="col-sm-10 col-xs-12 speakerDetailPara">
						<p class="para_training">Priyank DK Pathak is an Enterprise Agile Transformation and Continuous Delivery Consultant providing training, mentoring, and coaching services to companies to gain outcomes like quality, value and continuous flow. His key intervention is nurturing and developing skills required for Agile Software Development practices and methodologies based on the core Agile and Lean Values and Principles. He brings passion to his work and establishes strong understanding and expectations of customer value, by building on trust, results, and collaboration across the enterprise at Leadership, Management and Delivery Organization.</p>
				    </div>
				</div>
			</div>
		</div>
	</section>
    <!--end Presenter Details section-->
    
    <!--start Session Overview section-->
	<section class="agileMetrics grey-section">
		<div class="container">
			<div class="col-sm-12 col-xs-12">
				<h2 class="sectionTitle">Session Overview</h2>
				<p class="para_training">It's a great honour to have Priyank Pathak ( Curator and Founder at <strong class="innoroo">INNOVATION ROOTS</strong>) as a presenter for the Lean Kanban 2015 Conference conducted on Dec 11th 2015 at Aloft, Cessna Business Park, Bengaluru, India.</p>
                <p class="para_training">At the session, the presenter Priyank would be taking the participants indulge through the real stories from his experiences in implementing Agile for large enterprises. This session is recommended for any who is planning to going for Agile or still in the journey to transform into an Agile company. In the session, the audience would be given a thinking tool to plan for Agile, how to discover and identify the most common mistakes during the Agile transformation phase.</p>
			</div>
		</div>
	</section>
    <!--end Session Overview section-->
    
    <!--start Learning Objective section-->
	<section class="agileMetrics">
		<div class="container">
			<div class="col-sm-12 col-xs-12">
				<h2 class="sectionTitle">
					Learning Objective
				</h2>
				<ul>
					<li class="training_li_list">Introduction to Agile</li>
					<li class="training_li_list">Principles and Concepts of Agile</li>
					<li class="training_li_list">Generic approaches for Agile</li>
                    <li class="training_li_list">Challenges you face during Agile transformation and How to fix them</li>
					<li class="training_li_list">Q & A session.</li>
				</ul>
			</div>
		</div>
	</section>
     <!--end Learning Objective section-->
    
     <!--start contact section-->	
	<section class="no-margin-bottom contact_us_bg_page margin_top_contact">
		<div class="container">
			<div class="col-sm-12 col-xs-12 padding0">
				<div class="col-sm-12 col-xs-12">
					<h2 class="contact_training_title1">Want to Participate?</h2>
					<h4 class="contact_training_title2">You can reach us to book in-house class</h4>
					<a href="../../about/contact/" class="training_contact">Contact</a>
				</div>
			</div>
		</div>
	</section>
     <!--end contact section-->
	<?php include('../../includes/footer.php'); ?>
    
     <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>
    <!--end pure chat-->
    
</body>

</html>
