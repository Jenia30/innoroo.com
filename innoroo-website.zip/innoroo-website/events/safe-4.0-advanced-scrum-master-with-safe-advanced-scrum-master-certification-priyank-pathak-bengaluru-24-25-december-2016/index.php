<!--Updated On 07-07-2018 MI
	Meta tag updated
-->

<!DOCTYPE html>
<html lang="en">

<head>
    <title>INNOVATION ROOTS | Events | SAFe 4.0 Advanced Scrum Master with SAFe Advanced Scrum Master Certification Priyank Pathak Bengaluru 24 - 25 December 2016 | Best training session on SAFe 4.0 advanced scrum master training in 2016 </title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="The SAFe Advanced Scrum Master is the two-day technical course for existing Scrum Masters to take the path leading their Scrum knowledge to Enterprise-level. Register here to learn more!">
    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">

    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link rel=stylesheet href=../../inc/assets/css/newsletter_form.css>
    <link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
    <link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
    <link rel="stylesheet" href="../../inc/assets/css/material-design-iconic-font.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../../inc/assets/css/main.css" rel="stylesheet" />
    <script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>
    <script type=text/javascript>
        document.oncontextmenu = new Function("return false");
        document.onselectstart = new Function("return false");
        if (window.sidebar) {
            document.onmousedown = new Function("return false");
            document.onclick = new Function("return true");
            document.oncut = new Function("return false");
            document.oncopy = new Function("return false");
            document.onpaste = new Function("return false")
        };

    </script>
    <!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
</head>

<body>
    <?php include('../../includes/header.php'); ?>
    <section class="section_margin_gen_training section_training_banner safe_class">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-9 col-xs-12">
                    <h2 class="sectionTitle class_font">SAFe<sup>&reg;</sup> 4.0 Advanced Scrum Master with SAFe<sup>&reg;</sup> Advanced Scrum Master Certification</h2>
                    <h3 class="sectionSubtitle class_font">[ Essential Leadership skills to lead the enterprise transformation ]</h3>
                </div>
                <div class="col-sm-3 col-xs-12">
                    <div class="reg_section_bg">
                        <div class="reg_training_sec">
                            <h4 class="reg_section">24 - 25 December 2016</h4>
                            <h4 class="reg_section">2 Day Workshop</h4>
                            <h4 class="reg_section"><b>Bengaluru</b></h4>
                        </div>
                        <a target="blank" class="training_register">CLOSED</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">Overview</h2>
                    <p class="para_training">This SAFe<sup>&reg;</sup> Advanced Scrum Master (SASM) course helps the present Scrum Masters to take the leadership roles in applying and implementing the SAFe<sup>&reg;</sup> principles in Agile team, program and enterprise. This course comprises of leadership skills, facilitating of cross-team interactions to support Program Execution and relentless improvement. During this course participants will learn several topics on SAFe<sup>&reg;</sup> principles, values, Lean-Agile principles, Agile Architecture, Quality Engineering techniques, and DevOps practices. This course benefits Team Leaders, Project Managers, Engineering and Development Managers, and others who are responsible for Agile execution or facilitation in an Agile or SAFe<sup>&reg;</sup> context.</p>
                    
                    <p class="para_training">After attending this two-day course, participants will learn how to intensify the Scrum paradigm by introducing Scalable Engineering and DevOps practices. The course also helps in understanding the application of Kanban to facilitate the flow of values and supports interactions with architects, Product Management, and other critical stakeholders in context of larger Programs and Enterprise. The course provides the tool of action that help build high-performance teams that express practical methods of dealing with Agile and Scrum Anti-Patterns.</p>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training section_training_requirements">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-hourglass-half fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Duration</h5>
                        <h6 class="training_requirement_title1">2 Days (16 Hours)</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-clock-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Timing</h5>
                        <h6 class="training_requirement_title1">9 AM to 6 PM Each day (1 Hour break in between)</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-user-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Presenter</h5>
                        <h6 class="training_requirement_title1">Priyank Pathak</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-group fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Batch Size</h5>
                        <h6 class="training_requirement_title1">Max 50 participants</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-id-badge fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Participant Profile</h5>
                        <h6 class="training_requirement_title1">Intermediate</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-tasks fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Prerequisite</h5>
                        <h6 class="training_requirement_title1">Recommended to be certified as SAFe<sup>&reg;</sup> Scrum Master/Certified Scrum Master/Professional Scrum Master
                        </h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-language fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Course Delivery Language</h5>
                        <h6 class="training_requirement_title1">English</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <span class="glyphicon glyphicon-blackboard fa_training fa-2x"></span>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Approach of Delivery</h5>
                        <h6 class="training_requirement_title1">Mix of theory and workshop sessions (Classroom Training)</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-graduation-cap fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Certification Details</h5>
                        <h6 class="training_requirement_title1">Attending the course will enable participants to take the exam and become  a certified SAFe<sup>&reg;</sup> Advanced Scrum Master (SASM) 4.0
                        </h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-university fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Accreditation Institute</h5>
                        <h6 class="training_requirement_title1">Scaled Agile Academy</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-handshake-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Commercials & Logistics</h5>
                        <h6 class="training_requirement_title1">Contact us for Quotations</h6>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0 section-ul-bottom">
                <div class="col-sm-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Agenda
                    </h2>
                    <ul>
                        <li class="training_li_list">SAFe<sup>&reg;</sup> Framework, values, and Lean-Agile principles</li>
                        <li class="training_li_list">Scrum Master roles and responsibilities in SAFe<sup>&reg;</sup> environment</li>
                        <li class="training_li_list">Apply SAFe<sup>&reg;</sup> principles with the perspective of a Scrum Master</li>
                        <li class="training_li_list">Analyze Agile and Scrum anti-patterns</li>
                        <li class="training_li_list">Apply Kanban and flow to optimize teamwork</li>
                        <li class="training_li_list">Build high-performing teams</li>
                        <li class="training_li_list">Interact with the system team, deployment, UX, Architects, Product Owners, Product Managers, and Business Owners</li>
                        <li class="training_li_list">Program increment planning, execution, and Inspect and Adapt workshop</li>
                    </ul>
                </div>
                <div class="col-sm-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Learning Objective
                    </h2>
                    <ul>
                        <li class="training_li_list">Application of SAFe<sup>&reg;</sup> 4.0 principles to facilitate, enable, and coach in the multi-team environment</li>
                        <li class="training_li_list">Build high-performing teams that foster relentless improvement at the program and team levels</li>
                        <li class="training_li_list">Find out Agile and Scrum anti-patterns</li>
                        <li class="training_li_list">Support the adoption of DevOps, Agile Architecture and other Engineering Practices</li>
                        <li class="training_li_list">Discover the usage of  Kanban in facilitating the flow of team and improve team's performance</li>
                        <li class="training_li_list">Learn to facilitate Program Planning (PI), Execution, and Delivery of end-to-end systems value</li>
                        <li class="training_li_list">Learning through participation in Communities of Practices and Innovation Cycles.</li>
                    </ul>
                </div>
                <div class="col-sm-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Audience
                    </h2>
                    <ul>
                        <li class="training_li_list">Existing Scrum Masters</li>
                        <li class="training_li_list">Team leaders, Project Managers, and others professionals aiming to assume the role of an Agile Team Facilitator in a SAFe<sup>&reg;</sup> or Enterprise Agile context</li>
                        <li class="training_li_list">Development and Engineering Managers  responsible for execution of Agile, and for coaching teams and sub-teams</li>
                        <li class="training_li_list">Agile Coaches, Agile Program Managers and Release Train Engineers</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Course Deliverables
                    </h2>
                    <ul>
                        <li class="training_li_list">Attendees will get a printed copy of the workbook</li>
                        <li class="training_li_list">Eligibility to take the SAFe<sup>&reg;</sup> Advanced Scrum Master exam online</li>
                        <li class="training_li_list">Attendees who pass the exam will receive the SAFe<sup>&reg;</sup> Advanced Scrum Master certificate with one year free membership from Scaled Agile Academy</li>
                        <li class="training_li_list">A SAFe<sup>&reg;</sup> Advanced Scrum Master (SASM) digital badge for promoting accomplishment online</li>
                        <li class="training_li_list">Participants will also receive a branding kit with SASM certification mark</li>
                        <li class="training_li_list">Attendees who pass the exam, will get access to members-only resources like workbooks, webinars, guidance presentations, and advance notice of forthcoming SAFe<sup>&reg;</sup> products</li>
                        <li class="training_li_list">Membership renewals annual from the date of certification</li>
                        <li class="training_li_list">In person 2- day training full of learning and fun.</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section class="no-margin-bottom contact_us_bg_page margin_top_contact">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-ms-12 col-xs-12">
                    <h2 class="contact_training_title1">Want to Participate?</h2>
                    <h4 class="contact_training_title2">You can reach us to book in-house class</h4>
                    <a href="../../about/contact/" class="training_contact">Contact</a>
                </div>
            </div>
        </div>
    </section>
    <?php include('../../includes/footer.php'); ?>

    <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
        window.purechatApi = {
            l: [],
            t: [],
            on: function() {
                this.l.push(arguments);
            }
        };
        (function() {
            var done = false;
            var script = document.createElement('script');
            script.async = true;
            script.type = 'text/javascript';
            script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
            document.getElementsByTagName('HEAD').item(0).appendChild(script);
            script.onreadystatechange = script.onload = function(e) {
                if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
                    var w = new PCWidget({
                        c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
                        f: true
                    });
                    done = true;
                }
            };
        })();

    </script>
    <!--end pure chat-->


</body>

</html>
