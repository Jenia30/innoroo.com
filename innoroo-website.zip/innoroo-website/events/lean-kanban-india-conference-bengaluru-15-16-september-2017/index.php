<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Title Tag Meta Start -->
    <!-- Updated on 07.07.18 version MI -->

    <title>INNOVATION ROOTS | Events | Lean Kanban India Conference Bengaluru 15 - 16 September 2017 | Best conference in India </title>

    <!-- Title Tag Meta End -->

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Description Tag Meta Start -->
    <!-- Updated on 07.07.18 version MI -->

    <meta name="description" content="Lean Kanban India 2017 is the 4th edition of the internationally acclaimed conference, organized and managed by INNOVATION ROOTS in partnership with Lean Kanban University.">

    <!-- Description Tag Meta End -->

    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
    <META NAME="ROBOTS" CONTENT="INDEX, FOLLOW"></META>

    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
    <link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../../inc/assets/css/main.css" rel="stylesheet" />
    <script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>
    <script type=text/javascript>
        document.oncontextmenu = new Function("return false");
        document.onselectstart = new Function("return false");
        if (window.sidebar) {
            document.onmousedown = new Function("return false");
            document.onclick = new Function("return true");
            document.oncut = new Function("return false");
            document.oncopy = new Function("return false");
            document.onpaste = new Function("return false")
        };

    </script>
</head>

<body>
    <?php include('../../includes/header.php'); ?>
    <section class="section_margin_gen_training section_training_banner kanban_class">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-9 col-xs-12">
                    <h2 class="sectionTitle class_font">Lean Kanban India 2017 Conference</h2>
                </div>
                <div class="col-sm-3 col-xs-12">
                    <div class="reg_section_bg">
                        <div class="reg_training_sec">
                            <h4 class="reg_section">15 - 16 September 2017</h4>
                            <h4 class="reg_section">2 Day Conference</h4>
                            <h4 class="reg_section"><b>Bengaluru</b></h4>
                        </div>
                        <a href="http://www.leankanbanindia.com/conference/2017" target="_blank" class="training_register">KNOW MORE</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <p class="para_training">
                        Lean Kanban India 2017 is the 4th edition of the internationally acclaimed conference, organized and managed by <strong class="innoroo">INNOVATION ROOTS</strong> in partnership with Lean Kanban University. Like every year, we are happy to have Digite, Inc., and GoEventz as our sponsors. The conference is going to be held at Hotel Novotel, Bengaluru on September 15-16, 2017. 
                    </p>
                    <p class="para_training">
                        Lean Kanban 2017 is going to be a promising event with a variety of sessions and workshops taken by Keynote Speakers, Thought Leaders, Researchers, and Scientists who have revolutionary changes in the IT industry with their unique perspectives and ideas. The sessions and workshops covered in this conference are based on the themes- Foundation Kanban, Enterprise Kanban, DevOps and Coaching, which are presented along with real-time case studies.
                    </p>
                    <p class="para_training">
                        You get the opportunity to connect with Kanban Community Leaders like David J. Anderson (the originator of Kanban and Chairperson of LKU), Patrick Steyaert Founder (Principal Coach and Trainer at Okaloa), Mike Burrows  (Founder at Agendashift) and Shri Swami Shantatmananda (Secretary, Ramakrishna Mission, Delhi). Be a part of this conference to experience the world-class perspectives of Kanban deployment and methods of applying Kanban in your enterprise.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section class="no-margin-bottom contact_us_bg_page margin_top_contact">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="contact_training_title1">Want to Participate?</h2>
                    <h4 class="contact_training_title2">You can reach us to book in-house class</h4>
                    <a href="../../about/contact/" class="training_contact">Contact</a>
                </div>
            </div>
        </div>
    </section>
    <?php include('../../includes/footer.php'); ?>

    <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
        window.purechatApi = {
            l: [],
            t: [],
            on: function() {
                this.l.push(arguments);
            }
        };
        (function() {
            var done = false;
            var script = document.createElement('script');
            script.async = true;
            script.type = 'text/javascript';
            script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
            document.getElementsByTagName('HEAD').item(0).appendChild(script);
            script.onreadystatechange = script.onload = function(e) {
                if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
                    var w = new PCWidget({
                        c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
                        f: true
                    });
                    done = true;
                }
            };
        })();

    </script>
    <!--end pure chat-->

</body>

</html>
