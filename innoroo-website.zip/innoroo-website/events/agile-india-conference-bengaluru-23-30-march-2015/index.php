<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Title Tag Meta Start -->
    <!-- Updated on 25.06.04 version MI -->

    <title>INNOVATION ROOTS | Events | Agile India Conference Bengaluru 23 - 30 March 2015 | Agile India 2015 | Agile 2015 conference  </title>

    <!-- Title Tag Meta End -->

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Description Tag Meta Start -->
    <!-- Updated on 25.06.04 version MI -->

    <meta name="description" content="Come join us at Agile India 2015 conference to explore diversified and interesting solutions, and contribute to the future of Agile software development. ">

    <!-- Description Tag Meta End -->

    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
    <META NAME="ROBOTS" CONTENT="INDEX, FOLLOW"></META>

    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
    <link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../../inc/assets/css/main.css" rel="stylesheet" />
    <script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>
    <script type=text/javascript>
        document.oncontextmenu = new Function("return false");
        document.onselectstart = new Function("return false");
        if (window.sidebar) {
            document.onmousedown = new Function("return false");
            document.onclick = new Function("return true");
            document.oncut = new Function("return false");
            document.oncopy = new Function("return false");
            document.onpaste = new Function("return false")
        };

    </script>
</head>

<body>
    <?php include('../../includes/header.php'); ?>
    <section class="section_margin_gen_training section_training_banner conference_2017_class">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-9 col-xs-12">
                    <h2 class="sectionTitle class_font">Agile India 2015 Conference</h2>
                </div>
                <div class="col-sm-3 col-xs-12">
                    <div class="reg_section_bg">
                        <div class="reg_training_sec">
                            <h4 class="reg_section">23 - 30 March 2015</h4>
                            <h4 class="reg_section">8 Day Conference</h4>
                            <h4 class="reg_section"><b>Bengaluru</b></h4>
                        </div>
                        <a href="https://2015.agileindia.org" target="_blank" class="training_register">KNOW MORE</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <p class="para_training">
                        <strong class="innoroo">INNOVATION ROOTS</strong> is proudly announcing the Gold Sponsorship for the Agile India 2015 conference, which is going to held on 23 - 30 March, 2015 at Chancery Pavilion Hotel, Bangalore. We are presenting this sponsorship to Agile India 2015 in partnership with Rally. 
                    </p>
                    <p class="para_training">
                        Agile India 2015 is Asia's largest international conference on Agile and Lean Product Development. This is a refreshing yet intense 4-day conference where you can learn new ideas and practices from expert practitioners, and a great opportune time to network with more than 1500+ international delegates of globally top software companies famous in the Agile and Lean arena.
                    </p>
                    <p class="para_training">
                        We at <strong class="innoroo">INNOVATION ROOTS</strong> provide Training, Consultancy services, and mentoring services to our customers, help them in enhancing their leadership skills, and creating value delivery teams. We are also specialized in providing training and certifications on Lean-Agile, Scrum, DevOps and SAFe.
                    </p>
                    <p class="para_training">
                        Come join us at Agile India 2015 conference to explore diversified and interesting solutions, and contribute to the future of Agile software development. 
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section class="no-margin-bottom contact_us_bg_page margin_top_contact">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="contact_training_title1">Want to Participate?</h2>
                    <h4 class="contact_training_title2">You can reach us to book in-house class</h4>
                    <a href="../../about/contact/" class="training_contact">Contact</a>
                </div>
            </div>
        </div>
    </section>
    <?php include('../../includes/footer.php'); ?>

    <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
        window.purechatApi = {
            l: [],
            t: [],
            on: function() {
                this.l.push(arguments);
            }
        };
        (function() {
            var done = false;
            var script = document.createElement('script');
            script.async = true;
            script.type = 'text/javascript';
            script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
            document.getElementsByTagName('HEAD').item(0).appendChild(script);
            script.onreadystatechange = script.onload = function(e) {
                if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
                    var w = new PCWidget({
                        c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
                        f: true
                    });
                    done = true;
                }
            };
        })();

    </script>
    <!--end pure chat-->

</body>

</html>
