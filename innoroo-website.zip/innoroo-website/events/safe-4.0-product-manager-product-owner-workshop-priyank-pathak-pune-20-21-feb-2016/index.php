<!DOCTYPE html>
<html lang="en">

<head>
    
    <!--Updated On 07-07-2018 MI
	Meta tag updated-->
    <title>INNOVATION ROOTS | Events | Safe 4.0 Product Manager/Product Owner Workshop Priyank Pathak Pune 20-21 February 2016 | Finest training on SAFe 4.0 Product Manager | Product Manager/Product Owner (PMPO) </title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Description Tag Meta -->
    <!-- Updated on 07.07.18 version MI -->
    <meta name="description" content="Attending the class prepares you to take the exam and become a certified SAFe Product Manager/Product Owner (PMPO).">
    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">

    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link rel=stylesheet href=../../inc/assets/css/newsletter_form.css>
    <link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
    <link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
    <link rel="stylesheet" href="../../inc/assets/css/material-design-iconic-font.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../../inc/assets/css/main.css" rel="stylesheet" />
    <script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>
    <script type=text/javascript>
        document.oncontextmenu = new Function("return false");
        document.onselectstart = new Function("return false");
        if (window.sidebar) {
            document.onmousedown = new Function("return false");
            document.onclick = new Function("return true");
            document.oncut = new Function("return false");
            document.oncopy = new Function("return false");
            document.onpaste = new Function("return false")
        };

    </script>
    <!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
</head>

<body>
    <?php include('../../includes/header.php'); ?>
    <section class="section_margin_gen_training section_training_banner safe_class">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-9 col-xs-12">
                    <h2 class="sectionTitle class_font">SAFe<sup>&reg;</sup> 4.0 Product Manager/Product Owner</h2>
                    <h3 class="sectionSubtitle class_font">[ Be a SAFe<sup>&reg;</sup> Product Management Expert ]</h3>
                </div>
                <div class="col-sm-3 col-xs-12">
                    <div class="reg_section_bg">
                        <div class="reg_training_sec">
                            <h4 class="reg_section">20 - 21 February 2016</h4>
                            <h4 class="reg_section">2 Day Workshop</h4>
                            <h4 class="reg_section"><b>Pune</b></h4>
                        </div>
                        <a target="blank" class="training_register">CLOSED</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">Overview</h2>
                    <p class="para_training">The roles of Product Manager, Product Owner, Solution Manager and Epic Owner tend to drive the delivery of value in a SAFe<sup>&reg;</sup> enterprise. The Lean-Agile mindset, and a concrete understand of the key activities, tools and mechanics are effectively used for value delivery to the enterprise.</p>
                    
                    <p class="para_training">This two-day course, teaches the participants gain an intricate knowledge of the specific tools, mechanics and activities that are effectively used to deliver value to the enterprise. After the course, participants will be able to write Epics, Capabilities, Features and User Stories in the context of SAFe<sup>&reg;</sup>, and have a strong foundation for managing backlogs and programs within a Lean-Agile enterprise.</p>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training section_training_requirements">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-hourglass-half fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Duration</h5>
                        <h6 class="training_requirement_title1">2 Days (16 Hours)</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-clock-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Timing</h5>
                        <h6 class="training_requirement_title1">9 AM to 6 PM Each day (1 Hour break in between)</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-user-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Presenter</h5>
                        <h6 class="training_requirement_title1">Priyank Pathak</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-group fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Batch Size</h5>
                        <h6 class="training_requirement_title1">Max 30 Participants</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-id-badge fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Participant Profile</h5>
                        <h6 class="training_requirement_title1">Intermediate</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-tasks fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Prerequisite</h5>
                        <h6 class="training_requirement_title1">Attended a Leading SAFe<sup>&reg;</sup> course, Experience in SAFe<sup>&reg;</sup>, Agile and other relevant certifications</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-language fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Course Delivery Language</h5>
                        <h6 class="training_requirement_title1">English</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <span class="glyphicon glyphicon-blackboard fa_training fa-2x"></span>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Approach of Delivery</h5>
                        <h6 class="training_requirement_title1">Mix of theory and workshop sessions (Classroom Training)</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-graduation-cap fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Certification Details</h5>
                        <h6 class="training_requirement_title1">Attending the course will enable participants to take the exam and become a certified SAFe<sup>&reg;</sup> Product Manager/Product Owner (PO/PM)
                        </h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-university fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Accreditation Institute</h5>
                        <h6 class="training_requirement_title1">Scaled Agile Academy</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-handshake-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Commercials & Logistics</h5>
                        <h6 class="training_requirement_title1">Contact us for Quotations</h6>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0 section-ul-bottom">
                <div class="col-sm-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Agenda
                    </h2>
                    <ul>
                        <li class="training_li_list">Introduction to the roles of SAFe<sup>&reg;</sup> 4.0 Project Manager/Product Owner</li>
                        <li class="training_li_list">Understand the Lean-Agile mindset</li>
                        <li class="training_li_list">Learn to apply SAFe<sup>&reg;</sup> in the Lean enterprise</li>
                        <li class="training_li_list">Roles and responsibilities of Product Manager/Product Owner</li>
                        <li class="training_li_list">Contribute to Portfolio Content</li>
                        <li class="training_li_list">Define and manage Solution value</li>
                        <li class="training_li_list">Being an effective SAFe<sup>&reg;</sup> Product Manager and a SAFe<sup>&reg;</sup> Product Owner</li>
                        <li class="training_li_list">Engage Stakeholders</li>
                    </ul>
                </div>
                <div class="col-sm-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Learning Objective
                    </h2>
                    <ul>
                        <li class="training_li_list">Identify the major components of the Scaled Agile Framework (SAFe<sup>&reg;</sup>)</li>
                        <li class="training_li_list">Connect SAFe<sup>&reg;</sup> to core Lean-Agile principles and values</li>
                        <li class="training_li_list">Identify the most prominent roles within a SAFe<sup>&reg;</sup> implementation</li>
                        <li class="training_li_list">Apply Value Stream strategies to define and manage solution value</li>
                        <li class="training_li_list">Eliminate the processes that provides no value to the business, and improve through Value Stream Mapping</li>
                        <li class="training_li_list">Engage with Program Increment Planning and figure out continuous value</li>
                        <li class="training_li_list">Develop a stakeholder engagement plan</li>
                        <li class="training_li_list">Build and grow communities of practice.</li>                        
                    </ul>
                </div>
                <div class="col-sm-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Audience
                    </h2>
                    <ul>
                        <li class="training_li_list">Product Managers, Product Line Managers, Product Owners, Business Owners, and Business Analysts</li>
                        <li class="training_li_list">Solution Managers, Portfolio Managers, Program Managers, PMO personnel, and Process Leads</li>
                        <li class="training_li_list">Enterprise, Solution, and System Architects</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Course Deliverables
                    </h2>
                    <ul> 
                        <li class="training_li_list">Attendees will get a printed copy of workbook</li>
                        <li class="training_li_list">Eligibility to take the SAFe<sup>&reg;</sup> Project Manager/Product Owner exam</li>
                        <li class="training_li_list">Attendees who pass the exam will receive SAFe<sup>&reg;</sup> Project Manager/Product Owner certificate with one-year free membership from Scaled Agile Academy</li>
                        <li class="training_li_list">A SAFe<sup>&reg;</sup> Project Manager/Product Owner (SAFe<sup>&reg;</sup> POPM) branding kit with Product Manager/Product Owner certification</li>
                        <li class="training_li_list">Attendees who pass the exam, will get access to members-only resources like workbooks, webinars, guidance presentations, and advance notice of forthcoming SAFe<sup>&reg;</sup> products</li>
                        <li class="training_li_list">Membership renewals annually from the date of certification</li>
                        <li class="training_li_list">In person 2-day training full of learning and fun.</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section class="no-margin-bottom contact_us_bg_page margin_top_contact">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-ms-12 col-xs-12">
                    <h2 class="contact_training_title1">Want to Participate?</h2>
                    <h4 class="contact_training_title2">You can reach us to book in-house class</h4>
                    <a href="../../about/contact/" class="training_contact">Contact</a>
                </div>
            </div>
        </div>
    </section>
    <?php include('../../includes/footer.php'); ?>

    <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
        window.purechatApi = {
            l: [],
            t: [],
            on: function() {
                this.l.push(arguments);
            }
        };
        (function() {
            var done = false;
            var script = document.createElement('script');
            script.async = true;
            script.type = 'text/javascript';
            script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
            document.getElementsByTagName('HEAD').item(0).appendChild(script);
            script.onreadystatechange = script.onload = function(e) {
                if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
                    var w = new PCWidget({
                        c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
                        f: true
                    });
                    done = true;
                }
            };
        })();

    </script>
    <!--end pure chat-->


</body>

</html>
