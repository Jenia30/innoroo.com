<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Title Tag Meta Start -->
    <!-- Updated on 09.07.18 version JB -->
    <title>INNOVATION ROOTS | Events | Kanban Management Professional Alexei Zheglov Bengaluru 24-25 September 2018 | Kanban Management Professional training </title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Description Tag Meta Start -->
    <!-- Updated on 09.07.18 version JB -->
    <meta name="description" content="This course is also called as KMP foundation-2, which officially completes the requirements towards earning the Kanban Management Professional (KMP) designation.">
    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
    <META NAME="ROBOTS" CONTENT="INDEX, FOLLOW"></META>

    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
    <link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../../inc/assets/css/main.css" rel="stylesheet" />
    <script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>
    <script type=text/javascript>
        document.oncontextmenu = new Function("return false");
        document.onselectstart = new Function("return false");
        if (window.sidebar) {
            document.onmousedown = new Function("return false");
            document.onclick = new Function("return true");
            document.oncut = new Function("return false");
            document.oncopy = new Function("return false");
            document.onpaste = new Function("return false")
        };

    </script>
    <!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
</head>

<body>
    <?php include('../../includes/header.php'); ?>
    <section class="section_margin_gen_training section_training_banner kanban_class">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-9 col-xs-12">
                    <h2 class="sectionTitle class_font">Kanban Management Professional (KMP II) Workshop</h2>
                    <h3 class="sectionSubtitle class_font">[ Get started with applying advanced Kanban concepts ] </h3>
                </div>
                <div class="col-sm-3 col-xs-12">
                    <div class="reg_section_bg">
                        <div class="reg_training_sec">
                            <h4 class="reg_section">24 - 25 September 2018</h4>
                            <h4 class="reg_section">2 Day Workshop</h4>
                            <h4 class="reg_section"><b>Bengaluru</b></h4>
                        </div>
                        <a href="https://www.goeventz.com/event/kanban-management-professional-kmp-ii/72439" target="_blank" class="training_register">REGISTER</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Overview
                    </h2>
                    <p class="para_training">
                       The two-day Lean Kanban University-certified Kanban Management Professional (KMP II) class is the second stage of training required to attain the Kanban Management Professional (KMP) credential. This KMP II class, running just after the Lean Kanban India 2018 conference, is your unique opportunity to take this training with Alexei Zheglov, one of the top Kanban experts worldwide (and a Keynote Speaker at Lean Kanban India), who will team up with one of the Accredited Kanban Trainers (AKTs) from India. It’s an opportunity for deeper learning and getting your difficult Kanban questions answered.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training section_training_requirements">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-hourglass-half fa_training fa-2x fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Duration</h5>
                        <h6 class="training_requirement_title1">2 Day (16 Hours)</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-clock-o fa_training fa-2x fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Timing</h5>
                        <h6 class="training_requirement_title1">9 AM to 6 PM (1 Hour break in between)</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-user-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Presenter</h5>
                        <h6 class="training_requirement_title1">Alexei Zheglov</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-group fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Batch Size</h5>
                        <h6 class="training_requirement_title1">Max 30 Participants</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-id-badge fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Participants Profile</h5>
                        <h6 class="training_requirement_title1">Intermediate</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-tasks fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Prerequisite</h5>
                        <h6 class="training_requirement_title1">KMP1 Certification</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-language fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Course Delivery Language</h5>
                        <h6 class="training_requirement_title1">English</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <span class="glyphicon glyphicon-blackboard fa_training fa-2x"></span>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Approach of Delivery</h5>
                        <h6 class="training_requirement_title1">Mix of theory & workshop session (Classroom training)</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-graduation-cap fa_training fa-2x " aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Certification Details</h5>
                        <h6 class="training_requirement_title1">Attendees will get certified by Lean Kanban University as a Kanban Management Professional (KMP)</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-university fa_training fa-2x " aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Accreditation Institute</h5>
                        <h6 class="training_requirement_title1">Lean Kanban University</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-handshake-o fa_training fa-2x " aria-hidden=true></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Commercials & Logistics</h5>
                        <h6 class="training_requirement_title1">Contact us for Quotations</h6>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class=section_margin_gen_training>
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0 section-ul-bottom">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Agenda
                    </h2>
                    <ul>
                        <li class="training_li_list">Motivation for the Kanban method</li>
                        <li class="training_li_list">Proto-Kanban evolutionary forms, multi-service Kanban case study, commitments</li>
                        <li class="training_li_list">Interpretation of Kanban practices in-context, seeing services, upstream Kanban</li>
                        <li class="training_li_list">Kanban cadences: Service delivery set</li>
                        <li class="training_li_list">Service delivery reviews (SDR), Ops reviews, models for improvement, sources of delay, dependencies between services</li>
                        <li class="training_li_list">Managing variability, blocker clustering, risk reviews, bottlenecks, economic costs, evolutionary approach to organizational change and improvement</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Learning Objective
                    </h2>
                    <ul>
                        <li class="training_li_list">Deeper Kanban practices to sustain evolutionary improvements</li>
                        <li class="training_li_list">Getting to pull at the enterprise scale</li>
                        <li class="training_li_list">Organizational feedback loops enabled by Kanban cadences</li>
                        <li class="training_li_list">Several important models for finding and validating improvements – "improvement technologies"</li>
                        <li class="training_li_list">We will also enhance this class with practical guidance on several topics such as: the lead time metric, non-IT Kanban applications, and the secrets of STATIK (the systems thinking approach to introducing Kanban)</li>
                        <li class="training_li_list">Why evolutionary change may be more appropriate for your company than managed change</li>
                        <li class="training_li_list">How to identify and approach emotional and rational sources of resistance to change</li>
                        <li class="training_li_list">How proto-Kanban systems aren't "incorrect ways to do Kanban", but rather evolutionary Kanban forms that bring real benefits to companies</li>
                        <li class="training_li_list">A relatable enterprise-level Kanban case study</li>
                        <li class="training_li_list">How to be deliberate at making important business commitments</li>
                        <li class="training_li_list">Deeper definitions of the Kanban method and their appropriate interpretations in context</li>
                        <li class="training_li_list">Seeing your enterprise as a network of services that can improve together</li>
                        <li class="training_li_list">Non-IT applications of Kanban</li>
                        <li class="training_li_list">Advanced guidance on STATIK (the systems thinking approach to introducing Kanban)</li>
                        <li class="training_li_list">Key approaches to scaling Kanban</li>
                        <li class="training_li_list">Understanding upstream vs. delivery Kanban and the related management roles</li>
                        <li class="training_li_list">Implementing the Delivery Set of Kanban cadences, particularly the replenishment meeting, multiple-levels of stand-ups and delivery planning</li>
                        <li class="training_li_list">How to design service delivery reviews (SDR) and Ops Reviews (this begins the Improvement Set of Kanban cadences)</li>
                        <li class="training_li_list">The lead time metric and its probabilistic nature</li>
                        <li class="training_li_list">Identifying, managing, eliminating, mitigating sources of delay</li>
                        <li class="training_li_list">Managing dependencies between services</li>
                        <li class="training_li_list">Understanding and managing the sources of variability present in your processes</li>
                        <li class="training_li_list">Conducting risk reviews (this completes the Improvement Set of Kanban cadences)</li>
                        <li class="training_li_list">Dealing with bottlenecks in high-variability creative processes</li>
                        <li class="training_li_list">Applying an economic model to find waste in projects</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Audience
                    </h2>
                    <ul>
                        <li class="training_li_list">Project and Portfolio Managers</li>
                        <li class="training_li_list">Service Delivery Managers</li>
                        <li class="training_li_list">Heads of PMO and Program Directors</li>
                        <li class="training_li_list">Project Management Consultants</li>
                        <li class="training_li_list">Executives with eagerness to develop Managerial skills.</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Course Deliverables
                    </h2>
                    <ul>
                        <li class="training_li_list">Attendees will receive a certificate of completion from Lean Kanban University (LKU) in digital format</li>
                        <li class="training_li_list">Get listed to LKU Alumni Directory along with free membership in Lean Kanban University</li>
                        <li class="training_li_list">Attendees will receive a KMP digital badge and access to members-only KMP forums</li>
                        <li class="training_li_list">In person 2-day training full of learning and activities.</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section class="no-margin-bottom contact_us_bg_page margin_top_contact">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="contact_training_title1">Want to Participate?</h2>
                    <h4 class="contact_training_title2">You can reach us to book in-house class</h4>
                    <a href="../../about/contact/" class="training_contact">Contact</a>
                </div>
            </div>
        </div>
    </section>
    <?php include('../../includes/footer.php'); ?>

    <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
        window.purechatApi = {
            l: [],
            t: [],
            on: function() {
                this.l.push(arguments);
            }
        };
        (function() {
            var done = false;
            var script = document.createElement('script');
            script.async = true;
            script.type = 'text/javascript';
            script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
            document.getElementsByTagName('HEAD').item(0).appendChild(script);
            script.onreadystatechange = script.onload = function(e) {
                if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
                    var w = new PCWidget({
                        c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
                        f: true
                    });
                    done = true;
                }
            };
        })();

    </script>
    <!--end pure chat-->

</body>

</html>
