<!DOCTYPE html>
<html lang="en">

<head>
    
      <!--Updated On 25-06-2018 MI
	Meta tag updated-->

	<title>INNOVATION ROOTS | Events | Doing Innovative and Exploratory Work using Kanban Webinar Brett Ansley Online 15 December 2017 | Be a part to be in the best webinar by Brett Ansley </title>
	<meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Description Tag Meta -->
    <!-- Updated on 25.06.18 version MI -->  
	<meta name="description" content="The main objective of this webinar is to influence people for coaching and instructing a group that was occupied with exceedingly inventive discovery, through a best case study. Register here to know more!">
	<meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
    
    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->
    
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
	<link rel=stylesheet href=../../inc/assets/css/newsletter_form.css>
	<link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
	<link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
	<link rel="stylesheet" href="../../inc/assets/css/material-design-iconic-font.min.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="//fonts.googleapis.com/css?family=Roboto+Slab:400,300,700|Open+Sans:700,400,300|Playfair+Display:400,400italic" rel=stylesheet />
	<link href="../../inc/assets/css/main.css" rel="stylesheet" />
	<script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
	<link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
	<script>
		(function(d, e, j, h, f, c, b) {
			d.GoogleAnalyticsObject = f;
			d[f] = d[f] || function() {
				(d[f].q = d[f].q || []).push(arguments)
			}, d[f].l = 1 * new Date();
			c = e.createElement(j), b = e.getElementsByTagName(j)[0];
			c.async = 1;
			c.src = h;
			b.parentNode.insertBefore(c, b)
		})(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
		ga("create", "UA-100332682-2", "auto");
		ga("send", "pageview");

	</script>
	
	<script type=text/javascript>
		document.oncontextmenu = new Function("return false");
		document.onselectstart = new Function("return false");
		if (window.sidebar) {
			document.onmousedown = new Function("return false");
			document.onclick = new Function("return true");
			document.oncut = new Function("return false");
			document.oncopy = new Function("return false");
			document.onpaste = new Function("return false")
		};
	</script>

	<!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
</head>

<body>
	<?php include('../../includes/header.php'); ?>
    
    <!--start Register section-->
	<section class="section_margin_gen_training section_training_banner agileMatrics_class">
		<div class="container">
			<div class="col-sm-12 col-xs-12 padding0">
				<div class="col-sm-9 col-xs-12">
					<h2 class="sectionTitle class_font">Doing Innovative Exploratory work using Kanban Webinar</h2>
					<h3 class="sectionSubtitle class_font">[ Brett Ansley | Agile Kanban Coach, Brett Ansley Consulting ]</h3>
				</div>
				<div class="col-sm-3 col-xs-12">
					<div class="reg_section_bg">
						<div class="reg_training_sec">
							<h4 class="reg_section">15 December 2017</h4>
							<h4 class="reg_section">6:00 pm - 7:30 pm IST</h4>
							<h4 class="reg_section"><b>Online Webinar</b></h4>
						</div>
						<a class="training_register">CLOSED</a>
					</div>
				</div>

			</div>
		</div>
	</section>
    <!--end Register Section-->
    
    <!--start Presenter Details section-->
    <section class="agileMetrics1">
		<div class="container">
			<div class="col-sm-12 col-xs-12">
				<h2 class="sectionTitle">
					Presenter
				</h2>
				<div class="col-sm-12 col-xs-12 speakerDetailSection padd0">
					<div class="col-sm-2 col-sm-offset-0 col-xs-8 col-xs-offset-2 webinar-detail-img">
						<img src="../../inc/assets/img/events/brett-ansley-detail.png" width="100%">
                        <p>( Agile Kanban Coach, Brett Ansley Consulting )</p>
					</div>
					<div class="col-sm-10 col-xs-12 speakerDetailPara">
						<p class="para_training">Brett Ansley is a Digital Product expert, a coach and consultant. He has experience in both leading and coaching product teams inside large companies and startups. He focuses on the intersection of commercial and technology opportunities looking for innovative ways to use technology to drive commercial results. Brett was one of the early Agile adopters and presently coaches the adoption of Lean and Kanban methods to optimise the efficiency of Product Delivery and Management.</p>
					</div>
				</div>
			</div>
		</div>
	</section>
    <!--end Presenter Details section-->
    
    <!--start Session Overview section-->
	<section class="agileMetrics grey-section">
		<div class="container">
			<div class="col-sm-12 col-xs-12">
				<h2 class="sectionTitle">Session Overview</h2>
				<p class="para_training">The session takes audience through the case study of, a coaching team that was engaged in highly innovative discovery work within Government Digital Services. We will compare the before and after states of the team and what outcomes we were trying to achieve, the techniques we used to get there and the challenges we face during the implementation of a flow system within the larger organisation that was not used to flow.</p>
			</div>
		</div>
	</section>
    <!--end Session Overview section-->
    
    <!--start Learning Objective section-->
	<section class="agileMetrics">
		<div class="container">
			<div class="col-sm-12 col-xs-12">
				<h2 class="sectionTitle">
					Learning Objective
				</h2>
				<ul>
					<li class="training_li_list">A real-time Case Study of a Coaching Team</li>
					<li class="training_li_list">Practical Techniques to implement a flow system</li>
					<li class="training_li_list">Q & A session.</li>
				</ul>
			</div>
		</div>
	</section>
     <!--end Learning Objective section-->
    
     <!--start contact section-->	
	<section class="no-margin-bottom contact_us_bg_page margin_top_contact">
		<div class="container">
			<div class="col-sm-12 col-xs-12 padding0">
				<div class="col-sm-12 col-xs-12">
					<h2 class="contact_training_title1">Want to Participate?</h2>
					<h4 class="contact_training_title2">You can reach us to book in-house class</h4>
					<a href="../../about/contact/" class="training_contact">Contact</a>
				</div>
			</div>
		</div>
	</section>
     <!--end contact section-->
	<?php include('../../includes/footer.php'); ?>
    
     <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>
    <!--end pure chat-->
    
</body>

</html>
