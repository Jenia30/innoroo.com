<!DOCTYPE html>
<html lang="en">

<head>

    <!--Updated On 07-07-2018 MI
	Meta tag updated-->
    <title>INNOVATION ROOTS | Events | Flow Days Workshop Patrick Steyaert and Mike Burrows Bengaluru 17-18 September 2017 | Bangalore flow days | 17-18th Sept 2017 </title>

    <!-- Title Tag Meta End -->

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Description Tag Meta Start -->
    <!--  Updated on 07.07.18 version MI -->

    <meta name="description" content="Learn innovative ways of working and become an effective Agile Coach to guide a team and business in gaining organizational agility.">

    <!-- Description Tag Meta End -->

    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
    <META NAME="ROBOTS" CONTENT="INDEX, FOLLOW"></META>

    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
    <link href="../../inc/assets/css/normalize-3.0.2.css rel=stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../../inc/assets/css/main.css" rel="stylesheet" />
    <script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>
    <script type=text/javascript>
        document.oncontextmenu = new Function("return false");
        document.onselectstart = new Function("return false");
        if (window.sidebar) {
            document.onmousedown = new Function("return false");
            document.onclick = new Function("return true");
            document.oncut = new Function("return false");
            document.oncopy = new Function("return false");
            document.onpaste = new Function("return false")
        };

    </script>
    <!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
</head>

<body>
    <?php include('../../includes/header.php'); ?>
    <section class="section_margin_gen_training section_training_banner kanban_class">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-9 col-xs-12">
                    <h2 class="sectionTitle class_font">Bengaluru Flow Days Workshop</h2>
                    <h3 class="sectionSubtitle class_font">[ Intensive, hands-on learning of Okaloa Flowlab and Agendashift ]</h3>
                </div>
                <div class="col-sm-3 col-xs-12">
                    <div class="reg_section_bg">
                        <div class="reg_training_sec">
                            <h4 class="reg_section">17 - 18 September 2017</h4>
                            <h4 class="reg_section">2 Day Workshop</h4>
                            <h4 class="reg_section"><b>Bengaluru</b></h4>
                        </div>
                        <a class="training_register">CLOSED</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Overview
                    </h2>
                    <p class="para_training">
                        The Bengaluru Flow Days workshop offers a combination of both Okaloa Flowlab and Agendashift, two method-agnostic concepts that help participants broaden their expertise as Agile Coaches, assist teams and go beyond their capabilities.
                    </p>
                    <p class="para_training">
                        This two-day workshop provide insights from the creators of the Okaloa Flowlab and Agendashift concepts themselves, namely Patrick Steyaert and Mike Burrows respectively. Okaloa Flowlab helps to demonstrate the concepts of 'Flow' on both Customer and Team-level. Also, it brings more collaboration, awareness, and empathy between upstream and downstream partners.   Agendashift helps in modifying the participants approach towards Lean-Agile transformation and offer great tools to grow competencies as an Agile coach.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training section_training_requirements">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-hourglass-half fa_training fa-2x" aria-hidden=true></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Duration</h5>
                        <h6 class="training_requirement_title1">2 Days (16 Hours)</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-clock-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Timing</h5>
                        <h6 class="training_requirement_title1">9 AM to 6 PM (1 Hour break in between)</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-user-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Presenter</h5>
                        <h6 class="training_requirement_title1">Patrick Steyaert & Mike Burrows</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-group fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Batch Size</h5>
                        <h6 class="training_requirement_title1">30 participants</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-id-badge fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Participants Profile</h5>
                        <h6 class="training_requirement_title1">Beginner or Intermediate</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-check-circle-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Prerequisite</h5>
                        <h6 class="training_requirement_title1">None</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-language fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Course Delivery Language</h5>
                        <h6 class="training_requirement_title1">English</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <span class="glyphicon glyphicon-blackboard fa_training fa-2x"></span>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Approach of Delivery</h5>
                        <h6 class="training_requirement_title1">Mix of theory & workshop sessions (Classroom Training)</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-graduation-cap fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Certification Details</h5>
                        <h6 class="training_requirement_title1">Attendees receive the certificate of Completion for 'Bengaluru Flow Days' workshop
                        </h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-university fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Accreditation Institute</h5>
                        <h6 class="training_requirement_title1"><strong class="innoroo">INNOVATION ROOTS</strong> Academy</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-handshake-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Commercials & Logistics</h5>
                        <h6 class="training_requirement_title1">Contact us for Quotations</h6>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class=section_margin_gen_training>
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0 section-ul-bottom">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Agenda
                    </h2>
                    <ul>
                        <li class="training_li_list">Introduction to Okaloa Flowlab and Agendashift</li>
                        <li class="training_li_list">Explore 'Flow' at Team, Portfolio and Customer level</li>
                        <li class="training_li_list"><strong>Discovery -</strong> Identifying strategic goals, obstacles, and outcomes</li>
                        <li class="training_li_list"><strong>Exploration -</strong> Debriefing your Agendashift values-based delivery assessment, agreeing scope and approach</li>
                        <li class="training_li_list"><strong>Mapping -</strong> Building your transformation plan</li>
                        <li class="training_li_list"><strong>Elaboration -</strong> Generating, framing, and developing actions</li>
                        <li class="training_li_list"><strong>Operation -</strong> Organising for continuous transformation</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Learning Objective
                    </h2>
                    <ul>
                        <li class="training_li_list">Learn ways of working to become an effective Agile Coach</li>
                        <li class="training_li_list">Discover the foundation for team, business and organizational agility</li>
                        <li class="training_li_list">Learn different approaches for Lean-Agile Transformation to grow your competencies as a coach</li>
                        <li class="training_li_list">Understand the integration of techniques and concepts from Lean-Agile, Kanban, Clean Language, Cynefin, Lean Startup, and A3</li>
                        <li class="training_li_list">Learn to bring continuous transformation in your organization.</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Audience
                    </h2>
                    <ul>
                        <li class="training_li_list">Kanban Coach</li>
                        <li class="training_li_list">Project Managers and Project Leads</li>
                        <li class="training_li_list">Scrum Masters</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Course Deliverables
                    </h2>
                    <ul>
                        <li class="training_li_list">Attendees will receive the  Certificate of Completion on 'Bengaluru Flow Days'</li>
                        <li class="training_li_list">In person 2-day training full of learning and fun.</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section class="contact_us_bg_page no-margin-bottom margin_top_contact">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="contact_training_title1">Want to Participate?</h2>
                    <h4 class="contact_training_title2">You can reach us to book in-house class</h4>
                    <a href="../../about/contact/" class="training_contact">Contact</a>
                </div>
            </div>
        </div>
    </section>
    <?php include('../../includes/footer.php'); ?>

    <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
        window.purechatApi = {
            l: [],
            t: [],
            on: function() {
                this.l.push(arguments);
            }
        };
        (function() {
            var done = false;
            var script = document.createElement('script');
            script.async = true;
            script.type = 'text/javascript';
            script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
            document.getElementsByTagName('HEAD').item(0).appendChild(script);
            script.onreadystatechange = script.onload = function(e) {
                if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
                    var w = new PCWidget({
                        c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
                        f: true
                    });
                    done = true;
                }
            };
        })();

    </script>
    <!--end pure chat-->

</body>

</html>
