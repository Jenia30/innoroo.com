<!--Updated On 09-07-2018JB
meta tag updated-->

<!DOCTYPE html>
<html class="full" lang="en">

<head>
    <title>INNOVATION ROOTS | Training | SAFe 4.5 Product Owner Product Manager with SAFe 4 Product Owner Product Manager Certification Priyank Pathak Gurugram 21-22 July 2018</title>
    <meta http-equiv="Content-Type" content="text/html" charset="euc-jp">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
    
    <!--Updated On 09-07-2018JB
Description meta tag updated-->
    <meta name="description" content="The SAFe POPM is a two days course by attending the course, the participants will get an clear idea of the Scaled Agile Framework (SAFe®), the Lean-Agile mindset, and an understanding of key activities, tools, and mechanics used to effectively deliver value to the enterprise.">

    <!-- OPEN GRAPH META TAG STARTS -->	
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
    <link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../../inc/assets/css/main.css" rel="stylesheet" />
    <script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">

    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>
    <script type=text/javascript>
        document.oncontextmenu = new Function("return false");
        document.onselectstart = new Function("return false");
        if (window.sidebar) {
            document.onmousedown = new Function("return false");
            document.onclick = new Function("return true");
            document.oncut = new Function("return false");
            document.oncopy = new Function("return false");
            document.onpaste = new Function("return false")
        };

    </script>
</head>

<body>
    <?php include('../../includes/header.php'); ?>
    <section class="section_margin_gen_training section_training_banner safe_class">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-9 col-xs-12">
                    <h2 class="sectionTitle class_font">SAFe<sup>&reg;</sup> 4.5 Product Owner/Product Manager with SAFe<sup>&reg;</sup> 4 Product Owner/Product Manager Certification</h2>
                    <h3 class="sectionSubtitle class_font">[ Gain the skills to guide the delivery of value in Lean Enterprises ]</h3>
                </div>
                <div class="col-sm-3 col-xs-12">
                    <div class="reg_section_bg">
                        <div class="reg_training_sec">
                            <h4 class="reg_section">21 - 22 July 2018</h4>
                            <h4 class="reg_section">2 Day Workshop</h4>
                            <h4 class="reg_section"><b>Gurugram</b></h4>
                        </div>
                        <a href=" https://www.goeventz.com/event/safe-4.5-product-owner-product-manager-popm/72365" target="_blank" class="training_register">Register</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Overview
                    </h2>
                    <p class="para_training">
                        This two-day course teaches the process of how the roles of Product Manager, Product Owner, Solution Manager, and Epic Owner, tend to drive the delivery of value in a SAFe<sup>&reg;</sup> enterprise. This class helps participants gain an intricate knowledge of the Agile Release Train (ART) and its way of delivering value, and perform their roles more effectively.
                    </p>
                    <p class="para_training">
                        After attending the course, the participants will get an overview of the Scaled Agile Framework (SAFe<sup>&reg;</sup>), the Lean-Agile mindset, and an understanding of key activities, tools, and mechanics used to effectively deliver value to the enterprise. The participants will be able to make use of Lean-Agile methods in order to write Epics, deconstruct them into Features and Stories, plan and execute Iterations and plan Program Increments. They will also gain an understanding of the Continuous Delivery Pipeline and DevOps culture, and the methods to simultaneously improve the Agile Release Train.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training section_training_requirements">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-hourglass-half fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Duration</h5>
                        <h6 class="training_requirement_title1">2 Days (16 Hours)</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-clock-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Timing</h5>
                        <h6 class="training_requirement_title1">9 AM to 6 PM Each day (1 Hour break in between)</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-user-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Presenter</h5>
                        <h6 class="training_requirement_title1">Priyank Pathak</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-group fa_training fa-2x" aria-hidden=true></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Batch Size</h5>
                        <h6 class="training_requirement_title1">Max 30 participants</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-id-badge fa_training fa-2x" aria-hidden=true></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Participants Profile</h5>
                        <h6 class="training_requirement_title1">Beginner or Intermediate</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-tasks fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Prerequisite</h5>
                        <h6 class="training_requirement_title1">Attended a Leading SAFe<sup>&reg;</sup> course, Experience in SAFe<sup>&reg;</sup>, Agile and other relevant certifications
                        </h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-language fa_training fa-2x" aria-hidden=true></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Course Delivery Language</h5>
                        <h6 class="training_requirement_title1">English</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <span class="glyphicon glyphicon-blackboard fa_training fa-2x"></span>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Approach of Delivery</h5>
                        <h6 class="training_requirement_title1">Mix of theory and workshop sessions (Classroom Training)</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-graduation-cap fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Certification Details</h5>
                        <h6 class="training_requirement_title1">Attending the course will enable participants to take the exam and become a certified SAFe<sup>&reg;</sup>Product Owner/ Product Manager (PO/PM)
                        </h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-university fa_training fa-2x" aria-hidden=true></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Accreditation Institute</h5>
                        <h6 class="training_requirement_title1">Scaled Agile Academy</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-handshake-o fa_training fa-2x" aria-hidden=true></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Commercials & Logistics</h5>
                        <h6 class="training_requirement_title1">Contact us for Quotations</h6>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Agenda
                    </h2>
                    <ul>
                        <li class="training_li_list">Introduction to SAFe<sup>&reg;</sup> Product Owner/Project Manager</li>
                        <li class="training_li_list">Understand the Lean-Agile mindset</li>
                        <li class="training_li_list">Learn to apply SAFe<sup>&reg;</sup> in the Lean enterprise</li>
                        <li class="training_li_list">Product Manager and Product Owner roles and responsibilities</li>
                        <li class="training_li_list">Explore customer needs on a continuous loop</li>
                        <li class="training_li_list">Collaborate on Lean Portfolio Management</li>
                        <li class="training_li_list">Execute Program Increment</li>
                        <li class="training_li_list">Create an action plan for a Product Owner/Project Manager</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Learning Objective
                    </h2>
                    <ul>
                        <li class="training_li_list">Identify the major components of the Scaled Agile Framework (SAFe<sup>&reg;</sup>)</li>
                        <li class="training_li_list">Connect SAFe<sup>&reg;</sup> to core Lean-Agile principles and values</li>
                        <li class="training_li_list">Identify the most prominent roles within a SAFe<sup>&reg;</sup> implementation</li>
                        <li class="training_li_list">Apply SAFe<sup>&reg;</sup> in Lean-Agile enterprise</li>
                        <li class="training_li_list">Eliminate the processes that provides no value to the business, and improve through Value Stream Mapping</li>
                        <li class="training_li_list">Engage with Program Increment Planning and figure out continuous value</li>
                        <li class="training_li_list">Develop a stakeholder engagement plan</li>
                        <li class="training_li_list">Build and grow communities of practice.</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Audience
                    </h2>
                    <ul>
                        <li class="training_li_list">Product Managers, Product Line Managers, Product Owners, Business Owners, and Business Analysts</li>
                        <li class="training_li_list">Solution Managers, Portfolio Managers, Program Managers, PMO personnel, and Process Leads</li>
                        <li class="training_li_list">Enterprise, Solution, and System Architects</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Course Deliverables
                    </h2>
                    <ul>
                        <li class="training_li_list">Attendees will get a printed copy of workbook</li>
                        <li class="training_li_list">Eligibility to take the SAFe<sup>&reg;</sup> Product Owner/Project Manager exam</li>
                        <li class="training_li_list">Attendees who pass the exam will receive SAFe<sup>&reg;</sup> Product Owner/Project Manager certificate with one-year free membership from Scaled Agile Academy</li>
                        <li class="training_li_list">A SAFe<sup>&reg;</sup> Product Owner/Project Manager (SAFe<sup>&reg;</sup> POPM) digital badge for promoting accomplishment online</li>
                        <li class="training_li_list">Attendees who pass the exam, will get access to members-only resources like workbooks, webinars, guidance presentations, and advance notice of forthcoming SAFe<sup>&reg;</sup> products</li>
                        <li class="training_li_list">Membership renewals annually from the date of certification</li>
                        <li class="training_li_list">Attendees can apply for 15 PDUs through PMI, 16 SEUs under category C through Scrum Alliance</li>
                        <li class="training_li_list">In person 2-day training full of learning and fun.</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section class="no-margin-bottom contact_us_bg_page margin_top_contact">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="contact_training_title1">Want to Participate?</h2>
                    <h4 class="contact_training_title2">You can reach us to book in-house class</h4>
                    <a href="../../about/contact/" class="training_contact">Contact</a>
                </div>
            </div>
        </div>
    </section>
    <?php include('../../includes/footer.php'); ?>

    <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
        window.purechatApi = {
            l: [],
            t: [],
            on: function() {
                this.l.push(arguments);
            }
        };
        (function() {
            var done = false;
            var script = document.createElement('script');
            script.async = true;
            script.type = 'text/javascript';
            script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
            document.getElementsByTagName('HEAD').item(0).appendChild(script);
            script.onreadystatechange = script.onload = function(e) {
                if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
                    var w = new PCWidget({
                        c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
                        f: true
                    });
                    done = true;
                }
            };
        })();

    </script>
    <!--end pure chat-->

</body>

</html>
