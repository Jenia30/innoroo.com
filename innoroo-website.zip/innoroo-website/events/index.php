<!DOCTYPE html>
<?php
if($_POST)
{

	$name = $_POST['name'];
        $from       = $_POST['email'];
        $phone      =$_POST['phone'];
    
        if($name != '' && $from != '' && $phone !='')
        {
        
        $event      = $_POST['data-events'];
        $location = $_POST['data-location'];
        $dt = $_POST['data-dt'];
        $to         = 'community@innovationroots.com';
        $subject    = 'Register - '.$event;
        $message    = '<html>
                        <head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
                          <title>'.$subject.'</title>
                        </head>
                        <body>
                          <table cellspacing="5" cellpadding="5">
                            <tr>
                              <th>Name : </th><td>'.$name.'</td>
                            </tr>
                            <tr>
                              <th>Email : </th><td>'.$from.'</td>
                            </tr>
                            <tr>
                              <th>Phone : </th><td>'.$phone.'</td>
                            </tr>
                            <tr>
                              <th>Event : </th><td>'.$event.'</td>
                            </tr>
                            <tr>
                              <th>Location : </th><td>'.$location.'</td>
                            </tr>
                            <tr>
                              <th>Date : </th><td>'.$dt.'</td>
                            </tr>
                          </table>
                        </body>
                       </html>';
        $headers  = 'MIME-Version: 1.0'."\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";
        if($from != ''){
            if(mail($to, $subject, $message, $headers))
                header("location:http://innovationroots.com/");
            else
                echo "<span class='text-danger'>Problem sending email</span>";
        }
        }
    
    }
?>
    <html lang="en">

    <head>
         <!--Updated On 07-07-2018 MI
meta tag updated-->
        <title>INNOVATION ROOTS | Events | Best events in 2018:Agile,Kanban,Scrum Master,Lean Kanban,Scaled Agile Framework(SAFe) </title>

        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <!-- OPEN GRAPH META TAG STARTS -->
        <meta property='og:title' content='INNOVATION ROOTS' />
        <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
        <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
        <meta property="og:url" content="www.innoroo.com" />        
        <!-- OPEN GRAPH META TAG ENDS -->

         <!--Description Tag Meta Start-->
    <!--Updated for 07.07.18 version MI-->
        <meta name="description" content="Learn and get certified on Agile,SAFe Advanced Scrum Master and Kanban and SAFe Program Consultant. Regsiter for the workshop at www.innovationroots.com"> 
        <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
        <META NAME="ROBOTS" CONTENT="INDEX, FOLLOW"></META>
        <link href="../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
        <link href="../inc/assets/css/bootstrap.min.css" rel="stylesheet" />
        <link type="text/css" rel="stylesheet" href="../inc/assets/css/newsletter_form.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="../inc/assets/css/main.css" rel="stylesheet" />
        <script src="../inc/assets/js/modernizr.custom.83079.js"></script>
        <link rel="shortcut icon" type="image/x-icon" href="../inc/assets/img/favicon.ico">
        <script>
            (function(d, e, k, h, f, c, b) {
                d.GoogleAnalyticsObject = f;
                d[f] = d[f] || function() {
                    (d[f].q = d[f].q || []).push(arguments)
                }, d[f].l = 1 * new Date();
                c = e.createElement(k), b = e.getElementsByTagName(k)[0];
                c.async = 1;
                c.src = h;
                b.parentNode.insertBefore(c, b)
            })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
            ga("create", "UA-100332682-2", "auto");
            ga("send", "pageview");

        </script>

        <script type="text/javascript">
            document.oncontextmenu = new Function("return false");
            document.onselectstart = new Function("return false");
            if (window.sidebar) {
                document.onmousedown = new Function("return false");
                document.onclick = new Function("return true");
                document.oncut = new Function("return false");
                document.oncopy = new Function("return false");
                document.onpaste = new Function("return false");
            }

        </script>



        <!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
        <!--<script src=https://www.google.com/recaptcha/api.js></script>-->
    </head>

    <body>
        <?php include('../includes/header.php');?>
        <section class="page-cover_bg margin_training_list_media" style=margin:0px>
            <div class="container">
                <div class="page_center_caption">
                    <h1 class="main_title">Events</h1>
                    <div class="text_center_hr"></div>
                    <h2 class="heading_sub_page">Conferences, Training, Meetups and Webinars</h2>
                </div>
            </div>
        </section>

        <!--Start upcoming events-->
        <section class="trianing_list_bg" style="margin:0!important">
            <div class="container">
                <div class="col-sm-12 col-xs-12 padding0">
                    <div class="col-sm-12 col-xs-12 event2017">
                        <h2 class="sectionTitle">Upcoming Events</h2>
                    </div>
                    <div class="col-sm-12 col-xs-12 padding0">
                        

                        <!--Start Team Kanban Practitioner approval-->
<!--
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/prashant-mj.png" alt="Uday Atla" width="100%">

                                            <div class="overlay">
                                                <a href="team-kanban-practitioner-workshop-prashant-mj-bengaluru-07-july-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Team Kanban Practitioner (TKP) Workshop
                                            <p class="training_topic_sub">
                                                1 day course <br /> 07 July 2018
                                            </p>
                                    </div>
                                </div>
                            </div>
                        </div>
-->
                        <!--End Team Kanban Practitioner-->
                        
                        
                        <!--End Priyank Pathak Transform the Core first-->

                        <!--Start Kanban System Design Workshop approval-->
<!--
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/prashant-mj.png" alt="Prashant MJ" width="100%">

                                            <div class="overlay">
                                                <a href="kanban-system-design-prashant-mj-bengaluru-20-21-july-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Kanban System Design (KMP I) Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 20 - 21 July 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
-->
                        <!--End Kanban System Design Workshop-->
                        
                        <!--Start Priyank SAFe 4.5 POPM-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                            <div class="overlay">
                                                <a href="safe-4.5-product-owner-product-manager-with-safe-4-product-owner-product-manager-certification-priyank-pathak-gurugram-21-22-july-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> 4.5 Product Owner/Product Manager Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 21 - 22 July 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe 4.5 POPM-->

                        <!--Start SAFe 4.5 Advanced Scrum Master register link-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Uday Atla" width="100%">

                                            <div class="overlay">
                                                <a href="safe-4.5-advanced-scrum-master-with-safe-4-advanced-scrum-master-certification-priyank-pathak-bengaluru-28-29-july-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> 4.5 Advanced Scrum Master Workshop
                                            <p class="training_topic_sub">
                                                2 day course <br /> 28 - 29 July 2018
                                            </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe 4.5 Advanced Scrum Master-->
                        
                        <!--Start Team Kanban Practitioner approval-->
<!--
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/prashant-mj.png" alt="Uday Atla" width="100%">

                                            <div class="overlay">
                                                <a href="team-kanban-practitioner-workshop-prashant-mj-bengaluru-04-august-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Team Kanban Practitioner (TKP) Workshop
                                            <p class="training_topic_sub">
                                                1 day course <br /> 04 August 2018
                                            </p>
                                    </div>
                                </div>
                            </div>
                        </div>
-->
                        <!--End Team Kanban Practitioner-->
                        
                        <!--Start Priyank SAFe 4.5 POPM-->
<!--
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">

                                            <div class="overlay">

                                                <a href="safe-4.5-product-owner-product-manager-with-safe-4-product-owner-product-manager-certification-priyank-pathak-bengaluru-11-12-august-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> 4.5 Product Owner/Product Manager Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 11 - 12 August 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
-->
                        <!--End SAFe 4.5 POPM-->
                        
                        <!--Start Kanban System Design Workshop-->
<!--
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/prashant-mj.png" alt="Prashant MJ" width="100%">

                                            <div class="overlay">
                                                <a href="kanban-system-design-prashant-mj-bengaluru-17-18-august-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Kanban System Design (KMP I) Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 17 - 18 August 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
-->
                        <!--End Kanban System Design Workshop-->                        
                        
                        <!--Start Collaboration Game Workshop - Meetup Review-->
                       <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                           <div class="training_listcard">
                               <div class="row">
                                   <div class="col-md-5 col-xs-5 img_hover_training">
                                       <div class="hovereffect_training">
                                           <img class="img-responsive img_training" src="../inc/assets/img/events/meetups.png" alt="David J Anderson" width="100%">
                                           
                                           <div class="overlay">
                                               <a href="https://www.meetup.com/innoroo/events/250648081/" target="_blank">
                                                   <p class="info">View</p>
                                               </a>
                                           </div>

                                       </div>
                                   </div>
                                   <div class="col-md-7 col-xs-7">
                                       <p class="training_topic">
                                           Collaboration Game Workshop - Meetup
                                       </p>
                                       <p class="training_topic_sub">
                                           2 Hours <br />11 August 2018
                                       </p>
                                   </div>
                               </div>
                           </div>
                       </div>
                       <!--End Collaboration Game Workshop - Meetup-->   
                        
                        <!--Start Priyank Leading SAFe 4.5 -->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Leading SAFe 4.5" width="100%">
                                            <div class="overlay">
                                                <a href="leading-safe-4.5-workshop-priyank-pathak-bengaluru-11-12-august-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.5 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 11 - 12 August 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Leading SAFe 4.5-->
                        <!--Start Kanban System Design Workshop-->
<!--
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/sudipta-lahiri.png" alt="Sudipta lahiri" width="100%">

                                            <div class="overlay">
                                                <a href="kanban-system-design-bengaluru-18-19-august-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Kanban System Design (KMP I) Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 18 - 19 August 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
-->
                        <!--End Kanban System Design Workshop-->
                        
                        <!--Start Priyank Leading SAFe 4.5 register link-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Leading SAFe 4.5" width="100%">
                                            <div class="overlay">
                                                <a href="leading-safe-4.5-workshop-priyank-pathak-bengaluru-25-26-august-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.5 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 25 - 26 August 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Leading SAFe 4.5-->
                        
                        <!--Start Priyank Feedback Early and Often-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                            <div class="overlay">
                                                <a href="feedback-early-and-often-priyank-pathak-bengaluru-31-august-2018">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                           Feedback Early and Often Session at Next Generation Leadership Summit 
                                        </p>
                                        <p class="training_topic_sub">
                                            45 Minutes Session <br /> 31 August 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Feedback Early and Often-->
                        
                        <!--Start Design Thinking Workshop - Meetup Review-->
                       <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                           <div class="training_listcard">
                               <div class="row">
                                   <div class="col-md-5 col-xs-5 img_hover_training">
                                       <div class="hovereffect_training">
                                           <img class="img-responsive img_training" src="../inc/assets/img/events/meetups.png" alt="David J Anderson" width="100%">
                                           
                                           <div class="overlay">
                                               <a href="https://www.meetup.com/innoroo/events/250648668/" target="_blank">
                                                   <p class="info">View</p>
                                               </a>
                                           </div>

                                       </div>
                                   </div>
                                   <div class="col-md-7 col-xs-7">
                                       <p class="training_topic">
                                           Design Thinking Workshop - Meetup
                                       </p>
                                       <p class="training_topic_sub">
                                           2 Hours <br />08 September 2018
                                       </p>
                                   </div>
                               </div>
                           </div>
                       </div>
                       <!--End Design Thinking Workshop - Meetup-->
                        
                       
                        <!--Start Accredited Kanban-trainer-2018 Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/janice-linden-reed.png" alt="Janice Linden Reed" width="100%">
                                            <div class="overlay">
                                                <a href="accredited-kanban-trainer-janice-linden-reed-bengaluru-16-20-september-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Accredited Kanban Trainer Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            5 day course <br /> 16 - 20 September 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Accredited Kanban-trainer-2018 Workshop-->
                        
                        <!--Start Accredited Kanban-trainer-2018 Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/masa-k-maeda.jpg" alt="Masa K Maeda" width="100%">
                                            <div class="overlay">
                                                <a href="papyrus-city-kanban-workshop-masa-k-maeda-bengaluru-20-september-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Papyrus City Kanban Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            1 day course <br /> 20 September 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Accredited Kanban-trainer-2018 Workshop-->

                        <!--Start Lean Kanban India 2018 Conference-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/leankanbanindia-2018.png" alt="Lean Kanban" width="100%">
                                            <div class="overlay">
                                                <a href="http://leankanbanindia.com/" target="_blank">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Lean Kanban India 2018 Conference
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day event<br /> 21 - 22 September 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Lean Kanban India 2018 Conference-->
                        
                        <!--Start OKALOA Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/patrick-steyart.png" alt="Patrick Steyart" width="100%">
                                            <div class="overlay">
                                                <a href="okaloa-flowlab-workshop-patrick-steyaert-bengaluru-23-september-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                           Okaloa Flowlab Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            1 day course <br /> 23 September 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End OKALOA Workshop-->
                        
                        <!--Start Kanban System Design Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img-circle img_training" src="../inc/assets/img/events/alexei-zheglov.png" alt="Alexei Zheglov" width="100%">
                                            <div class="overlay">
                                                <a href="kanban-management-professional-alexei-zheglov-bengaluru-24-25-september-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Kanban Management Professional (KMP II) Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            1 day course <br /> 24 - 25 September 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Kanban System Design Workshop-->
                        
                        <!--Start Kanban Maturity Model Masterclass-->
                      <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                          <div class="training_listcard">
                              <div class="row">
                                  <div class="col-md-5 col-xs-5 img_hover_training">
                                      <div class="hovereffect_training">
                                          <img class="img-responsive img_training" src="../inc/assets/img/events/lku.png" alt="Kanban" width="100%">

                                          <div class="overlay">
                                              <a href="kanban-maturity-model-masterclass-david-j-anderson-and-teodora-bozheva-bengaluru-24-26-september-2018/">
                                                  <p class="info">View</p>
                                              </a>
                                          </div>

                                      </div>
                                  </div>
                                  <div class="col-md-7 col-xs-7">
                                      <p class="training_topic">
                                          Kanban Maturity Model Masterclass 
                                      </p>
                                      <p class="training_topic_sub">
                                          3 day course <br /> 24 - 26 September 2018
                                      </p>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <!--End Kanban Maturity Model Masterclass-->
                       
                       <!--Start Kanban Coaching Professional Masterclass Workshop-->
                       <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                           <div class="training_listcard">
                               <div class="row">
                                   <div class="col-md-5 col-xs-5 img_hover_training">
                                       <div class="hovereffect_training">
                                           <img class="img-responsive img_training" src="../inc/assets/img/events/lku.png" alt="Kanban" width="100%">
                                           <div class="overlay">
                                               <a href="kanban-coaching-professional-masterclass-david-j-anderson-and-teodora-bozheva-bengaluru-24-28-september-2018/">
                                                   <p class="info">View</p>
                                               </a>
                                           </div>
                                       </div>
                                   </div>
                                   <div class="col-md-7 col-xs-7">
                                       <p class="training_topic">
                                           Kanban Coaching Professional Masterclass
                                       </p>
                                       <p class="training_topic_sub">
                                           5 day course <br /> 24 - 28 September 2018
                                       </p>
                                   </div>
                               </div>
                           </div>
                       </div>
                       <!--End Kanban Coaching Professional Masterclass Workshop-->
                       
                       <!--Start Kanban Leadership Maturity Masterclass Workshop-->
                       <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                           <div class="training_listcard">
                               <div class="row">
                                   <div class="col-md-5 col-xs-5 img_hover_training">
                                       <div class="hovereffect_training">
                                           <img class="img-responsive img_training" src="../inc/assets/img/events/lku.png" alt="Kanban" width="100%">
                                           <div class="overlay">
                                               <a href="kanban-leadership-maturity-masterclass-david-j-anderson-and-teodora-bozheva-bengaluru-27-28-september-2018/">
                                                   <p class="info">View</p>
                                               </a>
                                           </div>
                                       </div>
                                   </div>
                                   <div class="col-md-7 col-xs-7">
                                       <p class="training_topic">
                                           Kanban Leadership Maturity Masterclass 
                                       </p>
                                       <p class="training_topic_sub">
                                           2 day course <br /> 27 - 28 September 2018
                                       </p>
                                   </div>
                               </div>
                           </div>
                       </div>
                       <!--End Kanban Leadership Maturity Masterclass Workshop-->
                        
                        <!--Start Certified LeSS Practitioner-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training " src="../inc/assets/img/events/venkatesh-krishnamurthy.png" alt="venkatesh krishnamurthy" width="100%">
                                            <div class="overlay">
                                                <a href="certified-less-practitioner-workshop-venkatesh-krishnamurthy-bengaluru-05-07-october-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Certified LeSS Practitioner Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            3 day course <br /> 05 - 07 October 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Certified LeSS Practitioner-->  
                    </div>
                </div>
            </div>
        </section>
        <!--End upcoming events-->

        <!--Start Archived Events-->
        <section class="section">
            <div class="container">
                <div class="col-sm-12 col-xs-12 padding0">
                    <div class="col-sm-12 col-xs-12 event2017">
                        <h2 class="sectionTitle">Archived Events</h2>
                    </div>
                    <div class="col-sm-12 col-xs-12 padding0">
                        
                        <!--Start Priyank Pathak Leading SAFe 4.5 register link-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                            <div class="overlay">
                                                <a href="leading-safe-4.5-workshop-priyank-pathak-bengaluru-14-15-july-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.5 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 14 - 15 July 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Priyank Pathak Leading SAFe 4.5-->
                        
                        <!--Start Priyank Pathak Collaboration at Scale register link-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                            <div class="overlay">
                                                <a href="collaboration-at-scale-workshop-priyank-pathak-bengaluru-17-july-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Collaboration at Scale Session - Infosys DevOps Agile Day.
                                        </p>
                                        <p class="training_topic_sub">
                                            1 Hour session <br /> 17 July 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Priyank Pathak Collaboration at Scale-->
                        <!--Start Priyank Pathak Transform the Core first register link-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                            <div class="overlay">
                                                <a href="transform-the-core-first-priyank-pathak-bengaluru-19-july-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Transform the Core first Session at Agile Leadership Summit 2018
                                        </p>
                                        <p class="training_topic_sub">
                                           30 Minutes session <br /> 19 July 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                         <!--Start Planning Game Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/meetups.png" alt="Meetup" width="100%">
                                            <div class="overlay">
                                                <a href="https://www.meetup.com/innoroo/events/250648043/" target="_blank">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Planning Game Workshop <br />- Meetup
                                        </p>
                                        <p class="training_topic_sub">
                                           2 Hours  <br /> 07 July 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Planning Game Workshop-->
                        
                        <!--Start Priyank SAFe 4.5 POPM register link-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">

                                            <div class="overlay">

                                                <a href="safe-4.5-product-owner-product-manager-with-safe-4-product-owner-product-manager-certification-priyank-pathak-bengaluru-30-june-01-july-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> 4.5 Product Owner/Product Manager Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 30 June - 01 July 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe 4.5 POPM-->
                        
                        <!--Start Dov Tsal Taoism and Agility Webinar-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training img-circle" src="../inc/assets/img/events/dov-tsal.jpg" alt="Dov Tsal" width="100%">
                                            <div class="overlay">
                                                <a href="taoism-and-agility-webinar-dov-tsal-online-28-june-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Taoism and Agility Webinar
                                        </p>
                                        <p class="training_topic_sub">
                                            1 Hour <br /> 28 June 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Dov Tsal Taoism and Agility Webinar-->
                        
                        
                        <!--Start Prashant MJ Leading SAFe 4.5-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/prashant-mj.png" alt="Prashant MJ" width="100%">
                                            <div class="overlay">
                                                <a href="../events/leading-safe-4.5-with-sa-certification-prashant-mj-bengaluru-16-17-june-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.5 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 16 - 17 June 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Prashant MJ Leading SAFe 4.5-->
                        
                        <!--Start Flow Game Workshop - Meetup Review-->
                       <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                           <div class="training_listcard">
                               <div class="row">
                                   <div class="col-md-5 col-xs-5 img_hover_training">
                                       <div class="hovereffect_training">
                                           <img class="img-responsive img_training" src="../inc/assets/img/events/meetups.png" alt="David J Anderson" width="100%">
                                           
                                           <div class="overlay">
                                               <a href="flow-game-workshop-meetup-bengaluru-09-june-2018/">
                                                   <p class="info">View</p>
                                               </a>
                                           </div>

                                       </div>
                                   </div>
                                   <div class="col-md-7 col-xs-7">
                                       <p class="training_topic">
                                           Flow Game Workshop - Meetup
                                       </p>
                                       <p class="training_topic_sub">
                                           2 Hours <br />09 June 2018
                                       </p>
                                   </div>
                               </div>
                           </div>
                       </div>
                       <!--End Flow Game Workshop - Meetup-->
                        
                        <!--Start Team Kanban Practitioner register link-->
<!--
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/prashant-mj.png" alt="Uday Atla" width="100%">

                                            <div class="overlay">
                                                <a href="team-kanban-practitioner-workshop-prashant-mj-bengaluru-09-june-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Team Kanban Practitioner (TKP) Workshop
                                            <p class="training_topic_sub">
                                                1 day course <br /> 09 June 2018
                                            </p>
                                    </div>
                                </div>
                            </div>
                        </div>
-->
                        <!--End Team Kanban Practitioner-->
                        
                        <!--Start [Webinar] - Doc Norton Webinar-->
                        
                        <div class="col-md-4 col-sm-6 col-xs-12  margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img-circle img_training" src="../inc/assets/img/events/doc-norton.png" alt="Doc Norton" width="100%">
                                            <div class="overlay">
                                                <a href="agile-metrics-webinar-doc-norton-online-30-may-2018/" >
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                           Agile Metrics Webinar
                                        </p>
                                        <p class="training_topic_sub">
                                            1 Hour <br /> 30 May 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--End [Webinar] - Doc Norton Webinar-->
                        
                        <!--Start SAFe 4.5 Advanced Scrum Master-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">

                                            <div class="overlay">
                                                <a href="safe-4.5-advanced-scrum-master-with-safe-advanced-scrum-master-certification-priyank-pathak-bengaluru-26-27-may-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> 4.5 Advanced Scrum Master Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 26 - 27 May 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe 4.5 Advanced Scrum Master-->
                        
                         <!--Start [Meetup] - Animal Estimation Game Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/meetups.png" alt="Estimation Game" width="100%">
                                            <div class="overlay">
                                                <a href="../events/estimation-game-workshop-meetup-priyank-pathak-bengaluru-19-may-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Estimation Game Workshop Meetup
                                        </p>
                                        <p class="training_topic_sub">
                                            Half day event<br /> 19 May 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End [Meetup] - Animal Estimation Game Workshop-->
                        
                         <!--Start Bhaskar Rao Leading SAFe 4.5-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/bhaskar-rao.png" alt="Bhaskar Rao" width="100%">
                                            <div class="overlay">
                                                <a href="../events/leading-safe-4.5-with-sa-certification-bhaskar-rao-chennai-12-13-may-2018">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.5 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 12 - 13 May 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Bhaskar Rao Leading SAFe 4.5-->
                        
                         <!--Start [Meetup] - The Agile Fluency Model-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/meetups.png" alt="Agile Fluency Model" width="100%">
                                            <div class="overlay">
                                                <a href="agile-fluency-model-meetup-bengaluru-05-may-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            The Agile Fluency Model Meetup
                                        </p>
                                        <p class="training_topic_sub">
                                            2 Hours<br /> 05 May 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End [Meetup] - The Agile Fluency Model-->
                        
                         <!--Start How Agile Leaders Improve Results w/ The Responsibility Process-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/christopher-avery.png" alt="Christopher Avery" width="100%">
                                            <div class="overlay">
                                                <a href="how-agile-leaders-improve-results-with-the-responsibility-process-webinar-christopher-avery-online-1-may-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            How Agile Leaders Improve Results? - Webinar
                                        </p>
                                        <p class="training_topic_sub">
                                            1 Hour <br /> 01 May 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--Ends How Agile Leaders Improve Results w/ The Responsibility Process-->
                        
                        <!--Start Being Agile vs. Doing Agile Webinar-->
                        <div class="col-md-4 col-sm-6 col-xs-12  margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/arie-van-bennekum.png" alt="Arie Van Bennekum" width="100%">
                                            <div class="overlay">
                                                <a href="being-agile-vs-doing-agile-webinar-arie-van-bennekum-online-26-april-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Being Agile vs. Doing Agile Webinar
                                        </p>
                                        <p class="training_topic_sub">
                                            1 Hour <br /> 26 April 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Being Agile vs. Doing Agile Webinar-->

                        <!--Start [Meetup] - LeSS Practitioners Meetup-->
                        <div class="col-md-4 col-sm-6 col-xs-12  margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/meetups.png" alt="LeSS Practitioner" width="100%">

                                            <div class="overlay">
                                                <a href="less-practitioners-meetup-bengaluru-21-april-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            LeSS Practitioners Meetup
                                        </p>
                                        <p class="training_topic_sub">
                                            1:30 Hour<br /> 21 April 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End [Meetup] - LeSS Practitioners Meetup-->

                        <!--Start Certified LeSS Practitioners-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training " src="../inc/assets/img/events/venkatesh-krishnamurthy.png" alt="venkatesh krishnamurthy" width="100%">
                                            <div class="overlay">
                                                <a href="certified-less-practitioner-workshop-venkatesh-krishnamurthy-bengaluru-20-22-april-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Certified LeSS Practitioner Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            3 day course <br /> 20 - 22 April 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Certified LeSS Practitioners-->

                        <!--Start Five Relationships of a Product Owner Webinar-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/venkatesh-krishnamurthy.png" alt="Venkatesh Krishnamurthy" width="100%">
                                            <div class="overlay">
                                                <a href="five-relationships-of-a-product-owner-webinar-venkatesh-krishnamurthy-online-09-april-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Five Relationships of a Product Owner Webinar
                                        </p>
                                        <p class="training_topic_sub">
                                            1 Hour <br /> 09 April 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Five Relationships of a Product Owner Webinar-->

                        <!--Start Agile Metrics for Team and Product Progress Webinar-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/johanna-rothman.png" alt="Johanna Rothman" width="100%">
                                            <div class="overlay">
                                                <a href="agile-metrics-for-team-and-product-progress-webinar-johanna-rothman-online-29-march-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Agile Metrics for Team and Product Progress Webinar
                                        </p>
                                        <p class="training_topic_sub">
                                            1 Hour <br /> 29 March 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Agile Metrics for Team and Product Progress Webinar-->

                        <!--Start Priyank Leading SAFe 4.5-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Leading SAFe 4.5" width="100%">
                                            <div class="overlay">
                                                <a href="../events/leading-safe-4.5-with-sa-certification-priyank-pathak-bengaluru-26-27-march-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.5 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 26 - 27 March 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Leading SAFe 4.5-->

                        <!--Start Deploying Strategic Agility-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/karl-scotland.png" alt="DCA" width="100%">
                                            <div class="overlay">
                                                <a href="deploying-strategic-agility-workshop-karl-scotland-gurugram-25-march-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Deploying Strategic Agility Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            1 day course <br /> 25 March 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Deploying Strategic Agility-->

                        <!--Start Agile Gurugram 2018 Conference-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/AG18.png" alt="Agile Gurugram" width="100%">
                                            <div class="overlay">
                                                <a href="agile-gurugram-conference-23-24-march-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Agile Gurugram 2018 Conference
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day event<br /> 23 - 24 March 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Agile Gurugram 2018 Conference-->

                        <!--Start Priyank Leading SAFe 4.5-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Leading SAFe 4.5" width="100%">
                                            <div class="overlay">
                                                <a href="leading-safe-4.5-with-sa-certification-priyank-pathak-bengaluru-17-18-february-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.5 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 17 - 18 February 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Priyank Leading SAFe 4.5-->
                        
                        <!--Start Kanban System Design Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/brett-ansley.png" alt="Brett Ansley" width="100%">

                                            <div class="overlay">
                                                <a href="kanban-system-design-brett-ansley-bristol-united-kingdom-20-21-january-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Kanban System Design (KMP I) Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 20 - 21 January 2018
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Kanban System Design Workshop-->

                        <!--Start Innovative and Exploratory work with Kanban Webinar-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/brett-ansley.png" alt="Brett Ansley" width="100%">
                                            <div class="overlay">
                                                <a href="doing-innovative-exploratory-work-using-kanban-webinar-brett-ansley-online-15-december-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Innovative and Exploratory work with Kanban Webinar
                                        </p>
                                        <p class="training_topic_sub">
                                            1:30 Hours <br /> 15 December 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Innovative and Exploratory work with Kanban Webinar-->
                        
                        <!--Business and Enterprise Agility Conference (BEACON) 2017-->
<!--
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                            
                                            <div class="overlay">
                                                <a href="business-and-enterprise-agility-conference-priyank-pathak-hyderabad-02-december-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Business and Enterprise Agility Conference (BEACON) 2017
                                        </p>
                                        <p class="training_topic_sub">
                                            1 Hour <br />02 December 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
-->
                        <!--End Business and Enterprise Agility Conference (BEACON) 2017-->

                        <!--Start L.E.A.P w/ Continuous Delivery of SAFe 4.5-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/vikas-kapila.png" alt="Vikas Kapila" width="100%">
                                            <!--
                                            <div class="overlay">
                                                <a href="l.e.a.p-w-continuous-delivery-of-safe-4.5-webinar-vikas-kapila-online-17-november-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
-->
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            L.E.A.P w/ Continuous Delivery of SAFe<sup>&reg;</sup> 4.5 Webinar
                                        </p>
                                        <p class="training_topic_sub">
                                            1:15 Hours <br /> 17 November 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--Ends L.E.A.P w/ Continuous Delivery of SAFe 4.5-->

                        <!--Start Agendashift Debrief Webinar-->

                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/mike-burrows.png" alt="Mike Burrows" width="100%">
                                            <div class="overlay">
                                                <a href="agendashift-debrief-webinar-mike-burrows-online-27-october-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Agendashift Debrief Webinar
                                        </p>
                                        <p class="training_topic_sub">
                                            1 Hour <br /> 27 October 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--End Agendashift Debrief Webinar-->

                        <!--Start CA Presents: Implementing SAFe 4.5 | 23-26 October 2017-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/gerald-cadden.png" alt="SPC" width="100%">
                                            <div class="overlay">
                                                <a href="safe-program-consultant-workshop-gerald-cadden-bengaluru-23-26-october-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            CA Presents: Implementing SAFe<sup>&reg;</sup> 4.5 Workshop</p>
                                        <p class="training_topic_sub">
                                            4 day course <br /> 23 - 26 October 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End CA Presents: Implementing SAFe 4.5 | 23-26 October 2017-->
                        
                        <!--Start Team's Agility Assessment-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/prashant-mj.png" alt="Prashant MJ" width="100%">
                                            
                                            <div class="overlay">
                                                <a href="teams-agility-assessment-workshop-prashant-mj-bengaluru-14-october-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Team's Agility Assessment Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            1 Hour <br /> 14 October 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Team's Agility Assessment-->

                        <!--Start Lead an Enterprise-level Agile Transformation webinar-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/gerald-cadden.png" alt="Gerald Cadden" width="100%">
                                           
                                            <div class="overlay">
                                                <a href="how-to-lead-an-enterprise-level-lean-agile-transformation-as-a-safe-coach-webinar-gerald-cadden-online-11-october-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Lead an Enterprise-level Agile Transformation Webinar
                                        </p>
                                        <p class="training_topic_sub">
                                            1:30 Hours <br /> 11 October 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Lead an Enterprise-level Agile Transformation webinar-->

                        <!--Start Kanban Coaching Professional Masterclass 2017 Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/david-j-anderson.png" alt="David J Anderson" width="100%">
                                            <div class="overlay">
                                                <a href="kanban-coaching-professional-masterclass-david-j-anderson-bengaluru-18-22-september-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Kanban Coaching Professional Masterclass Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            5 day course <br /> 18 - 22 September 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Kanban Coaching Professional Masterclass 2017 Workshop-->

                        <!--Start Bengaluru Flow Days Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/bengaluru_flow_days.png" alt="Bengaluru_Flow_Days" width="100%">
                                            <div class="overlay">
                                                <a href="flow-days-workshop-patrick-steyaert-and-mike-burrows-bengaluru-17-18-september-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Bengaluru Flow Days Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 17 - 18 September 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Bengaluru Flow Days Workshop-->

                        <!--Start Lean Kanban India 2017-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/leankanbanindia-2017.png" alt="Lean Kanban India 2017" width="100%">
                                            <div class="overlay">
                                                <a href="lean-kanban-india-conference-bengaluru-15-16-september-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Lean Kanban India 2017 Conference
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day event <br /> 15 - 16 September 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Lean Kanban India 2017-->
                        
                        <!--Start Enterprise Transformation of a Telecom company using Kanban yet to review-->
<!--
                       <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                           <div class="training_listcard">
                               <div class="row">
                                   <div class="col-md-5 col-xs-5 img_hover_training">
                                       <div class="hovereffect_training">
                                           <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                           
                                           <div class="overlay">
                                               <a href="enterprise-transformation-of-a-telecom-company-using-kanban-workshop-priyank-pathak-bengaluru-15-september-2017/">
                                                   <p class="info">View</p>
                                               </a>
                                           </div>

                                       </div>
                                   </div>
                                   <div class="col-md-7 col-xs-7">
                                       <p class="training_topic">
                                           Enterprise Transformation of a Telecom company using Kanban
                                       </p>
                                       <p class="training_topic_sub">
                                           1 Hour <br />15 September 2017
                                       </p>
                                   </div>
                               </div>
                           </div>
                       </div>
-->
                       <!--End Enterprise Transformation of a Telecom company using Kanban-->

                        <!--Start Accredited Kanban-trainer-2017 Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/janice-linden-reed.png" alt="Janice Linden Reed" width="100%">
                                            <div class="overlay">
                                                <a href="accredited-kanban-trainer-janice-linden-reed-bengaluru-10-14-september-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Accredited Kanban Trainer Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            5 day course <br /> 10 - 14 September 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Accredited Kanban-trainer-2017 Workshop-->

                        <!--Start SAFe 4.0 Advanced Scrum Master-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/uday-atla.png" alt="Uday Atla" width="100%">

                                            <div class="overlay">
                                                <a href="safe-4.0-advanced-scrum-master-with-safe-advanced-scrum-master-certification-uday-atla-kolkata-02-03-september-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> 4.0 Advanced Scrum Master Workshop
                                            <p class="training_topic_sub">
                                                2 day course <br /> 02 - 03 September 2017
                                            </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe 4.0 Advanced Scrum Master-->

                        <!--Start Application Lifecycle Management with CA Tech webinar-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">                                            
                                            <div class="overlay">
                                                <a href="application-lifecycle-management-with-ca-agile-central-webinar-priyank-pathak-online-8-august-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Application Lifecycle Management with CA Agile Central Webinar
                                        </p>
                                        <p class="training_topic_sub">
                                            1 Hour <br /> 8 August 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Application Lifecycle Management with CA Tech webinar-->

                        <!--Start Leading SAFe 4.5-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">

                                            <div class="overlay">
                                                <a href="leading-safe-4.5-with-sa-certification-priyank-pathak-bengaluru-05-06-august-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.5 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 Day Course <br /> 05 - 06 August 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Leading SAFe 4.5-->

                        <!--Start [Meetup] - Continuous Delivery Meetup Series-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/meetups.png" alt="Meet Up" width="100%">

                                            <div class="overlay">
                                                <a href="continuous-delivery-meetup-bengaluru-22-july-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Continuous Delivery Meetup
                                        </p>
                                        <p class="training_topic_sub">
                                            3 Hours <br /> 22 July 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--Ends Continuous Delivery Meetup-->
                        
                        <!--Start Agile Leadership Summit Workshop-->
                       <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                           <div class="training_listcard">
                               <div class="row">
                                   <div class="col-md-5 col-xs-5 img_hover_training">
                                       <div class="hovereffect_training">
                                           <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                           
                                           <div class="overlay">
                                               <a href="agile-leadership-summit-workshop-priyank-pathak-bengaluru-20-july-2017/">
                                                   <p class="info">View</p>
                                               </a>
                                           </div>

                                       </div>
                                   </div>
                                   <div class="col-md-7 col-xs-7">
                                       <p class="training_topic">
                                           Agile Leadership Summit Workshop
                                       </p>
                                       <p class="training_topic_sub">
                                           1 Hour <br /> 20 July 2017
                                       </p>
                                   </div>
                               </div>
                           </div>
                       </div>
                       <!--End Agile Leadership Summit Workshop-->

                        <!--Start "DevOps > CI + CD", Continuous Delivery Webinar-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/sudipta-lahiri.png" alt="Sudipta Lahiri" width="100%">                                            
                                            <div class="overlay">
                                                <a href="devops-ci-cd-continuous-delivery-webinar-sudipta-lahiri-online-12-July-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            DevOps > CI + CD Continuous Delivery Webinar
                                        </p>
                                        <p class="training_topic_sub">
                                            1 Hour <br /> 12 July 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--DevOps > CI + CD", Continuous Delivery Webinar-->
                        
                        <!--Start SAFe 4.0 Advanced Scrum Master-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">

                                            <div class="overlay">
                                                <a href="safe-4.0-advanced-scrum-master-with-safe-advanced-scrum-master-certification-priyank-pathak-bengaluru-29-30-may-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> 4.0 Advanced Scrum Master Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 29 - 30 May 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe 4.0 Advanced Scrum Master-->

                        <!--Start Cynefin and Complexity Masterclass-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/dave_snowden.png" alt="Dave Snowden" width="100%">

                                            <div class="overlay">
                                                <a href="cynefin-and-complexity-masterclass-for-agile-practitioner-dave-snowden-gurugram-27-28-may-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Cynefin and Complexity Masterclass
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 27 - 28 May 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Cynefin and Complexity Masterclass-->
                        
                        <!--Start Team's Agility Assessment-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/prashant-mj.png" alt="Prashant MJ" width="100%">
                                            
                                            <div class="overlay">
                                                <a href="teams-agility-assessment-workshop-prashant-mj-gurugram-27-may-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Team's Agility Assessment Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            1 Hour <br /> 27 May 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Team's Agility Assessment-->

                        <!--Start Agile Gurugram 2017 Conference-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/AG17.png" alt="Agile Gurugram 2017" width="100%">

                                            <div class="overlay">
                                                <a href="agile-gurugram-conference-26-27-may-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Agile Gurugram 2017 Conference
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day event<br /> 26 - 27 May 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Agile Gurugram 2017 Conference-->
                        
                          <!--Start Lean Agile Performance Management in Action-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/thriveni-shetty.png" alt="Thriveni Shetty" width="100%">
                                            
                                            <div class="overlay">
                                                <a href="lean-agile-performance-management-in-action-workshop-thriveni-shetty-gurugram-26-may-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Lean Agile Performance Management in Action Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            30 Minutes session <br /> 26 May 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Lean Agile Performance Management in Action-->

                        <!--Start CA Presents: Implementing SAFe 4.5 | 22-25 May 2017 -->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/gerald-cadden.png" alt="SPC" width="100%">
                                            <div class="overlay">
                                                <a href="safe-program-consultant-workshop-gerald-cadden-gurugram-22-25-may-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            CA Presents: Implementing SAFe<sup>&reg;</sup> 4.5 Workshop</p>
                                        <p class="training_topic_sub">
                                            4 day course <br /> 22 - 25 May 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End CA Presents: Implementing SAFe 4.5 | 22-25 May 2017-->

                        <!--Start Priyank SAFe 4.0 POPM-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">

                                            <div class="overlay">

                                                <a href="safe-4.0-product-owner-product-manager-workshop-priyank-pathak-gurugram-11-12-may-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> 4.0 Product Owner/Product Manager Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 11 - 12 May 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe 4.0 POPM-->

                        <!--Start Priyank POPM-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                            <div class="overlay">
                                                <a href="safe-4.0-product-owner-product-manager-workshop-priyank-pathak-bengaluru-23-24-april-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> 4.0 Product Owner/Product Manager Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 23 - 24 April 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Priyank POPM-->

                        <!--Start SAFe 4.0 Advanced Scrum Master-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">

                                            <div class="overlay">
                                                <a href="safe-4.0-advanced-scrum-master-with-safe-advanced-scrum-master-certification-priyank-pathak-bengaluru-11-12-april-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> 4.0 Advanced Scrum Master Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 11 - 12 April 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe 4.0 Advanced Scrum Master-->

                        <!--Start Leading SAFe 4.0-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                            <div class="overlay">
                                                <a href="leading-safe-4.0-workshop-priyank-pathak-bengaluru-26-27-march-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.0 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 26 - 27 March 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Leading SAFe 4.0-->

                        <!--Start Priyank SAFe 4.0 POPM-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">

                                            <div class="overlay">

                                                <a href="safe-4.0-product-owner-product-manager-workshop-priyank-pathak-bengaluru-11-12-march-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> 4.0 Product Owner/Product Manager Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 11 - 12 March 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe 4.0 POPM-->
                        
                        <!--Start SAFe 4.0 Product Owner/Product Manager (POPM)-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                            <div class="overlay">
                                                <a href="safe-4.0-product-owner-product-manager-workshop-priyank-pathak-gurugram-27-28-february-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe 4.0 Product Owner/Product Manager (POPM) Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 27 - 28 February 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe 4.0 Product Owner/Product Manager (POPM):-->


                        <!--Start Priyank Leading SAFe 4.0-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                            <div class="overlay">
                                                <a href="leading-safe-4.0-workshop-priyank-pathak-mumbai-25-26-feb-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.0 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 25 - 26 February 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Leading SAFe 4.0-->

                        <!--Start Leading SAFe 4.0-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">

                                            <div class="overlay">

                                                <a href="leading-safe-4.0-workshop-priyank-pathak-bengaluru-11-12-feb-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.0 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 11 - 12 February 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Leading SAFe 4.0-->

                        <!--Start Priyank SAFe 4.0 SASM-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                            <div class="overlay">
                                                <a href="safe-4.0-advanced-scrum-master-with-safe-advanced-scrum-master-certification-priyank-pathak-bengaluru-21-22-january-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> 4.0 Advanced Scrum Master Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 21 - 22 January 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe 4.0 SASM-->

                        <!--Start Priyank Leading SAFe 4.0 -->

                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                            <div class="overlay">
                                                <a href="leading-safe-4.0-workshop-priyank-pathak-bengaluru-14-15-jan-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.0 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 14 - 15 January 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--End Leading SAFe 4.5-->

                        <!--Start Priyank Leading SAFe 4.0-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">

                                            <div class="overlay">

                                                <a href="leading-safe-4.0-workshop-priyank-pathak-kolkata-07-08-jan-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.0 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 07 - 08 January 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe Leading SAFe 4.0-->
                        
                        <!--Start Team's Agility Assessment-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/prashant-mj.png" alt="Prashant MJ" width="100%">
                                            
                                            <div class="overlay">
                                                <a href="teams-agility-assessment-workshop-prashant-mj-pune-07-january-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Team's Agility Assessment Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            1 Hour <br /> 07 January 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Team's Agility Assessment-->
                        
                        <!--Start Kanban Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/thriveni-shetty.png" alt="Thriveni Shetty" width="100%">                                        
                                            <div class="overlay">
                                                <a href="kanban-workshop-thriveni-shetty-pune-7-january-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Kanban Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            1 Hour <br /> 07 January 2017
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Kanban Workshop-->

                        <!--Start SAFe 4.0 Advanced Scrum Master-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">

                                            <div class="overlay">

                                                <a href="safe-4.0-advanced-scrum-master-with-safe-advanced-scrum-master-certification-priyank-pathak-bengaluru-24-25-december-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> 4.0 Advanced Scrum Master Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 24 - 25 December 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe 4.0 Advanced Scrum Master-->
                        
                        <!--Start Kanban Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/thriveni-shetty.png" alt="Thriveni Shetty" width="100%">                                     
                                            <div class="overlay">
                                                <a href="kanban-workshop-thriveni-shetty-noida-17-december-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Kanban Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            1 Hour <br /> 17 December 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Kanban Workshop-->

                        <!--Start Priyank Leading SAFe 4.0-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                            <div class="overlay">
                                                <a href="leading-safe-4.0-workshop-priyank-pathak-bengaluru-03-04-dec-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.0 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 03 - 04 December 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Leading SAFe 4.0-->

                        <!--Start Heart of Agile Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/alistair.png" alt="Dr. Alistair Cockburn" width="100%">
                                            <div class="overlay">
                                                <a href="heart-of-agile-workshop-dr.alistair-cockburn-pune-bengaluru-hyderabad-24-26-october-2017/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Heart of Agile Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            1 day course <br /> 24 - 26 October 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Heart of Agile Workshop-->

                        <!--Start Priyank SAFe 4.0 POPM-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">

                                            <div class="overlay">

                                                <a href="safe-4.0-product-manager-product-owner-workshop-priyank-pathak-bengaluru-15-16-oct-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> 4.0 Product Manager/Product Owner Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 15 - 16 October 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe 4.0 POPM-->

                        <!--Start Priyank Leading SAFe 4.0-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">

                                            <div class="overlay">
                                                <a href="leading-safe-4.0-workshop-priyank-pathak-bengaluru-01-02-oct-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.0 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 01 - 02 October 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Leading SAFe 4.0-->

                        <!--Start SAFe 4.0 Advanced Scrum Master-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">

                                            <div class="overlay">

                                                <a href="safe-4.0-advanced-scrum-master-with-safe-advanced-scrum-master-certification-priyank-pathak-bengaluru-28-29-september-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> 4.0 Advanced Scrum Master Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 28 - 29 September 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe 4.0 Advanced Scrum Master-->

                        <!--Start Leading SAFe 4.0-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">

                                            <div class="overlay">
                                                <a href="leading-safe-4.0-workshop-priyank-pathak-bengaluru-26-27-september-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.0 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 26 - 27 September 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Leading SAFe 4.0-->

                        <!--Start Priyank SAFe 4.0 SASM-->
                        <!--
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                            
                                            <div class="overlay">

                                                <a href="safe-4.0-advanced-scrum-master-with-safe-advanced-scrum-master-certification-priyank-pathak-bengaluru-24-25-september-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> 4.0 Advanced Scrum Master Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 24 - 25 September 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
-->
                        <!--End SAFe 4.0 SASM-->

                        <!--Start Lean Product Development Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/donald.png" alt="Donal Reinertsen" width="100%">
                                            <div class="overlay">
                                                <a href="lean-product-development-workshop-donal-reinertsen-bengaluru-12-13-september-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Lean Product Development Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 12 - 13 September 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Lean Product Development Workshop-->

                        <!--Start Kanban System Design Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/mike-leber.png" alt="Mike Leber" width="100%">
                                            <div class="overlay">
                                                <a href="kanban-management-professional-mike-leber-bengaluru-11-12-september-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Kanban Management Professional (KMP II) Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 11 - 12 September 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Kanban System Design Workshop-->
                        
                          <!--Start Kanban Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                            <div class="overlay">
                                                <a href="Kanban-workshop-priyank-pathak-bengaluru-10-september-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Kanban Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 Hours <br /> 10 September 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Kanban Workshop-->

                        <!--Start Lean Kanban India 2016-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/leankanbanindia-2016.png" alt="Lean Kanban India 2016" width="100%">

                                            <div class="overlay">
                                                <a href="lean-kanban-india-conference-bengaluru-9-10-september-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Lean Kanban India 2016 Conference
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day event <br /> 09 - 10 September 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Lean Kanban India 2016-->

                        <!--Start Kanban System Design Workshop-->
                        <!--
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/alok-upadhya.png" alt="Alok Upadhya" width="100%">
                                            <div class="overlay">
                                                <a href="kanban-system-design-alok-upadhya-bengaluru-07-08-september-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Kanban System Design
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 07 - 08 September 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
-->
                        <!--End Kanban System Design Workshop-->

                        <!--Start Kanban System Design Workshop-->
                        <!--
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/mike-leber.png" alt="Mike Leber" width="100%">                                            
                                            <div class="overlay">
                                                <a href="kanban-system-design-mike-leber-bengaluru-07-08-september-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Kanban System Design (KMP I) Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 07 - 08 September 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
-->
                        <!--End Kanban System Design Workshop-->

                        <!--Start Kanban Coaching Professional Masterclass 2016 Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/david-j-anderson.png" alt="David J Anderson" width="100%">
                                            <div class="overlay">
                                                <a href="kanban-coaching-professional-masterclass-david-j-anderson-bengaluru-04-08-september-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Kanban Coaching Professional Masterclass Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            5 day course <br />04 - 08 September 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Kanban Coaching Professional Masterclass 2016 Workshop-->

                        <!--Start Accredited Kanban-trainer-2016 Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/janice-linden-reed.png" alt="Janice Linden Reed" width="100%">
                                            <div class="overlay">
                                                <a href="accredited-kanban-trainer-janice-linden-reed-bengaluru-04-08-september-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Accredited Kanban Trainer Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            5 day course <br /> 04 - 08 September 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Accredited Kanban-trainer-2016 Workshop-->
                        <!--Start Kanban Postcard Game-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/thriveni-shetty.png" alt="Thriveni Shetty" width="100%">                                       
                                            <div class="overlay">
                                                <a href="kanban-postcard-game-workshop-thriveni-shetty-bengaluru-3-september-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Kanban Postcard Game Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            1 Hour <br /> 3 September 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Kanban Postcard Game-->

                        <!--Start Leading SAFe 4.5-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                            <div class="overlay">
                                                <a href="leading-safe-4.0-workshop-priyank-pathak-kolkata-22-23-august-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.0 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 Day Course <br /> 22 - 23 August 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Leading SAFe 4.5-->

                        <!--Start SAFe 4.0 Product Owner/Product Manager-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                            <div class="overlay">
                                                <a href="safe-4.0-product-manager-product-owner-workshop-priyank-pathak-bengaluru-30-31-july-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> 4.0 Product Manager/Product Owner Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 30 - 31 July 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe 4.0 Product Owner/Product Manager-->

                        <!--Start Agile Gurugram 2016 Conference-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/AG16.png" alt="Agile Gurugram 2017" width="100%">
                                            <div class="overlay">
                                                <a href="agile-gurgaon-conference-27-28-may-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Agile Gurgaon 2016 Conference
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day event<br /> 27 - 28 May 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Agile Gurugram 2016 Conference-->
                        
                        <!--Start What is Next ?-->
                       <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                           <div class="training_listcard">
                               <div class="row">
                                   <div class="col-md-5 col-xs-5 img_hover_training">
                                       <div class="hovereffect_training">
                                           <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                           
                                           <div class="overlay">
                                               <a href="what-is-next-keynote-priyank-pathak-gurgaon-27-28-may-2016/">
                                                   <p class="info">View</p>
                                               </a>
                                           </div>
                                       </div>
                                   </div>
                                   <div class="col-md-7 col-xs-7">
                                       <p class="training_topic">
                                           What is Next ? - Keynote
                                       </p>
                                       <p class="training_topic_sub">
                                           2 day course <br />27 - 28 May 2016
                                       </p>
                                   </div>
                               </div>
                           </div>
                       </div>
                       <!--End What is Next ?-->
                        
                        <!--Start Certified Scrum Master-2015 Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/kok-ewe-siew.png" alt="Kok Ewe Siew" width="100%">
                                            <div class="overlay">
                                                <a href="certified-scrum-master-kok-ewe-siew-gurgoan-25-26-may-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Certified Scrum Master Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 25 - 26 May 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Certified Scrum Master-2015 Workshop-->

                        <!--Start Leading SAFe 4.5 blocked version-->
                        <!--
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priank Pathak" width="100%">
                                            
                                            <div class="overlay">
                                                <a href="leading-safe4.5-with-sa-certification-priyank-pathak-gurugram-23-24-may-2016/" target="_blank">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.5 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course<br /> 23 - 24 May 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
-->
                        <!--End Leading SAFe 4.5-->
                        
                        <!--Start Priyank Leading SAFe 4.5-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Leading SAFe 4.5" width="100%">
                                            <div class="overlay">
                                                <a href="leading-safe-4.5-with-sa-certification-priyank-pathak-bengaluru-29-30-april-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.5 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 29 - 30 April 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Priyank Leading SAFe 4.5-->
                        
                        <!--Start Leading SAFe 4.0-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                            <div class="overlay">
                                                <a href="leading-safe-4.0-workshop-priyank-pathak-pune-22-23-march-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Leading SAFe<sup>&reg;</sup> 4.0 Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 22 - 23 March 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Leading SAFe 4.0-->

                        <!--Start SAFe 4.0 Product Owner/Product Manager-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">

                                            <div class="overlay">
                                                <a href="safe-4.0-product-manager-product-owner-workshop-priyank-pathak-pune-20-21-feb-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> 4.0 Product Manager/Product Owner Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 20 - 21 Feb 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe 4.0 Product Owner/Product Manager-->
                        
                        <!--Start Scrum Framework Basics: from where to start ?-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/meetups.png" alt="Prashant MJ" width="100%">
                                            <div class="overlay">
                                                <a href="scrum-framework-basics-from-where-to-start-meetup-gugaon-19-feb-2016/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Scrum Framework Basics: from where to start?
                                        </p>
                                        <p class="training_topic_sub">
                                            5 Hours <br /> 19 Feb 2016
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Scrum Framework Basics: from where to start ?-->

                        <!--Start Accredited Kanban-trainer-2015 Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/david-j-anderson.png" alt="David-J Anderson" width="100%">
                                            <div class="overlay">
                                                <a href="accredited-kanban-trainer-david-j-anderson-bengaluru-14-18-december-2015/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Accredited Kanban Trainer Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            5 day course <br /> 14 - 18 December 2015
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Accredited Kanban-trainer-2015 Workshop-->

                        <!--Start Lean Kanban India 2015-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/leankanbanindia-2015.png" alt="Lean Kanban India 2015" width="100%">
                                            <div class="overlay">
                                                <a href="lean-kanban-india-conference-bengaluru-11-12-december-2015/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Lean Kanban India 2015 Conference
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day event <br /> 11 - 12 December 2015
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Lean Kanban India 2015-->
                        
                        <!--Start Alternative Path for Transformation-->
                       <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                           <div class="training_listcard">
                               <div class="row">
                                   <div class="col-md-5 col-xs-5 img_hover_training">
                                       <div class="hovereffect_training">
                                           <img class="img-responsive img_training" src="../inc/assets/img/events/priyank-pathak.png" alt="Priyank Pathak" width="100%">
                                           
                                           <div class="overlay">
                                               <a href="alternative-path-for-transformation-workshop-priyank-pathak-bengaluru-11-december-2015/">
                                                   <p class="info">View</p>
                                               </a>
                                           </div>

                                       </div>
                                   </div>
                                   <div class="col-md-7 col-xs-7">
                                       <p class="training_topic">
                                           Alternative Path for Transformation
                                       </p>
                                       <p class="training_topic_sub">
                                           1 Hour <br />11 December 2015
                                       </p>
                                   </div>
                               </div>
                           </div>
                       </div>
                       <!--End Alternative Path for Transformation-->

                        <!--Start Kanban System Design Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/mike-leber.png" alt="Mike Leber" width="100%">

                                            <div class="overlay">
                                                <a href="kanban-system-design-mike-leber-bengaluru-09-10-december-2015/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Kanban System Design (KMP I) Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 09 - 10 December 2015
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Kanban System Design Workshop-->

                        <!--Start Certified Scrum Master-2015 Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/kok-ewe-siew.png" alt="Kok Ewe Siew" width="100%">
                                            <div class="overlay">
                                                <a href="certified-scrum-master-kok-ewe-siew-hyderabad-28-29-november-2015/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Certified Scrum Master Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 28 - 29 November 2015
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Certified Scrum Master-2015 Workshop-->

                        <!--Start Certified Scrum Master-2016 Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/kok-ewe-siew.png" alt="Kok Ewe Siew" width="100%">
                                            <div class="overlay">
                                                <a href="certified-scrum-master-kok-ewe-siew-bengaluru-28-29-september-2015/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Certified Scrum Master Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 28 - 29 September 2015
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Certified Scrum Master-2016 Workshop-->

                        <!--Start Certified Scrum Master-2015 Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/kok-ewe-siew.png" alt="Kok Ewe Siew" width="100%">
                                            <div class="overlay">
                                                <a href="certified-scrum-master-kok-ewe-siew-bengaluru-10-11-august-2015/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Certified Scrum Master Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 10 - 11 August 2015
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Certified Scrum Master-2015 Workshop-->

                        <!--Start SAFe Program Consultant (SPC)-2015 Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/michael-stump.png" alt="Michael Stump" width="100%">
                                            <div class="overlay">
                                                <a href="safe-3.0-program-consultant(spc)-workshop-michael-stump-and-priyank-pathak-bengaluru-07-10-july-2015/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> Program Consultant (SPC) Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            4 day course <br /> 07 - 10 July 2015
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe Program Consultant (SPC)-2015 Workshop-->
                        
                        <!--Start Kanban System Design Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/sanjeev-raman.png" alt="Sanjeev Raman" width="100%">
                                            <div class="overlay">
                                                <a href="kanban-system-design-sanjeev-raman-bengaluru-15-16-june-2015/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Kanban System Design (KMP I) Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 15 - 16 June 2015
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Kanban System Design Workshop-->

                        <!--Start SAFe Program Consultant and Certification (SPC)-2015 Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/tamara-nation.png" alt="Tamara Nation" width="100%">

                                            <div class="overlay">
                                                <a href="safe-3.0-program-consultant(spc)-workshop-tamara-nation-and-priyank-pathak-bengaluru-31-march-3-april-2015/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> Program Consultant (SPC) Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            4 day course <br /> 31 March - 03 April 2015
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe Program Consultant and Certification (SPC)-2015 Workshop-->

                        <!--Start Agile India 2015-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/agile-india-2015.png" alt="Agile India 2015" width="100%">
                                            <div class="overlay">
                                                <a href="agile-india-conference-bengaluru-23-30-march-2015/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Agile India 2015 Conference
                                        </p>
                                        <p class="training_topic_sub">
                                            8 day event <br /> 23 - 30 March 2015
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Agile India 2015-->

                        <!--Start Management 3.0-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/saket-biwalkar.png" alt="Saket Biwalkar" width="100%">
                                            <!--
                                            <div class="overlay">

                                                <a href="../events/leading-safe4.5-with-sa-certification-priyank-pathak-bengaluru-26-27-march-2018/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
-->
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Management 3.0
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day course <br /> 30 - 31 January 2015
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Management 3.0-->                        

                        <!--Start SAFe Program Consultant (SPC)-2014-2015 Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/siraj-sirajuddin.png" alt="Siraj Sirajuddin" width="100%">
                                            <div class="overlay">
                                                <a href="safe-3.0-program-consultant(spc)-workshop-siraj-sirajuddin-and-priyank-pathak-bengaluru-29-december-2014-1-January-2015/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> Program Consultant (SPC) Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            4 day course <br /> 29 Dec 2014 - 01 Jan 2015
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe Program Consultant (SPC)-2014-2015 Workshop-->

                        <!--Start Lean Kanban India 2014-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/leankanbanindia-2014.png" alt="Lean Kanban India 2014" width="100%">
                                            <div class="overlay">
                                                <a href="lean-kanban-india-apac-conference-bengaluru-11-12-december-2014/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            Lean Kanban India APAC 2014 Conference
                                        </p>
                                        <p class="training_topic_sub">
                                            2 day event <br /> 11 - 12 December 2014
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Lean Kanban India 2014-->

                        <!--Start SAFe Program Consultant (SPC)-2014 Workshop-->
                        <div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
                            <div class="training_listcard">
                                <div class="row">
                                    <div class="col-md-5 col-xs-5 img_hover_training">
                                        <div class="hovereffect_training">
                                            <img class="img-responsive img_training" src="../inc/assets/img/events/michael-stump.png" alt="Michael Stump" width="100%">

                                            <div class="overlay">
                                                <a href="safe-3.0-program-consultant(spc)-workshop-michael-stump-and-priyank-pathak-bengaluru-16-19-september-2014/">
                                                    <p class="info">View</p>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-7 col-xs-7">
                                        <p class="training_topic">
                                            SAFe<sup>&reg;</sup> Program Consultant (SPC) Workshop
                                        </p>
                                        <p class="training_topic_sub">
                                            4 day course <br /> 16 - 19 September 2014
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End SAFe Program Consultant (SPC)-2014 Workshop-->

                    </div>
                </div>
            </div>
        </section>
        <!--End Archived Events-->
        <?php include('../includes/footer.php');?>

        <!--start pure chat-->
        <script type='text/javascript' data-cfasync='false'>
            window.purechatApi = {
                l: [],
                t: [],
                on: function() {
                    this.l.push(arguments);
                }
            };
            (function() {
                var done = false;
                var script = document.createElement('script');
                script.async = true;
                script.type = 'text/javascript';
                script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
                document.getElementsByTagName('HEAD').item(0).appendChild(script);
                script.onreadystatechange = script.onload = function(e) {
                    if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
                        var w = new PCWidget({
                            c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
                            f: true
                        });
                        done = true;
                    }
                };
            })();

        </script>
        <!--end pure chat-->

    </body>

    </html>
