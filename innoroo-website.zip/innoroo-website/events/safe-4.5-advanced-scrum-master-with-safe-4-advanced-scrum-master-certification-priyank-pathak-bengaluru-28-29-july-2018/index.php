<!--Updated On 28-03-2018GA
meta tag updated
-->

<!DOCTYPE html>
<html class="full" lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
	
	<title>INNOVATION ROOTS | Events | SAFe 4.5 Advanced Scrum Master with SAFe 4 Advanced Scrum Master Certification Priyank Pathak Bengaluru 28 - 29 July 2018</title>

	<meta http-equiv="X-UA-Compatible" content="" IE="edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="The two-day Technical SAFe® Advanced Scrum Master (SASM) course mainly describes on providing existing Scrum Masters, the path to enhance their Scrum knowledge to the Enterprise Level.This course covers the entire spectrum that includes: Leadership Skills, facilitating Cross-Team Interactions to support Program Execution and Relentless Improvement.">
	<meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
     
	<!-- OPEN GRAPH META TAG STARTS -->	
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->
    
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
	<link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="../../inc/assets/css/main.css" rel="stylesheet" />
	<script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
	<link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
	<script>
		(function(d, e, j, h, f, c, b) {
			d.GoogleAnalyticsObject = f;
			d[f] = d[f] || function() {
				(d[f].q = d[f].q || []).push(arguments)
			}, d[f].l = 1 * new Date();
			c = e.createElement(j), b = e.getElementsByTagName(j)[0];
			c.async = 1;
			c.src = h;
			b.parentNode.insertBefore(c, b)
		})(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
		ga("create", "UA-100332682-2", "auto");
		ga("send", "pageview");

	</script>
	<script type=text/javascript>
		document.oncontextmenu = new Function("return false");
		document.onselectstart = new Function("return false");
		if (window.sidebar) {
			document.onmousedown = new Function("return false");
			document.onclick = new Function("return true");
			document.oncut = new Function("return false");
			document.oncopy = new Function("return false");
			document.onpaste = new Function("return false")
		};

	</script>
</head>

<body>
	<?php include('../../includes/header.php'); ?>
    <section class="section_margin_gen_training section_training_banner safe_class">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-9 col-xs-12">
                    <h2 class="sectionTitle class_font">SAFe<sup>&reg;</sup> 4.5 Advanced Scrum Master with SAFe<sup>&reg;</sup> 4 Advanced Scrum Master Certification</h2>
                    <h3 class="sectionSubtitle class_font">[ Effective Leadership skills to lead the Enterprise Transformation ]</h3>
                </div>
                <div class="col-sm-3 col-xs-12">
                    <div class="reg_section_bg">
                        <div class="reg_training_sec">
                            <h4 class="reg_section">28 - 29 July 2018</h4>
                            <h4 class="reg_section">2 Day Workshop</h4>
                            <h4 class="reg_section"><b>Bengaluru</b></h4>
                        </div>
                        <a href="https://www.goeventz.com/event/safe-4.5-advanced-scrum-master-with-sasm-certification/70148" target="_blank" class="training_register">Register</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
	<section class="section_margin_gen_training">
		<div class="container">
			<div class="col-sm-12 col-xs-12 padding0">
				<div class="col-sm-12 col-xs-12">
					<h2 class="sectionTitle margin_top_gen">
						Overview
					</h2>
					<p class="para_training">
						The two-day SAFe<sup>&reg;</sup> Advanced Scrum Master (SASM) course focuses on providing existing Scrum Masters, the path to enhance their Scrum knowledge to the enterprise level. Eventually, helping them amplify their contribution to enterprise success in a SAFe<sup>&reg;</sup> implementation. This course covers the entire spectrum that includes: leadership skills, facilitating cross-team interactions to support program execution and relentless improvement.
					</p>
					<p class="para_training">
						After attending this course, participants will learn how to intensify the Scrum paradigm by introducing Scalable Engineering and DevOps practices. The course also helps in understanding the application of Kanban to facilitate the flow of values and supports interactions with architects, product management, and other critical stakeholders in context of larger programs and enterprise. The course provides the tool of action that help build high-performance teams that express practical methods of dealing with Agile and Scrum Anti-Patterns.
					</p>
				</div>
			</div>
		</div>
	</section>
	<section class="section_margin_gen_training section_training_requirements">
		<div class="container">
			<div class="col-sm-12 col-xs-12 padding0">
				<div class="col-sm-6 col-xs-12">
						<div class="col-sm-1 col-xs-1 padding0 icon-align-center">
							<i class="fa fa-hourglass-half fa_training fa-2x" aria-hidden="true"></i>
						</div>
						<div class="col-sm-11 col-xs-11">
							<h5 class="training_requirement_title1">Duration</h5>
							<h6 class="training_requirement_title1">2 Days (16 Hours)</h6>
						</div>
					</div>
				<div class="col-sm-6 col-xs-12">
						<div class="col-sm-1 col-xs-1 padding0 icon-align-center">
							<i class="fa fa-clock-o fa_training fa-2x" aria-hidden="true"></i>
						</div>
						<div class="col-sm-11 col-xs-11">
							<h5 class="training_requirement_title1">Timing</h5>
							<h6 class="training_requirement_title1">9 AM to 6 PM Each day (1 Hour break in between)</h6>
						</div>
					</div>
				<div class="border_seperator"></div>
			</div>
			<div class="col-sm-12 col-xs-12 padding0">
				<div class="col-sm-6 col-xs-12">
						<div class="col-sm-1 col-xs-1 padding0 icon-align-center">
							<i class="fa fa-user-o fa_training fa-2x" aria-hidden="true"></i>
						</div>
						<div class="col-sm-11 col-xs-11">
							<h5 class="training_requirement_title1">Presenter</h5>
							<h6 class="training_requirement_title1">Priyank Pathak</h6>
						</div>
					</div>
				<div class="col-sm-6 col-xs-12">
						<div class="col-sm-1 col-xs-1 padding0 icon-align-center">
							<i class="fa fa-group fa_training fa-2x" aria-hidden="true"></i>
						</div>
						<div class="col-sm-11 col-xs-11">
							<h5 class="training_requirement_title1">Batch Size</h5>
							<h6 class="training_requirement_title1">Max 30 participants</h6>
						</div>
						</div>
				<div class="border_seperator"></div>
			</div>
			<div class="col-sm-12 col-xs-12 padding0">
				<div class="col-sm-6 col-xs-12">
						<div class="col-sm-1 col-xs-1 padding0 icon-align-center">
							<i class="fa fa-id-badge fa_training fa-2x" aria-hidden="true"></i>
						</div>
						<div class="col-sm-11 col-xs-11">
							<h5 class="training_requirement_title1">Participants Profile</h5>
							<h6 class="training_requirement_title1">Intermediate</h6>
						</div>
					</div>
				<div class="col-sm-6 col-xs-12">
						<div class="col-sm-1 col-xs-1 padding0 icon-align-center">
							<i class="fa fa-tasks fa_training fa-2x" aria-hidden="true"></i>
						</div>
						<div class="col-sm-11 col-xs-11">
							<h5 class="training_requirement_title1">Prerequisite</h5>
							<h6 class="training_requirement_title1">Recommended to be certified as SAFe<sup>&reg;</sup> Scrum Master/Certified Scrum Master/Professional Scrum Master</h6>
						</div>
					</div>
				<div class="border_seperator"></div>
			</div>
			<div class="col-sm-12 col-xs-12 padding0">
				<div class="col-sm-6 col-xs-12">
						<div class="col-sm-1 col-xs-1 padding0 icon-align-center">
							<i class="fa fa-language fa_training fa-2x" aria-hidden="true"></i>
						</div>
						<div class="col-sm-11 col-xs-11">
							<h5 class="training_requirement_title1">Course Delivery Language</h5>
							<h6 class="training_requirement_title1">English</h6>
						</div>
					</div>
				<div class="col-sm-6 col-xs-12">
						<div class="col-sm-1 col-xs-1 padding0 icon-align-center">
							<span class="glyphicon glyphicon-blackboard fa_training fa-2x"></span>
						</div>
						<div class="col-sm-11 col-xs-11">
							<h5 class="training_requirement_title1">Approach of Delivery</h5>
							<h6 class="training_requirement_title1">Mix of theory and workshop sessions (Classroom Training)</h6>
						</div>
					</div>
				<div class="border_seperator"></div>
			</div>
			<div class="col-sm-12 col-xs-12 padding0">
				<div class="col-sm-6 col-xs-12">
						<div class="col-sm-1 col-xs-1 padding0 icon-align-center">
							<i class="fa fa-graduation-cap fa_training fa-2x" aria-hidden="true"></i>
						</div>
						<div class="col-sm-11 col-xs-11">
							<h5 class="training_requirement_title1">Certification Details</h5>
							<h6 class="training_requirement_title1">Attending the course will enable participants to take the exam and become a certified SAFe<sup>&reg;</sup> Advanced Scrum Master (SASM)</h6>
						</div>
					</div>
				<div class="col-sm-6 col-xs-12">
						<div class="col-sm-1 col-xs-1 padding0 icon-align-center">
							<i class="fa fa-university fa_training fa-2x" aria-hidden="true"></i>
						</div>
						<div class="col-sm-11 col-xs-11">
							<h5 class="training_requirement_title1">Accreditation Institute</h5>
							<h6 class="training_requirement_title1">Scaled Agile Academy</h6>
						</div>
					</div>
				<div class="border_seperator"></div>
			</div>
			<div class="col-sm-12 col-xs-12 padding0">
				<div class="col-sm-6 col-xs-12">
						<div class="col-sm-1 col-xs-1 padding0 icon-align-center">
							<i class="fa fa-handshake-o fa_training fa-2x" aria-hidden="true"></i>
						</div>
						<div class="col-sm-11 col-xs-11">
							<h5 class="training_requirement_title1">Commercials & Logistics</h5>
							<h6 class="training_requirement_title1">Contact us for Quotations</h6>
						</div>
					</div>
			</div>
		</div>
	</section>
	<section class="section_margin_gen_training">
		<div class="container">
			<div class="col-sm-12 col-xs-12 padding0">
				<div class="col-sm-12 col-xs-12">
					<h2 class="sectionTitle margin_top_gen">
						Agenda
					</h2>
					<ul>
						<li class="training_li_list">Understand SAFe<sup>&reg;</sup> Framework, values, and Lean-Agile principles</li>
						<li class="training_li_list">Scrum Master roles and responsibilities in SAFe<sup>&reg;</sup> environment</li>
						<li class="training_li_list">Apply SAFe<sup>&reg;</sup> principles with the perspective of a Scrum Master</li>
						<li class="training_li_list">Analyze Agile and Scrum anti-patterns</li>
						<li class="training_li_list">Use Kanban for facilitating teamwork and visualizing flow of work</li>
						<li class="training_li_list">Build high-performing teams</li>
						<li class="training_li_list">Interact with the system team, deployment, UX, Architects, Product Owners, Product Managers, and Business Owners</li>
						<li class="training_li_list">Apply Inspect and Adapt to improve Program Performance</li>
					</ul>
				</div>
				<div class="col-sm-12 col-xs-12">
					<h2 class="sectionTitle margin_top_gen">
						Learning Objective
					</h2>
					<ul>
						<li class="training_li_list">Application of SAFe<sup>&reg;</sup> principles to facilitate, enable, and coach in the multi-team environment</li>
						<li class="training_li_list">Build high-performing teams that foster relentless improvement at the program and team levels</li>
						<li class="training_li_list">Find out Agile and Scrum anti-patterns</li>
						<li class="training_li_list">Support the adoption of DevOps, Agile Architecture and other Engineering Practices</li>
						<li class="training_li_list">Discover the usage of Kanban in facilitating the flow of team and improve team's performance</li>
						<li class="training_li_list">Learn to facilitate program planning, execution, and delivery of end-to-end systems value</li>
						<li class="training_li_list">Foster learning by participating in Communities of Practice and Innovation cycles.</li>
					</ul>
				</div>
				<div class="col-sm-12 col-xs-12">
					<h2 class="sectionTitle margin_top_gen">
						Audience
					</h2>
					<ul>
						<li class="training_li_list">Existing Scrum Masters</li>
						<li class="training_li_list">Team leaders, Project Managers, and others professionals aiming to assume the role of an Agile Team Facilitator in a SAFe<sup>&reg;</sup> or enterprise Agile context</li>
						<li class="training_li_list">Development and Engineering Managers responsible for execution of Agile, and for coaching teams and sub-teams</li>
						<li class="training_li_list">Agile Coaches, Agile Program Managers and Release Train Engineers</li>
					</ul>
				</div>
				<div class="col-sm-12 col-xs-12">
					<h2 class="sectionTitle margin_top_gen">
						Course Deliverables
					</h2>
					<ul>
						<li class="training_li_list">Attendees will get a printed copy of the workbook</li>
						<li class="training_li_list">Eligibility to take the SAFe<sup>&reg;</sup> Advanced Scrum Master exam online</li>
						<li class="training_li_list">Attendees who pass the exam will receive the SAFe<sup>&reg;</sup> Advanced Scrum Master certificate with one year free membership from Scaled Agile Academy</li>
						<li class="training_li_list">A SAFe<sup>&reg;</sup> Advanced Scrum Master (SASM) digital badge for promoting accomplishment online</li>
						<li class="training_li_list">Attendees who pass the exam, will get access to members-only resources like workbooks, webinars, guidance presentations, and advance notice of forthcoming SAFe<sup>&reg;</sup> products</li>
						<li class="training_li_list">Membership renewals annual from the date of certification</li>
						<li class="training_li_list">Attendees can apply for 15 PDUs through PMI, 16 SEUs under category C through Scrum Alliance</li>
						<li class="training_li_list">In person 2- day training full of learning and fun.</li>
					</ul>
				</div>
			</div>
		</div>
	</section>
	<section class="no-margin-bottom contact_us_bg_page margin_top_contact">
		<div class="container">
			<div class="col-sm-12 col-xs-12 padding0">
				<div class="col-sm-12 col-xs-12">
					<h2 class="contact_training_title1">Want to Participate?</h2>
					<h4 class="contact_training_title2">You can reach us to book in-house class</h4>
					<a href="../../about/contact/" class="training_contact">Contact</a>
				</div>
			</div>
		</div>
	</section>
	<?php include('../../includes/footer.php'); ?>
    
     <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>
    <!--end pure chat-->
    
</body>

</html>
