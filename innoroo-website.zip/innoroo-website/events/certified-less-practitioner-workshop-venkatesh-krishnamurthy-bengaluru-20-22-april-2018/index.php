<!DOCTYPE html>
<html lang=en>

<head>
    
   <!--Updated On 07-07-2018 MI
meta tag updated-->
    <title>INNOVATION ROOTS | Events | Certified Less Practitioners Workshop Venkatesh Krishnamurthy Bengaluru 20-22 April 2018 | 3 Day technical training on LeSS by Venkatesh </title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
     <!--Description Tag Meta Start-->
    <!--Updated for 07.07.18 version MI-->
    <meta name="description" content="The LeSS Practitioner training covers Large-Scale Scrum (LeSS) in wide knoweldge, with its best standards, frameworks and rules. It conveys fundamental information for the selection and change of LeSS for the current Product Development Group.">
    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">

    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../inc/assets/css/newsletter_form.css">
    <link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
    <link href="../../inc/assets/css/main.css" rel="stylesheet" />

    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>
    <script type=text/javascript>
        document.oncontextmenu = new Function("return false");
        document.onselectstart = new Function("return false");
        if (window.sidebar) {
            document.onmousedown = new Function("return false");
            document.onclick = new Function("return true");
            document.oncut = new Function("return false");
            document.oncopy = new Function("return false");
            document.onpaste = new Function("return false")
        };

    </script>
    <!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
    <style>
        .nav-tabs>li {
            float: left;
            margin-bottom: -5px;
            border-bottom: transparent
        }

    </style>
</head>

<body>
    <?php include('../../includes/header.php'); ?>
    <section class="section_margin_gen_training section_training_banner color_class">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-9 col-xs-12">
                    <h2 class="sectionTitle class_font">Certified LeSS Practitioners Workshop</h2>
                    <h3 class="sectionSubtitle class_font">[ Gain essential LeSS knowledge and the ability to adopt it in Product Development Cycle ]</h3>

                </div>
                <div class="col-sm-3 col-xs-12">
                    <div class="reg_section_bg">
                        <div class="reg_training_sec">
                            <h4 class="reg_section">20 - 22 April 2018</h4>
                            <h4 class="reg_section">3 Day Workshop</h4>
                            <h4 class="reg_section"><b>Bengaluru</b></h4>
                        </div>
                        <a class="training_register">CLOSED</a>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Overview
                    </h2>
                    <p class="para_training">
                        The Certified LeSS Practitioner course covers Large-Scale Scrum (LeSS) in an in-depth format, with its corresponding principles, frameworks and rules. It delivers essential information for the adoption and improvement of LeSS for the existing Product Development Group. Large-Scale Scrum (LeSS) knowledge is essential for the application of Scrum principles in a large-scale context.
                    </p>
                    <p class="para_training">
                        This three-day course will teach participants essential Scrum principles, as well as structural rules and guidelines on how to adopt it during development. Participants will learn LeSS overview, stories on LeSS adoptions, exercises and Q and A’s. It will also enhance the knowledge of existing Certified Scrum Masters, and Professional Scrum Masters.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training section_training_requirements">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-hourglass-half fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Duration</h5>
                        <h6 class="training_requirement_title1">3 Days (24 Hours)</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-clock-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Timing</h5>
                        <h6 class="training_requirement_title1">9 AM to 6 PM Each day (with 1 Hour break in between)</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-user-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Presenter</h5>
                        <h6 class="training_requirement_title1">Venkatesh Krishnamurthy</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-group fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Batch Size</h5>
                        <h6 class="training_requirement_title1">Maximum of 20</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-id-badge fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Participants Profile</h5>
                        <h6 class="training_requirement_title1">Intermediate</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-check-circle-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Prerequisite</h5>
                        <h6 class="training_requirement_title1">Basic Knowledge on Scrum</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-language fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Course Delivery Language</h5>
                        <h6 class="training_requirement_title1">English</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="glyphicon glyphicon-blackboard fa_training fa-2x"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Approach of Delivery</h5>
                        <h6 class="training_requirement_title1">Mix of theory & workshop sessions (Classroom Training)</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-graduation-cap fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Certification Details</h5>
                        <h6 class="training_requirement_title1">Attending this course will enable participants to become a Certified LeSS Practitioner</h6>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-university fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Accreditation Institute</h5>
                        <h6 class="training_requirement_title1">LeSS.works</h6>
                    </div>
                </div>
                <div class="border_seperator"></div>
            </div>
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12">
                    <div class="col-sm-1 col-xs-1 padding0 icon-align-center">
                        <i class="fa fa-handshake-o fa_training fa-2x" aria-hidden="true"></i>
                    </div>
                    <div class="col-sm-11 col-xs-11">
                        <h5 class="training_requirement_title1">Commercials & Logistics</h5>
                        <h6 class="training_requirement_title1">Contact us for Quotations</h6>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section_margin_gen_training">
        <div class="container">
            <div class="col-sm-12 col-xs-12 section-ul-bottom">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Agenda
                    </h2>
                    <ul>
                        <li class="training_li_list">LeSS Overview, Principles and Organizational aspects</li>
                        <li class="training_li_list">Manage Product Development and Definition of Done</li>
                        <li class="training_li_list">Organizing around Customer Value and Feature Teams</li>
                        <li class="training_li_list">LeSS Product Backlog Refinement, Sprint Planning, Review and Retrospective</li>
                        <li class="training_li_list">Product Owner role</li>
                        <li class="training_li_list">Scrum Master role with LeSS</li>
                        <li class="training_li_list">Facilitate collaboration in Teams</li>
                        <li class="training_li_list">Feature Team Adoption Map</li>
                        <li class="training_li_list">Adopting LeSS in your organization</li>
                        <li class="training_li_list">Case Study</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Learning Objective
                    </h2>
                    <ul>
                        <li class="training_li_list">Understand how to manage cross-functional, self-managing teams</li>
                        <li class="training_li_list">Learn the importance of LeSS, LeSS overview, Rules and Principles</li>
                        <li class="training_li_list">Organize around Customer Value and Feature Teams</li>
                        <li class="training_li_list">Analyze Product Owner roles and Backlog</li>
                        <li class="training_li_list">Execute Sprint Planning, LeSS Product Backlog refinement, Review and Retrospective</li>
                        <li class="training_li_list">Play the Scrum Master role within LeSS</li>
                        <li class="training_li_list">Discover why LeSS matters</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Audience
                    </h2>
                    <ul>
                        <li class="training_li_list">Scrum Masters</li>
                        <li class="training_li_list">Product Owners</li>
                        <li class="training_li_list">IT and Project Managers</li>
                        <li class="training_li_list">Delivery and Release Managers</li>
                    </ul>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <h2 class="sectionTitle margin_top_gen">
                        Course Deliverables
                    </h2>
                    <ul>
                        <li class="training_li_list">All participants get access to the new book: "Large-Scale Scrum: More with LeSS"</li>
                        <li class="training_li_list">In person 3-day training full of learning and fun</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section class="contact_us_bg_page no-margin-bottom margin_top_contact">
        <div class="container">
            <div class="col-sm-12 col-xs-12">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="contact_training_title1">Want to Participate?</h2>
                    <h4 class="contact_training_title2">You can reach us to book in-house class</h4>
                    <a href="../../about/contact/" class="training_contact">Contact</a>
                </div>
            </div>
        </div>
    </section>
    <?php include('../../includes/footer.php'); ?>

    <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
        window.purechatApi = {
            l: [],
            t: [],
            on: function() {
                this.l.push(arguments);
            }
        };
        (function() {
            var done = false;
            var script = document.createElement('script');
            script.async = true;
            script.type = 'text/javascript';
            script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
            document.getElementsByTagName('HEAD').item(0).appendChild(script);
            script.onreadystatechange = script.onload = function(e) {
                if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
                    var w = new PCWidget({
                        c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
                        f: true
                    });
                    done = true;
                }
            };
        })();

    </script>
    <!--end pure chat-->

</body>

</html>
