<!DOCTYPE html>
<html lang="en">

<head>
    
    <!--Updated On 07-07-2018 MI
meta tag updated-->
    <title>INNOVATION ROOTS | Resources | Game | Resources | Game Listing </title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width" initial-scale="1.0">
    
    <!--Description Tag Meta Start-->
    <!--Updated for 07.07.18 version MI-->
    <meta name=description content="Join with us to avail the best Agile games in 2018 by the most Innovative way.">
    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
    <meta name="ROBOTS" content="INDEX, FOLLOW">

    <!-- OPEN GRAPH META TAG STARTS -->	
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->

    <link href="../../inc/assets/css/bootstrap.min.css" rel="stylesheet" />
    <link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link href="../../inc/assets/css/main.css" rel="stylesheet" />
    <script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
    <link rel="shortcut icon" type=image/x-icon href="../../inc/assets/img/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type=text/javascript src=../../inc/assets/js/jquery-1.11.1.min.js></script>
    <script type=text/javascript src=../../inc/assets/js/bootstrap.min.js></script>
    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>


    <script type="text/javascript">
        document.oncontextmenu = new Function("return false");
        document.onselectstart = new Function("return false");
        if (window.sidebar) {
            document.onmousedown = new Function("return false");
            document.onclick = new Function("return true");
            document.oncut = new Function("return false");
            document.oncopy = new Function("return false");
            document.onpaste = new Function("return false");
        }
    </script>

</head>

<body>
    <!--header starts here-->
    <?php include('../../includes/header.php');?>

    <!--header ends here-->
    <!--start save in facebook-->
    <div id="fb-root"></div>
    <script>
        (function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s);
            js.id = id;
            js.src = 'https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.12&appId=175702923225282';
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
    </script>

    <!--end save in facebook-->

    <!--start like in facebook-->
    <div id="fb-root"></div>
    <script>
        (function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s);
            js.id = id;
            js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.12";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));

    </script>

    <!--end like in facebook-->

    <!--feature image section starts here-->
    <section class="page-cover-half color-white">
        <div class="container">
            <div class="page-cover-bg career-bg opacity-2"></div>
            <div class="col-sm-12 col-md-12 col-xs-12 page_center_caption">
                <h2 class="main_title">Games</h2>
                <div class="text_center_hr1"></div>
                <p class="heading_sub_page">Learning is Fun with Balls, Blocks, Cards, Coins and Papers!</p>
            </div>
        </div>
    </section>
    <!--feature image section ends here-->

    <!--game detail listing cards starts here-->
    <section class="gd-padding-sec">
        <div class="container">
            <div class="col-sm-12 col-md-12 col-xs-12 gd-listing padd0">
                <div class="col-md-4 col-sm-6 col-xs-12 div-padding padd0">
                    <div class="col-sm-12 col-xs-12 gd-bg-color">
                        <div class="col-sm-12 col-xs-12 gd-img">
                            <img src="../../inc/assets/img/game/pokercard-image.png" alt="" width="100%" height="100%">
                            <h2>Animal Estimation Game</h2>
                        </div>
                        <div class="col-sm-12 col-xs-12 gd-icons-bg">
                            <div class="gd-icons">
                                <div class="col-sm-1 col-xs-1 dropdown gd-share-icon padding0">
                                    <span class="dropbtn">
                                        <i class="fa fa-share"></i>
                                    </span>
                                    <div class="dropdown-content" style="left:0;">
                                        <div class="all_share_link">
                                            <a title="Share on Facebook" onclick="window.open('https://www.facebook.com/sharer.php?u=http://innovationroots.com/resources/game/animal-estimation-game/', 'facebookShare', 'width=626,height=436'); return false;" href="#" track-type="gamedetails-socialshare" track-element="gamedetails-socialshare-facebook"><i class="fa fa-facebook sp-left"></i> facebook</a>
                                            <a title="Tweet This" onclick="window.open('https://twitter.com/share?text=animal-estimation-game', 'twitterShare', 'width=626,height=436'); return false;" href="#" track-type="gamedetails-socialshare" track-element="gamedetails-socialshare-twitter"><i class="fa fa-twitter sp-left"></i> twitter</a>
                                            <a title="Share on Google+" onclick="window.open('https://plusone.google.com/_/+1/confirm?hl=en-US&amp;url=http://innovationroots.com/resources/game/animal-estimation-game/', 'googleShare', 'width=626,height=436'); return false;" href="#" track-type="gametdetails-socialshare" track-element="gamedetails-socialshare-googleplus"><i class="fa fa-google-plus sp-left"></i> google plus</a>
                                            <a title="Share on linkedin" onclick="window.open('https://www.linkedin.com/shareArticle?mini=true&url=http://innovationroots.com/resources/game/animal-estimation-game/', 'linkedinShare', 'width=750,height=350'); return false;" href="#" track-type="gamedetails-socialshare" track-element="gamedetails-socialshare-linkedin"><i class="fa fa-linkedin sp-left"></i> Linkedin</a>
                                            <div class="triangle">
                                                <div class="triangle-left">
                                                    <div class="inner-triangle"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-1 col-xs-1 gd-save-icon padding0">
                                    <i class="fa fa-bookmark" aria-hidden="true"></i>
                                    <div class="fb-save" data-uri="https://www.innoroo.com/inc/assets/img/game/pokercard-image.png"></div>
                                </div>
<!--
                                <div class="col-sm-10 col-xs-1 gd-like-icon padding0">
                                    <i class="fa fa-heart" aria-hidden="true"></i>
                                    <div class="fb-like" data-href="https://www.innoroo.com/inc/assets/img/game/pokercard-image.png/" data-layout="standard" data-action="like" data-show-faces="false">
                                    </div>
                                </div>
-->
                                <a href="animal-estimation-game/" class="gd-btn-right"><button class="btn">KNOW MORE</button></a>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="col-md-4 col-sm-6 col-xs-12 div-padding padd0">
                    <div class="col-sm-12 col-xs-12 gd-bg-color">
                        <div class="col-sm-12 col-xs-12 gd-img">
                            <img src="../../inc/assets/img/game/pokercard-image.png" alt="" width="100%" height="100%">
                            <h2 > Zoo Blindfold Game </h2>
                        </div>
                        <div class="col-sm-12 col-xs-12 gd-icons-bg">
                            <div class="gd-icons">
                                <div class="col-sm-1 col-xs-1 dropdown gd-share-icon padding0">
                                    <span class="dropbtn">
                                        <i class="fa fa-share"></i>
                                    </span>
                                    <div class="dropdown-content" style="left:0;">
                                        <div class="all_share_link">
                                            <a title="Share on Facebook" onclick="window.open('https://www.facebook.com/sharer.php?u=http://innovationroots.com/resources/game/zoo-feedback-game/', 'facebookShare', 'width=626,height=436'); return false;" href="#" track-type="gamedetails-socialshare" track-element="gamedetails-socialshare-facebook"><i class="fa fa-facebook sp-left"></i> facebook</a>
                                            <a title="Tweet This" onclick="window.open('https://twitter.com/share?text=zoo-feedback-game', 'twitterShare', 'width=626,height=436'); return false;" href="#" track-type="gamedetails-socialshare" track-element="gamedetails-socialshare-twitter"><i class="fa fa-twitter sp-left"></i> twitter</a>
                                            <a title="Share on Google+" onclick="window.open('https://plusone.google.com/_/+1/confirm?hl=en-US&amp;url=http://innovationroots.com/resources/game/zoo-feedback-game/', 'googleShare', 'width=626,height=436'); return false;" href="#" track-type="gametdetails-socialshare" track-element="gamedetails-socialshare-googleplus"><i class="fa fa-google-plus sp-left"></i> google plus</a>
                                            <a title="Share on linkedin" onclick="window.open('https://www.linkedin.com/shareArticle?mini=true&url=http://innovationroots.com/resources/game/zoo-feedback-game/', 'linkedinShare', 'width=750,height=350'); return false;" href="#" track-type="gamedetails-socialshare" track-element="gamedetails-socialshare-linkedin"><i class="fa fa-linkedin sp-left"></i> Linkedin</a>
                                            <div class="triangle">
                                                <div class="triangle-left">
                                                    <div class="inner-triangle"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-1 col-xs-1 gd-save-icon padding0">
                                    <i class="fa fa-bookmark" aria-hidden="true"></i>
                                    <div class="fb-save" data-uri="https://www.innoroo.com/inc/assets/img/game/pokercard-image.png"></div>
                                </div>
<!--
                                <div class="col-sm-10 col-xs-1 gd-like-icon padding0">
                                    <i class="fa fa-heart" aria-hidden="true"></i>
                                    <div class="fb-like" data-href="https://www.innoroo.com/inc/assets/img/game/pokercard-image.png/" data-layout="standard" data-action="like" data-show-faces="false">
                                    </div>
                                </div>
-->
                                <a href="zoo-blindfold-game/" class="gd-btn-right"><button class="btn">KNOW MORE</button></a>
                            </div>
                        </div>
                    </div>
                </div>
                
                
                <!--
                <div class="col-md-4 col-sm-6 col-xs-12 div-padding gd-margin-right">
                    <div class="col-sm-12 gd-bg-color">
                        <div class="col-sm-12 gd-img">
                            <img src="" alt="" width="100%" height="100%">
                        </div>
                        <div class="col-sm-12 gd-icons-bg">
                            <div class="gd-icons">
                                <i class="fa fa-heart-o" aria-hidden="true"></i>
                                 <i class="fa fa-bookmark-o" aria-hidden="true"></i> 
                                <div class="dropdown gd-share-icon">
                                    <span class="dropbtn"><i class="fa fa-share"></i></span>
                                    <div class="dropdown-content" style="left:0;">
                                        <div class="all_share_link">
                                            <a title="Share on Facebook" onclick="window.open('https://www.facebook.com/sharer.php?u=https://www.goeventz.com/event/leading-safe-4.0/36983', 'facebookShare', 'width=626,height=436'); return false;" href="#" track-type="eventdetails-socialshare" track-element="eventdetails-socialshare-facebook"><i class="fa fa-facebook sp-left"></i> facebook</a>
                                            <a title="Tweet This" onclick="window.open('https://twitter.com/share?text=Leading SAFe 4.5 with SA Certification', 'twitterShare', 'width=626,height=436'); return false;" href="#" track-type="eventdetails-socialshare" track-element="eventdetails-socialshare-twitter"><i class="fa fa-twitter sp-left"></i> twitter</a>
                                            <a title="Share on Google+" onclick="window.open('https://plusone.google.com/_/+1/confirm?hl=en-US&amp;url=https://www.goeventz.com/event/leading-safe-4.0/36983', 'googleShare', 'width=626,height=436'); return false;" href="#" track-type="eventdetails-socialshare" track-element="eventdetails-socialshare-googleplus"><i class="fa fa-google-plus sp-left"></i> google plus</a>
                                            <a title="Share on linkedin" onclick="window.open('https://www.linkedin.com/shareArticle?mini=true&url=https://www.goeventz.com/event/leading-safe-4.0/36983&summary=Leading SAFe 4.5 with SA Certification', 'linkedinShare', 'width=750,height=350'); return false;" href="#" track-type="eventdetails-socialshare" track-element="eventdetails-socialshare-linkedin"><i class="fa fa-linkedin sp-left"></i> Linkedin</a>
                                            <div class="triangle">
                                                <div class="triangle-left">
                                                    <div class="inner-triangle"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <a href="" class="gd-btn-right"><button class="btn">KNOW MORE</button></a>
                            </div>
                        </div>
                    </div>
                </div>
-->
                <!--
                <div class="col-md-4 col-sm-6 col-xs-12 div-padding gd-margin-right">
                    <div class="col-sm-12 gd-bg-color">
                        <div class="col-sm-12 gd-img">
                            <img src="" alt="" width="100%" height="100%">
                        </div>
                        <div class="col-sm-12 gd-icons-bg">
                            <div class="gd-icons">
                                <i class="fa fa-heart-o" aria-hidden="true"></i>
                                 <i class="fa fa-bookmark-o" aria-hidden="true"></i> 
                                <div class="dropdown gd-share-icon">
                                    <span class="dropbtn"><i class="fa fa-share"></i></span>
                                    <div class="dropdown-content" style="left:0;">
                                        <div class="all_share_link">
                                            <a title="Share on Facebook" onclick="window.open('https://www.facebook.com/sharer.php?u=https://www.goeventz.com/event/leading-safe-4.0/36983', 'facebookShare', 'width=626,height=436'); return false;" href="#" track-type="eventdetails-socialshare" track-element="eventdetails-socialshare-facebook"><i class="fa fa-facebook sp-left"></i> facebook</a>
                                            <a title="Tweet This" onclick="window.open('https://twitter.com/share?text=Leading SAFe 4.5 with SA Certification', 'twitterShare', 'width=626,height=436'); return false;" href="#" track-type="eventdetails-socialshare" track-element="eventdetails-socialshare-twitter"><i class="fa fa-twitter sp-left"></i> twitter</a>
                                            <a title="Share on Google+" onclick="window.open('https://plusone.google.com/_/+1/confirm?hl=en-US&amp;url=https://www.goeventz.com/event/leading-safe-4.0/36983', 'googleShare', 'width=626,height=436'); return false;" href="#" track-type="eventdetails-socialshare" track-element="eventdetails-socialshare-googleplus"><i class="fa fa-google-plus sp-left"></i> google plus</a>
                                            <a title="Share on linkedin" onclick="window.open('https://www.linkedin.com/shareArticle?mini=true&url=https://www.goeventz.com/event/leading-safe-4.0/36983&summary=Leading SAFe 4.5 with SA Certification', 'linkedinShare', 'width=750,height=350'); return false;" href="#" track-type="eventdetails-socialshare" track-element="eventdetails-socialshare-linkedin"><i class="fa fa-linkedin sp-left"></i> Linkedin</a>
                                            <div class="triangle">
                                                <div class="triangle-left">
                                                    <div class="inner-triangle"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <a href="" class="gd-btn-right"><button class="btn">KNOW MORE</button></a>
                            </div>
                        </div>
                    </div>
                </div>
-->
            </div>
        </div>
    </section>
    <!--game detail listing cards ends here-->

    <!--footer starts here-->
    <?php include('../../includes/footer.php');?>
    
     <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>
    <!--end pure chat-->
    
</body>

</html>
