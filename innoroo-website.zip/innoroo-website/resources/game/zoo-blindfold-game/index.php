<!DOCTYPE html>
<html lang="en">

<head>
    
   <!--Updated On 07-07-2018 MI
meta tag updated-->
    <meta name="google-site-verification" content="2RxPEMEJ3Vw7pu7BJ9I-zgwbmiEK6uJM3Ulq8ImrBZE" />
    <title>INNOVATION ROOTS | Resources | Game | Animal Estimation Game | Animal estimation game in the Agile </title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
     <!--Description Tag Meta Start-->
    <!--Updated for 07.07.18 version MI-->
    <meta name="description" content="Click here to learn more about the Agile Estimation Game. Download the facilitator guide to know the step-by-step process of game.">
    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
    <meta name="ROBOTS" content="INDEX, FOLLOW">
    
    <!-- OPEN GRAPH META TAG STARTS -->	
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->
    
    <link href="../../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
    <link href="../../../inc/assets/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../../../inc/assets/css/newsletter_form.css">
    <!-- Icon Fonts -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../../../inc/assets/css/main.css" rel="stylesheet" />
    <script src="../../../inc/assets/js/modernizr.custom.83079.js"></script>

    <link rel="shortcut icon" type="image/x-icon" href="../../../inc/assets/img/favicon.ico">

    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>

    <script src="https://www.google.com/recaptcha/api.js"></script>
    <script type="text/javascript">
        document.oncontextmenu = new Function("return false");
        document.onselectstart = new Function("return false");
        if (window.sidebar) {
            document.onmousedown = new Function("return false");
            document.onclick = new Function("return true");
            document.oncut = new Function("return false");
            document.oncopy = new Function("return false");
            document.onpaste = new Function("return false");
        }

    </script>
</head>

<body>
    <?php include ('../../../includes/header.php');?>
    <div class="home-cover">
        <div class="col-sm-12 padding0 animalPokerCardFeature">
            <img src="../../../inc/assets/img/game/zoo-blindfold-game.png" width="100%" alt="Animal Pocker Card">
            <div class="col-sm-10 col-xs-12 GameHeading">
                <h2>Zoo Blindfold Game</h2>
                <h3>Team consensus-based Gamified way of Estimation</h3>
            </div>
        </div>
        <section class="overview">
            <div class="container">
                <div class="col-sm-12 col-xs-12 ">
                    <div class="col-sm-12 col-xs-12 gameDetails">
                        <p><strong>Estimation</strong> Feedback is critical factor for project success. Delay in feedback may lead to not meeting Quality standards and thus missing the customer expectations . Our consulting team innovated a team based game to guide the engineers experience the importance of feedback as well as managing the timely feedback process in project work. 

Zoo Estimation Game is based on simple conect of Maze and can be played in a group or teams.
                    </div>
                </div>
            </div>
        </section>
<!--
        <section class="gamePDF">
            <div class="col-sm-12 col-xs-12">
                <div class="col-sm-6 col-xs-12">
                
                </div>
            <div class="col-sm-6 col-xs-12">
                <script type="text/javascript" src="https://form.jotform.me/jsform/80871574448467"></script>
                </div>
            
            </div>
        
        
        </section>
-->
        
        <!--
        <section class="instructions">
            <div class="container">
                <div class="col-sm-12 col-xs-12 howtoplay">
                    <div class="col-sm-4 col-xs-6">
                        <img src="../../../inc/assets/img/game/guide.png" alt="PDF" width="100%">
                    </div>
                    <div class="col-sm-6 guide">
                        <h2><span>GUIDE</span> for Animal Poker Card Game
                        </h2>
                        <p>Download for free</p>
                        <div class="col-sm-12 padding0" style="margin-top:20%">
                            <a href=""></a>
                            <div class="col-sm-8 padding0">
                                <button type="submit" data-toggle="modal" data-target="#myModal" class="btn">DOWNLOAD PDF</button>
                                <div class="col-sm-3 pdf">
                                    <img src="../../../inc/assets/img/game/pdf.png" width="100%" alt="PDF">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
-->
<!--
        <section class="gameKit">
            <div class="container">
                <div class="col-sm-12 col-xs-12">
                    <div class="col-sm-12 col-xs-12">
                        <h2 class="sectionTitle">Buy the Kit</h2>
                    </div>
                    <div class="col-sm-5 col-sm-offset-0 col-xs-8 col-xs-offset-2 padd0 gameKitImage">
                        <img src="../../../inc/assets/img/game/kit.png" width="100%" alt="Game Kit">
                    </div>
                    <div class="col-sm-6 col-xs-12 padd0">
                        <div class="col-sm-12 col-xs-12 padd0">
                            <ul>
                                <li>A deck of 9 set of hand designed Animal Cards for estimation</li>
                                <li>An End-To-End Facilitator-Guide Booklet, to coach teams to use Animal Cards for Estimation</li>
                                <li>A set of index cards, for taking important notes from the conversation</li>
                                <li>A set of waving thought-alert cards, to manage Attention</li>
                                <li>An awesome 15 minutes Sand Timer, to manage Time-Boxing</li>
                                <li>A Sports Whistle, to add fun to the activity</li>
                            </ul>
                            <a href="mailto:community@innovationroots.com">
								<button class="btn">BUY</button>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
-->
    <?php include ('../../../includes/footer.php');?>
    
     <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>
    <!--end pure chat-->
    
    
    <script type="text/javascript" src="../../../inc/assets/js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="../../../inc/assets/js/bootstrap.min.js"></script>

</body>

</html>
