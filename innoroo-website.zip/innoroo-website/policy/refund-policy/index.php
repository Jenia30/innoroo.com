<!--Updated On 28-03-2018GA
meta tag updated
-->

<!DOCTYPE html>
<html lang=en>

<head>
	<title>INNOVATION ROOTS | Policy | Refund Policy</title>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    
	<!-- OPEN GRAPH META TAG STARTS -->
	<meta property='og:title' content='INNOVATION ROOTS' />
	<meta property="og:image" content="http://innovationroots.com/test.innoroo.com/inc/assets/img/agile-transformation/agile-transformation.png" />
	<meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
	<meta property="og:url" content="www.innoroo.com" />
	<!-- OPEN GRAPH META TAG ENDS -->
    
	<meta name="description" content="Cancellation Request has to be sent to the community@innovationroots.com by customers. Below is the policy and charges on participation cancellation.">
	<meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
	<meta name="ROBOTS" content="INDEX, FOLLOW">
	<link href="../..//inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
	<link href="../../inc/assets/css/bootstrap.min.css" rel="stylesheet" />
	<link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="../../inc/assets/css/main.css" rel="stylesheet" />
	<script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
	<link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
	<script>
		(function(d, e, j, h, f, c, b) {
			d.GoogleAnalyticsObject = f;
			d[f] = d[f] || function() {
				(d[f].q = d[f].q || []).push(arguments)
			}, d[f].l = 1 * new Date();
			c = e.createElement(j), b = e.getElementsByTagName(j)[0];
			c.async = 1;
			c.src = h;
			b.parentNode.insertBefore(c, b)
		})(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
		ga("create", "UA-100332682-2", "auto");
		ga("send", "pageview");

	</script>
	<script type="text/javascript">
		document.oncontextmenu = new Function("return false");
		document.onselectstart = new Function("return false");
		if (window.sidebar) {
			document.onmousedown = new Function("return false");
			document.onclick = new Function("return true");

			document.oncut = new Function("return false");

			document.oncopy = new Function("return false");


			document.onpaste = new Function("return false");
		}

	</script>
	<!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
</head>

<body>
	<?php include('../../includes/header.php');?>
	<section class="section_margin_gen legal_head">
		<div class="container">
			<div class="col-sm-12 col-xs-12">
				<div class="col-sm-12 col-xs-12">
					<h2 class="heading_innoroo" style="text-align:left">Refund Policy</h2>
				</div>
			</div>
		</div>
	</section>
	<section class="legal_section">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<p class="policy_li_list">Cancellation Request has to be send in written to community@innovationroots.com by customers. Below is the policy and charges on participation cancellation-</p>

					<table cellspacing="1" cellpadding="1" border="1" id="ir_policy_table" class="table_policy_cancel ">
						<thead>
							<tr>
								<th class="policy_th event_width">Event Type</th>
								<th class="policy_th">Time of Cancellation</th>
								<th class="policy_th">Refundable amount</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td rowspan="3" colspan="1">Training/Workshop</td>
								<td>Less than 30 days of the event day or after the event day</td>
								<td>Non – Refundable</td>
							</tr>
							<tr>
								<td>Between 31 to 60 days of the event day</td>
								<td>50% Refund</td>
							</tr>
							<tr>
								<td>Between 61 days to 365 days of the event day</td>
								<td>80% Refund </td>
							</tr>
							<tr>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td>Certification Class</td>
								<td>Less than 30 days of the event or after the event day</td>
								<td>Non – Refundable</td>
							</tr>
							<tr>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td rowspan="3" colspan="1">Conference/Gatherings</td>
								<td>Less than 30 days of the event day or after the event day</td>
								<td>Non – Refundable</td>
							</tr>
							<tr>
								<td>Between 31 to 60 days of the event day</td>
								<td>50% Refund</td>
							</tr>
							<tr>
								<td>Between 61 days to 365 days of the event day</td>
								<td>80% Refund </td>
							</tr>
							<tr>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td rowspan="3" colspan="1">Any other Event</td>
								<td>Less than 30 days of the event day or after the event day</td>
								<td>Non – Refundable</td>
							</tr>
							<tr>
								<td>Between 31 to 60 days of the event day</td>
								<td>50% Refund</td>
							</tr>
							<tr>
								<td>Between 61 days to 365 days of the event day</td>
								<td>80% Refund </td>
							</tr>
						</tbody>
					</table>
					<script>
						$.each($('#ir_table', this.$el), function(index, table) {
							var rowspan = 0;
							$.each($('tr', table), function(index, tr) {
								if (rowspan > 0) {
									$('td:first-child', tr).addClass("not-first-child");
									rowspan = (rowspan > 0) ? rowspan - 1 : 0;
								} else if ($('td:first-child', tr).attr("rowspan") > 0) {
									rowspan = parseInt($('td:first-child', tr).attr("rowspan")) - 1;
								}
							});
						});

					</script>
					<style>
						table {
							border-collapse: collapse;
							border-spacing: 0;}
							thead,
							th,
							td,
							tfoot {
								border: 1px solid #ccc;
								padding: 10px;
							}
							
							td {
								&:first-child {
									color: #39f;
								}
								&.not-first-child {
									color: #eee;
								}
							}
						}

						.table_policy_cancel {
							border: 1px solid #ddd;
							width: 85%;
							margin: 4% auto;
						}

						#ir_policy_table td {
							padding: 5px;
							text-align: center;
						}

						.policy_th {
							text-align: center;
							padding: 10px;
						}

						.event_width {
							width: 23%;
						}

						@media (min-width: 280px) and (max-width:500px) {
							/*.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
                                    padding: 0px !important;

                                }*/
							.policy_th {
								text-align: left;
								padding: 10px 3px;
								font-size: 11px !important;
							}
							table {
								font-size: 12px !important;
							}
							#ir_policy_table td {
								padding: 5px;
							}
						}

					</style>
					<p class="policy_li_list">
						Company's Training Coordinator initiates the refund as per the process in 30 days from the date of receiving formal cancellation request from Customer.
					</p>
					<p class="policy_li_list">
						Refund will also attract deduction of discounts/promotional-offers/cash-back/complimentary-pass offers availed during the purchase, shipping expenses, administrative charges, tax collected, services charges and payment gateway charges etc. from the refundable amount.
					</p>
					<p class="policy_li_list">
						Company's Accounting & Finance directly credits the refundable amount to the buyer's account as per the process in 45 business days from the date of receiving the formal refund instruction from company's Training Coordinator. All the communication related to refund status has to be written sent to accounts@innovationroots.com.
					</p>
					<p class="policy_li_list">
						Any legal dispute and grievance arising out of this agreement shall be governed by the Laws of India. The court of jurisdiction for any disputes arising out of or about this agreed process may be addressed at the Court of Bengaluru, Karnataka, India as per applicable Indian Laws & all financial expenses would be borne by the judgment-debtor.
					</p>
					<p class="policy_li_list">
						Company reserves all the right to accept and/or reject the Cancellation Request and to change the policy on time-to-time basis without any prior notice to anyone.
					</p>
				</div>
			</div>
		</div>
	</section>
	<?php include('../../includes/footer.php');?>
    
     <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>
    <!--end pure chat-->
    
    
	<script type="text/javascript" src="../../inc/assets/js/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="../../inc/assets/js/bootstrap.min.js"></script>
</body>

</html>
