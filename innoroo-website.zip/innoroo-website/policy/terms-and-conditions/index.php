<!--Updated On 20-03-2018JB
	Meta tag updated
-->

<!DOCTYPE html>
<html lang="en">

<head>
    <title>INNOVATION ROOTS | Policy | Terms and Conditions</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/test.innoroo.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->
    <meta name="description" content="">
    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
    <meta name="ROBOTS" content="INDEX, FOLLOW">
    <link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
    <link href="../../inc/assets/css/bootstrap.min.css" rel="stylesheet" />
    <link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../../inc/assets/css/main.css" rel="stylesheet" />
    <script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>
    
	<script type="text/javascript">
		document.oncontextmenu = new Function("return false");
		document.onselectstart = new Function("return false");
		if (window.sidebar) {
			document.onmousedown = new Function("return false");
			document.onclick = new Function("return true");
			document.oncut = new Function("return false");
			document.oncopy = new Function("return false");
			document.onpaste = new Function("return false");
		}

	</script>
    <!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
</head>

<body>
    <?php include('../../includes/header.php');?>
    <section class="section_margin_gen legal_head">
        <div class="container">
            <div class="col-sm-12 col-xs-12">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="heading_innoroo" style="text-align:left">Terms and Conditions</h2>
                </div>
            </div>
        </div>
    </section>
    <section class="legal_section termsandConditions">
        <div class="container">
            <div class="col-sm-12 col-xs-12 spacing">
                <h3>Website Usage</h3>
                <p>This Terms and Conditions page of the website of <strong class="innoroo">INNOVATION ROOTS</strong> (hereafter, referenced as Company) dictates the limits of your usage of the website <a href="http://www.innoroo.com"> www.innoroo.com</a> and <a href="http://www.innovationroots.com"> www.innovationroots.com</a>. Company will be referred to in terms such as "we", "us", "ours", "belonging" and variations thereof in this policy. "You", "Visitors" and variations thereof will be used for referring the customers and visitors of the site. The phrases "courses", "training", "certifications", "publishing", "consulting", "coaching", "games", "blogs", "interviews", "articles", "workshops", "case studies", "designs", "design library" and variations thereof will be used to refer to the products and services offered by company.</p>

                <p>By using the website of company, or it's products and services, you agree to have read, understood and be bound by these 'Terms and Conditions'. As a user of this website, you are required to strictly adhere to these guidelines. Before navigating the company website, you are required to be in compliance with each and every one of them. If you are not accepting of these terms, you are not authorized to use the website, it's products or services.
                </p>
            </div>
            <div class="col-sm-12 col-xs-12 spacing">
                <h3>Purchases</h3>
                <p>If you wish to purchase any product/service from the company, you may be asked to supply relevant information to your purchase. Without limitation, the information may include your name, bank account details, address, telephone number, credit card information or other ancillary information.</p>
                <p>Company reserves the right to refuse service to any party it wishes not to have a relationship with. No additional/different terms contained in any document or purchase order will be binding upon delivery of product/service, unless agreed by company in writing.</p>
            </div>
            <div class="col-sm-12 col-xs-12 spacing">
                <h3>Content and Copyright</h3>
                <p>All the respective trademarks elaborated at the disclaimer is copyright of their respective bodies and entities, and may not be replicated, reproduced, modified in any manner by any party, except those said parties, and their affiliates, without prior consent.</p>
                <p>Company holds the right to deny, restrict or terminate access to the users who are disrespectful and disdainful of the Privacy Policy or Terms of Conditions of company. Your right to use the site, or any passwords or such in the future, are also non-transferable.</p>
            </div>
            <div class="col-sm-12 col-xs-12 spacing">
                <h3>User Postings</h3>
                <p>You acknowledge that company will own and possess the right for the complete unrestricted usage and publishing for any and all information you post or publish on the site, be it posts, responses or any other type. You also hereby agree to waive any and all claims against company for infringements or any other privacy violations.</p>
                <p>You agree that you will not post or publish material on the site that is: defamatory, misleading, obscene, or constitute a criminal offense or violation of law and copyright. It should also not contain viruses, external advertising or false statements. Company holds the right to deny the post and remove any post at any time on it's site, for any reason it sees fit.</p>
            </div>
            <div class="col-sm-12 col-xs-12 spacing">
                <h3>Restrictions</h3>
                <p>The company website is protected by copyright and trademark law. You have restrictions on your limits of usage:</p>
                <ul>
                    <li>Publishing, Modifying or trying to Reproduce the content/material of the website in any other form of media.</li>
                    <li>Trying to sell, commercialize or profit from any content/material published or developed by company.</li>
                    <li>Trying to duplicate or hold a performance regarding any content, or training offered by company.</li>
                    <li>Using the company website in a way that is damaging to the company or it's User Base, Business Affiliates or Partners.</li>
                    <li>Using the company website in a way that is against applicable laws, rules and regulations.</li>
                    <li>Trying to engage in data harvesting, data mining, data extracting or any other illegal activity.</li>
                    <li>Trying to use company website/content in Advertising/Marketing anything else without permission.</li>
                </ul>
            </div>
            <div class="col-sm-12 col-xs-12 spacing">
                <h3>Linking</h3>
                <p>Our website/services may or may not contain links to other third party websites/services that are not owned and operated by company.</p>
                <p>Company claims no responsibility, nor any control of the privacy policies of the third party website. You acknowledge further that company will not be liable, directly or indirectly, for any losses or damages caused in connection with the content/services on any such websites.</p>
                <p>You are not to use the pages of company website for spamming or linking it to malicious websites that include pornography, human rights violation, racism, sexism, xenophobia or terrorism. You are also not allowed to link the company websites to content which is violates any applicable Governmental, regulatory code of practice, or any IP of another third party.</p>
            </div>
            <div class="col-sm-12 col-xs-12 spacing">
                <h3>Liability and Indemnity</h3>
                <p>You agree that company will not be liable for any direct, indirect or incidental damage resulting to you, unless it is under situations and circumstances prohibited by law or legality.</p>
                <p>You agree to indemnify company and it's owners, directors, officers, shareholders, agents, employees, affiliates and subsidiaries free from harm regarding demands, liabilities, losses, expenses, or claims made against company from any third party, in connection with your use of the site, or without.</p>
            </div>
            <div class="col-sm-12 col-xs-12 spacing">
                <h3>Changes</h3>
                <p>We reserve the right to modify/substitute these terms at any point, according to our sole discretion. If there is a need for revision, we will inform the parties with a (X) day notice , prior to it being into effect.</p>
            </div>
            <div class="col-sm-12 col-xs-12 spacing">
                <h3>Contact Us</h3>
                <p>In case of queries or misunderstanding regarding the Terms and Conditions, contact us at</p>
                <ul>
                    <li>Email: community@innovationroots.com</li>
                    <li>Postal Address: No 94, 17/1, Ambalipura, Bellandur Gate, Bengaluru, Karnataka, India- 560102</li>
                    <li>The terms and conditions are effective from 01 April 2018.</li>
                </ul>
            </div>
        </div>
    </section>
    <?php include('../../includes/footer.php');?>
    
     <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>
    <!--end pure chat-->
    
</body>

</html>
