<!--Updated On 28-03-2018GA
meta tag updated
-->

<!DOCTYPE html>
<html lang="en">

<head>
    <title>INNOVATION ROOTS | Policy | Privacy Policy</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/test.innoroo.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->
    <meta name="description" content="If you choose to use our Service, then you agree to the rules and use of information in relation with this policy. The Personal Information that we collect are used for providing and improving the Service.">
    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
    <meta name="ROBOTS" content="INDEX, FOLLOW">
    <link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
    <link href="../../inc/assets/css/bootstrap.min.css" rel="stylesheet" />
    <link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../../inc/assets/css/main.css" rel="stylesheet" />
    <script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>

    
	<script type="text/javascript">
		document.oncontextmenu = new Function("return false");
		document.onselectstart = new Function("return false");
		if (window.sidebar) {
			document.onmousedown = new Function("return false");
			document.onclick = new Function("return true");
			document.oncut = new Function("return false");
			document.oncopy = new Function("return false");
			document.onpaste = new Function("return false");
		}

	</script>


    <!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
</head>

<body>
    <?php include('../../includes/header.php');?>
    <section class="section_margin_gen legal_head">
        <div class="container">
            <div class="col-sm-12 col-xs-12">
                <div class="col-md-12">
                    <h2 class="heading_innoroo" style="text-align:left">Privacy Policy</h2>
                </div>
            </div>
        </div>
    </section>
    <section class="legal_section privacy_section">
        <div class="container">

            <div class="col-md-12 col-sm-12 col-xs-12">
                <p>This Privacy Policy (or the "Policy", subject to be amended from "time to time") of <strong class="innoroo">INNOVATION ROOTS</strong> Softech Private Limited (or the "Company") intends to give you an understanding on our methods of collecting, storing, transferring and using the information that you provide to us.</p>

                <p>The Policy may be subject to further changes. Upon updating the Policy, we may revise the "Updated" date at the bottom of this Policy. We highly recommend that you regularly check this portal to inform yourself of any updates. Your continued engagement with us will imply your acceptance of such updates to this Policy. </p>

                <p>Company seeks to protect the privacy of its users. By using the Website<a href="http://www.innovationroots.com/"> www.innovationroots.com</a> and <a href="http://www.innoroo.com/">  www.innoroo.com </a>, you agree to the use of your Personal Information in accordance with this policy. These terms apply to the : (i) "use" shall, for the purposes of this Privacy Policy include accessing, viewing, browsing or using the Website by any other means by a natural or a legal person, either directly or with data mining, crawlers, extraction tools or by any other functionality which is created and installed by a third party; (ii) "personal information" shall include your name, nickname, age, username, email address, postal address, contact numbers, your geographic location, internet protocol address, and any other information that can be used to identify you; "You" shall include any visitor/ user of the Website.</p>

                <ul>
                    <li>
                        <p><strong>Personal Information:</strong> We collect the user ID, IP address, domain names, date and time of visit, operating system used to visit for tracking and improving the site performance and quality of service only, and not for any other commercial purpose. We also use the Personal Information that you may disclose to us for the aforesaid purposes. You agree that company will have access to, and may use your log information, and the information your device transfers to company websites for the aforementioned purposes. If required, we may use the Personal Information and any data disclosed to us by your Usage of the Website to investigate and prevent the illegal usage of our services and content proprietary to company. Fraudulent activities that pose physical threats to any person shall be subjected to court of action against laws for violating the terms and conditions of company. This data would also include (a) the information provided by the user in forms, (b) registration forms, (c) surveys and contests conducted by company.</p>
                        <p>We may use your Personal Information to contact you for membership related activities and marketing information appropriate to your interest. You may opt-out from such services from your profile setting.</p>

                    </li>
                    <li>
                        <p><strong>Disclosure:</strong> Company may disclose Personal Information: (i) pursuant to a directive or order of a government entity or statutory authority or any judicial or governmental agency or (ii) pursuant to any applicable laws, rules or regulations or direction of statutory or regulatory authority or stock exchange or order of a relevant court of law.</p>
                    </li>
                    <li>
                        <p><strong>Comments, Notice and User Content:</strong> The materials or testimonials submitted by you to the website and the comments posted by you are public. Company is not liable to make any changes and correction to the information, and company is not responsible for any copyright issues that arise from the information submitted by you</p>
                    </li>
                    <li>
                        <p><strong>Cookie Policy:</strong> During your visit to the website, the internet cookies may access your user ID, password and the browser information located on your computer hard disk to track the data and preferences about you. It is your choice to either accept or decline the cookies. Company may recognize your information next time when you visit website and customize your views according to your preferences.</p>
                    </li>
                    <li>
                        <p><strong>Policy Rights Change Time-to-Time:</strong> Company has all the rights to change and update the Privacy Policy at any time. It is your responsibility to be bound by the privacy statements, whether you have visited the Website before the change in privacy policies or after the change.</p>
                        <p>If in case you have any concern, you can contact our Grievance Officer during the official working hours (Monday - Friday 9:00 AM to 6:00 PM IST) to address any discrepancies / grievances with regard to the data provided.
                        </p>


                        <p class="paraLegal"> Email: legal@innovationroots.com</p>
                        <p class="paraLegal">Contact: 080 41489100</p>



                    </li>
                    <li><p><strong>Dispute Resolution:</strong>
                        
                            Any dispute that arises in relation to and under the present privacy policy will be subject to the jurisdiction of the Courts in Bangalore, India.</p>
                    </li>
                    <li><p><strong>Contact Information:</strong>
                        Company is located in Bellandur, Bengaluru, India. If you have any queries or suggestions regarding our privacy policies, please contact and provide the information to the site Administrator.</p>

                        <p class="paraLegal">Email : community@innovationroots.com</p>
                        <p class="paraLegal">Postal Address: No 94, 17/1, Ambalipura, Bellandur Gate, Bengaluru, Karnataka, India- 560102</p>
                    </li>
                </ul>
                <p class="paraLegal">This privacy statement is effective from 16 February 2018</p>
                <p class="paraLegal">Copyright © 2018 <strong class="innoroo">INNOVATION ROOTS </strong>Softech Pvt Ltd. All Rights Reserved.</p>
            </div>
        </div>
    </section>
    <?php include('../../includes/footer.php');?>
    
     <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>
    <!--end pure chat-->
    
    <script type="text/javascript" src="../../inc/assets/js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="../../inc/assets/js/bootstrap.min.js"></script>
</body>

</html>
