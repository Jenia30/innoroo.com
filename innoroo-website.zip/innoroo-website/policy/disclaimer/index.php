<!--Updated On 28-03-2018GA
meta tag updated
-->

<!DOCTYPE html>
<html lang=en>

<head>
	<title>INNOVATION ROOTS | Policy | Disclaimer</title>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- OPEN GRAPH META TAG STARTS -->
	<meta property='og:title' content='INNOVATION ROOTS' />
	<meta property="og:image" content="http://innovationroots.com/test.innoroo.com/inc/assets/img/agile-transformation/agile-transformation.png" />
	<meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
	<meta property="og:url" content="www.innoroo.com" />
	<!-- OPEN GRAPH META TAG ENDS -->
	<meta name="description" content="If you require any more information or have any questions contact our site’s disclaimer.">
	<meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
	<meta name="ROBOTS" content="INDEX, FOLLOW">
	<link href="../..//inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
	<link href="../../inc/assets/css/bootstrap.min.css" rel="stylesheet" />
	<link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="../../inc/assets/css/main.css" rel="stylesheet" />
	<script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
	<link rel="shortcut icon" type=image/x-icon href="../../inc/assets/img/favicon.ico">
	<script>
		(function(d, e, j, h, f, c, b) {
			d.GoogleAnalyticsObject = f;
			d[f] = d[f] || function() {
				(d[f].q = d[f].q || []).push(arguments)
			}, d[f].l = 1 * new Date();
			c = e.createElement(j), b = e.getElementsByTagName(j)[0];
			c.async = 1;
			c.src = h;
			b.parentNode.insertBefore(c, b)
		})(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
		ga("create", "UA-100332682-2", "auto");
		ga("send", "pageview");

	</script>
	<script type="text/javascript">
		document.oncontextmenu = new Function("return false");
		document.onselectstart = new Function("return false");
		if (window.sidebar) {
			document.onmousedown = new Function("return false");
			document.onclick = new Function("return true");

			document.oncut = new Function("return false");

			document.oncopy = new Function("return false");


			document.onpaste = new Function("return false");
		}

	</script>


	<!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
</head>

<body>
	<?php include('../../includes/header.php');?>
	<section class="section_margin_gen legal_head">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2 class="heading_innoroo" style="text-align:left">Disclaimer </h2>
				</div>
			</div>
		</div>
	</section>
	<section class="legal_section">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<ul>

						<!-- DP Text Start -->
						<!-- Updated DP v.10.Jan.2018.15:30:00 NA by PP -->

						<!-- PMI Start -->

						<li class="policy_li_list"> Project Management Professional (PMP)®, and PMI Agile Certified Practitioner (PMI ACP)® are registered trademarks of <a href="https://www.pmi.org" target="_blank">Project Management Institute, Inc.</a></li>

						<!-- PMI End -->

						<!-- SA Start -->

						<li class="policy_li_list"> Certified Scrum Product Owner® (CSPO), Certified ScrumMaster® (CSM), Certified Scrum Trainer® (CST), Certified Scrum Developer® (CSD®), Advanced Certified Scrum Product Owner™ (A-CSPO™), Advanced Certified ScrumMaster™ (A-CSM™), and Certified Agile Leadership 1 (CAL 1) are registered trademarks of <a href="https://www.scrumalliance.org" style="text-decoration:none"> Scrum Alliance</a></li>

						<!-- SA End -->

						<!-- S.org Start -->

						<li class="policy_li_list"> Professional Scrum Master (PSM), Professional Scrum Developer (PSD), Professional Scrum Product Owner (PSPO), and Scaled Professional Scrum (SPS) are registered trademarks of <a href="https://www.scrum.org/" style="text-decoration:none"> Scrum.org</a></li>

						<!-- S.org End -->

						<!-- SAI Start -->

						<li class="policy_li_list">Scaled Agile Framework (SAFe®), SAFe for Teams, Leading SAFe®, Implementing SAFe®, SAFe® Product Owner/ Product Manager, and SAFe® Advanced Scrum Master are registered trademarks of <a href="http://www.scaledagile.com" style="text-decoration:none"> Scaled Agile, Inc.</a></li>

						<!-- SAI End -->

						<!-- LKU Start -->

						<li class="policy_li_list">Enterprise Service Planning (ESP), Team Kanban Practitioner (TKP), Accredited Kanban Trainer (AKT), Kanban System Design, Kanban Management Professional and Kanban Coaching Professional are registered trademarks of <a href=" http://leankanban.com" style="text-decoration: none;"> Lean Kanban, Inc.</a></li>

						<!-- LKU End -->


						<!-- DAC Start -->

						<li class="policy_li_list"> Disciplined Agilist (DA), Certified Disciplined Agilist (CDA), Certified Disciplined Agile Practitioner (CDAP), and Certified Disciplined Agile Coach (CDAC) are registered trademarks of <a href="https://disciplinedagileconsortium.org/Home" style="text-decoration: none;">Disciplined Agile Consortium.</a></li>

						<!-- DAC End -->

						<!-- DI Start -->


						<li class="policy_li_list"> DevOps Leader (DOL)SM, DevOps Test Engineering (DTE)®, DevSecOps Engineering (DSOE)SM, Certified Agile Process Owner®, and Certified Agile Service Manager® are registered trademarks of <a href="https://devopsinstitute.com/" style="text-decoration: none;">DevOps Institute.</a></li>

						<!-- DI End -->

						<!-- CE Start -->

						<li class="policy_li_list"> Cynefin and Complexity MasterClass is the registered trademark of Dave Snowden ( Creator of Cynefin and Complexity) and <a href="http://cognitive-edge.com" style="text-decoration: none;">Cognitive Edge.</a></li>

						<!-- CE End -->

						<!-- HoA Start -->

						<li class="policy_li_list"> Heart of Agile is the registered trademark of Alistair Cockburn (Co-creator of Agile Manifesto and President, Humans & Technology Inc.) and <a href="http://heartofagile.com/" style="text-decoration: none;">Heart of Agile. </a></li>

						<!-- HoA End -->

						<!-- XM Start -->

						<li class="policy_li_list"> X-Matrix is the registered trademark of Karl Scotland and <a href="https://availagility.co.uk/" style="text-decoration: none;">AvailAgility. </a></li>

						<!-- XM End -->

						<!-- DP Text End -->

					</ul>
				</div>
			</div>
		</div>
	</section>
	<?php include('../../includes/footer.php');?>
    
     <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>
    <!--end pure chat-->
    
    
	<script type="text/javascript" src="../../inc/assets/js/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="../../inc/assets/js/bootstrap.min.js"></script>
</body>

</html>
