<!--Updated On 07-07-2018 MI
meta tag updated
-->

<!DOCTYPE html>
<html lang="en">
<?php
if($_POST)
{

	$name = $_POST['name'];
        $from       = $_POST['email'];
        $phone      =$_POST['phone'];
    
        if($name != '' && $from != '' && $phone !='')
        {
        
        $event      = $_POST['data-events'];
        $location = $_POST['data-location'];
        $dt = $_POST['data-dt'];
        $to         = 'community@innovationroots.com';
        $subject    = 'Register - '.$event;
        $message    = '<html>
                        <head>
                          <title>'.$subject.'</title>
                        </head>
                        <body>
                          <table cellspacing="5" cellpadding="5">
                            <tr>
                              <th>Name : </th><td>'.$name.'</td>
                            </tr>
                            <tr>
                              <th>Email : </th><td>'.$from.'</td>
                            </tr>
                            <tr>
                              <th>Phone : </th><td>'.$phone.'</td>
                            </tr>
                            <tr>
                              <th>Event : </th><td>'.$event.'</td>
                            </tr>
                            <tr>
                              <th>Location : </th><td>'.$location.'</td>
                            </tr>
                            <tr>
                              <th>Date : </th><td>'.$dt.'</td>
                            </tr>
                          </table>
                        </body>
                       </html>';
        $headers  = 'MIME-Version: 1.0'."\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";
        if($from != ''){
            if(mail($to, $subject, $message, $headers))
                header("location:http://innovationroots.com/");
            else
                echo "<span class='text-danger'>Problem sending email</span>";
        }
        }
    
    }
?>

	<head>
		<meta name="google-site-verification" content="2RxPEMEJ3Vw7pu7BJ9I-zgwbmiEK6uJM3Ulq8ImrBZE" />
		<title>INNOVATION ROOTS | Pioneers in Agile consulting | services | Advanced Scrum Master </title>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">   
        
        <!--Description Tag Meta Start-->
    <!--Updated for 07.07.18 version MI-->
		<meta name="description" content="Checkout this page and enlist yourself on approaching instructional courses on SAFe, Kanban, Advanced Scrum Master and Leading SAFe">
		<meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
		<meta name="ROBOTS" content="INDEX, FOLLOW">
        
		<!-- OPEN GRAPH META TAG STARTS -->
		<meta property='og:title' content='INNOVATION ROOTS' />
		<meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
		<meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
		<meta property="og:url" content="www.innoroo.com" />        
		<!-- OPEN GRAPH META TAG ENDS -->
        
		<link href="inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
		<link href="inc/assets/css/bootstrap.min.css" rel="stylesheet" />
		<link type="text/css" rel="stylesheet" href="inc/assets/css/newsletter_form.css" />
		<!-- Icon Fonts -->
        
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link href="inc/assets/css/main.css" rel="stylesheet" />
		<link rel="shortcut icon" type="image/x-icon" href="inc/assets/img/favicon.ico">
		<script src="inc/assets/js/modernizr.custom.83079.js"></script>


		<script>
			(function(d, e, j, h, f, c, b) {
				d.GoogleAnalyticsObject = f;
				d[f] = d[f] || function() {
					(d[f].q = d[f].q || []).push(arguments)
				}, d[f].l = 1 * new Date();
				c = e.createElement(j), b = e.getElementsByTagName(j)[0];
				c.async = 1;
				c.src = h;
				b.parentNode.insertBefore(c, b)
			})(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
			ga("create", "UA-100332682-2", "auto");
			ga("send", "pageview");

		</script>

		<script src=https://www.google.com/recaptcha/api.js></script>

		<script type="text/javascript">
			document.oncontextmenu = new Function("return false");
			document.onselectstart = new Function("return false");
			if (window.sidebar) {
				document.onmousedown = new Function("return false");
				document.onclick = new Function("return true");
				document.oncut = new Function("return false");
				document.oncopy = new Function("return false");
				document.onpaste = new Function("return false");
			}

		</script>


		<style>
			table {
				width: 100%;
				border-collapse: collapse;
				font-size: 13px
			}

			* {
				-webkit-hyphens: none
			}

			th {
				font-weight: bold;
				padding: 6px;
				background-color: white;
				text-align: center!important;
				border-bottom: 2px solid #ddd
			}

			td {
				padding: 6px;
				background-color: white;
				text-align: center;
				border-bottom: 1px solid #ddd
			}

			@media screen and (max-width:768px) {
				td {
					white-space: normal!important
				}
			}

			@media only screen and (max-width:760px),
			(min-device-width:768px) and (max-device-width:1024px) {
				table,
				thead,
				tbody,
				th,
				td,
				tr {
					display: block
				}
				thead tr {
					position: absolute;
					top: -9999px;
					left: -9999px
				}
				tr {
					border: 1px solid #ccc
				}
				td {
					border: 0;
					border-bottom: 1px solid #eee;
					position: relative;
					padding-left: 50%
				}
				td:before {
					position: absolute;
					top: 0;
					left: 6px;
					width: 45%;
					position: relative;
					padding-right: 10px;
					white-space: nowrap;
					font-weight: bold
				}
				td:nth-of-type(1):before {
					content: "Event: "
				}
				td:nth-of-type(2):before {
					content: "Certification/Credentials:  "
				}
				td:nth-of-type(3):before {
					content: "Trainer:  "
				}
				td:nth-of-type(4):before {
					content: "Date:  "
				}
				td:nth-of-type(5):before {
					content: "Location: "
				}
				td:nth-of-type(6):before {
					content: "   "
				}
			}

		</style>
	</head>

	<body>
		<?php include ('includes/header.php');?>

		<!---------------START FEATURE IMAGE-------------------->
		<section class="home-cover banner-container">
			<div class="container hero-carousel">
				<div id="myCarousel" class="carousel slide carousel-fade" data-ride="carousel">
					<ol class=carousel-indicators>
						<li data-target="#myCarousel" data-slide-to=0 class="active"></li>
						<li data-target="#myCarousel" data-slide-to=1></li>
                        <li data-target="#myCarousel" data-slide-to=2></li>
                        <li data-target="#myCarousel" data-slide-to=3></li>
                        <li data-target="#myCarousel" data-slide-to=4></li>
                        <li data-target="#myCarousel" data-slide-to=5></li>
                        <li data-target="#myCarousel" data-slide-to=6></li>
                        <li data-target="#myCarousel" data-slide-to=7></li>
                        <li data-target="#myCarousel" data-slide-to=8></li>
                        <li data-target="#myCarousel" data-slide-to=9></li>
                        <li data-target="#myCarousel" data-slide-to=10></li>
					</ol>
					<div class="carousel-inner" role="listbox">	
                        
                        
                         <!-------------start Priyank PMPO------------->
                        <div class="item active">
                            <img src="inc/assets/img/homeslides/priyank-pathak.jpg" alt="Priyank Pathak" width="100%" class="dekstopFeature">
                            <img src="inc/assets/img/homeslides/priyank-pathak-tablet.jpg" alt="Priyank Pathak" width="100%" class="tabFeature" style="display:none">
                            <div class="col-sm-11 col-sm-offset-1 col-xs-12 caption-feature-slider1">
                                <div class="col-sm-6 col-sm-offset-6 col-xs-6 col-xs-offset-6 padd0">
                                    <div class="col-sm-10 col-xs-12 headingMain paddRight">
                                        <h2 class=slider-title1>SAFe<sup>&reg;</sup> 4.5 Product Owner / Product Manager Workshop</h2>
                                        <h5 class=slider-title2>21 - 22 July 2018</h5>
                                    </div>
                                    <div class="col-sm-12 col-xs-12 featureDetails paddRight">
                                        <h1 class=name_speaker>Priyank Pathak</h1>
                                        <ul>
                                            <li>(Agile Coach and Trainer)</li>
                                            <li>Curator, INNOVATION ROOTS</li>
                                        </ul>
                                    </div>
                                    <div class="col-sm-12 col-xs-12 knowMore paddRight">
                                        <a href=events/safe-4.5-product-owner-product-manager-with-safe-4-product-owner-product-manager-certification-priyank-pathak-gurugram-21-22-july-2018/ >
                                        <button class="btn">KNOW MORE</button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-------------end Priyank PMPO-------------> 
                        
                        
                         <!-------------start Priyank SAFe Advanced Scrum Master------------->
                        <div class="item ">
                            <img src="inc/assets/img/homeslides/priyank-pathak.jpg" alt="Priyank Pathak" width="100%" class="dekstopFeature">
                            <img src="inc/assets/img/homeslides/priyank-pathak-tablet.jpg" alt="Priyank Pathak" width="100%" class="tabFeature" style="display:none">
                            <div class="col-sm-11 col-sm-offset-1 col-xs-12 caption-feature-slider1">
                                <div class="col-sm-6 col-sm-offset-6 col-xs-6 col-xs-offset-6 padd0">
                                    <div class="col-sm-10 col-xs-12 headingMain paddRight">
                                        <h2 class=slider-title1>SAFe<sup>&reg;</sup> 4.5 Advanced Scrum Master Workshop</h2>
                                        <h5 class=slider-title2>28 - 29 July 2018</h5>
                                    </div>
                                    <div class="col-sm-12 col-xs-12 featureDetails paddRight">
                                        <h1 class=name_speaker>Priyank Pathak</h1>
                                        <ul>
                                            <li>(Agile Coach and Trainer)</li>
                                            <li>Curator, INNOVATION ROOTS</li>
                                        </ul>
                                    </div>
                                    <div class="col-sm-12 col-xs-12 knowMore paddRight">
                                        <a href=events/safe-4.5-advanced-scrum-master-with-safe-4-advanced-scrum-master-certification-priyank-pathak-bengaluru-28-29-july-2018/ >
                                        <button class="btn">KNOW MORE</button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-------------end Priyank SAFe Advanced Scrum Master-------------> 
                        
                        <!-------------start Janice------------->
                        <div class="item ">
                            <img src="inc/assets/img/homeslides/Janice-linden-reed.jpg" alt="Janice Linden Reed" width="100%" class="dekstopFeature">
                            <img src="inc/assets/img/homeslides/Janice-linden-reed-tablet.jpg" alt="Janice Linden Reed" width="100%" class="tabFeature" style="display:none">
                            <div class="col-sm-11 col-sm-offset-1 col-xs-12 caption-feature-slider1">
                                <div class="col-sm-6 col-sm-offset-6 col-xs-6 col-xs-offset-6 padd0">
                                    <div class="col-sm-10 col-xs-12 headingMain paddRight">
                                        <h2 class=slider-title1>Accredited Kanban Trainer Workshop</h2>
                                        <h5 class=slider-title2>16 - 20 September 2018</h5>
                                    </div>
                                    <div class="col-sm-12 col-xs-12 featureDetails paddRight">
                                        <h1 class=name_speaker>Janice Linden-Reed</h1>
                                        <ul>
                                            <li>(Accredited Kanban Trainer)</li>
                                            <li>Chief Program Officer at Lean Kanban, Inc.</li>
                                        </ul>
                                    </div>
                                    <div class="col-sm-12 col-xs-12 knowMore paddRight">
                                        <a href=events/accredited-kanban-trainer-janice-linden-reed-bengaluru-16-20-september-2018/ >
                                        <button class="btn">KNOW MORE</button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-------------end Janice-------------> 
                        
                        <!-------------start Papyrus City Kanban workshop------------->
                        <div class="item">
                            <img src="inc/assets/img/homeslides/masa-k-maeda.jpg" alt="Masa K Maeda" width="100%" class="dekstopFeature">
                            <img src="inc/assets/img/homeslides/masa-k-maeda-tablet.jpg" alt="Masa K Maeda" width="100%" class="tabFeature" style="display:none">
                            <div class="col-sm-11 col-sm-offset-1 col-xs-12 caption-feature-slider1">
                                <div class="col-sm-6 col-sm-offset-6 col-xs-6 col-xs-offset-6 padd0">
                                    <div class="col-sm-10 col-xs-12 headingMain paddRight">
                                        <h2 class=slider-title1>Papyrus City Kanban Workshop</h2>
                                        <h5 class=slider-title2>20 September 2018</h5>
                                    </div>
                                    <div class="col-sm-12 col-xs-12 featureDetails paddRight">
                                        <h1 class=name_speaker>Masa K Maeda</h1>
                                        <ul>
                                            <li>(Principal Coach)</li>
                                            <li>CEO and Founder, Valueinnova</li>
                                        </ul>
                                    </div>
                                    <div class="col-sm-12 col-xs-12 knowMore paddRight">
                                        <a href=events/papyrus-city-kanban-workshop-masa-k-maeda-bengaluru-20-september-2018/ >
                                        <button class="btn">KNOW MORE</button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-------------end Papyrus City Kanban workshop-------------> 
                        
						<!-------------start Lean Kanban------------->
						<div class="item leanKanbanFeatureImage">
							<img src="inc/assets/img/homeslides/lean-kanban-india.jpg" alt="Lean Kanban" width="100%" class="dekstopFeature">
							<img src="inc/assets/img/homeslides/lean-kanban-india-tablet.jpg" alt="Lean Kanban" width="100%" class="tabFeature" style="display:none">
							<div class="col-sm-11 col-sm-offset-1 col-xs-12 caption-feature-slider1 caption-feature-leanagilegile1">
								<div class="col-sm-6 col-sm-offset-6 col-xs-6 col-xs-offset-6 padd0 ">
									<div class="col-sm-10 col-xs-12 headingMain leanagileheadingMain paddRight">
										<h2 class="slider-title1">LEAN KANBAN INDIA 2018 CONFERENCE</h2>
										<h5 class="slider-title2">21 - 22 September 2018 </h5>
									</div>
									<div class="col-sm-12 col-xs-12 featureDetails leanagilefeatureDetails paddRight">
										<h1 class="name_speaker">Bengaluru</h1>
										<ul>
											<li>India</li>
										</ul>
									</div>
									<div class="col-sm-12 knowMore paddRight">
										<a href=" http://www.leankanbanindia.com">
                                    <button class="btn">KNOW MORE</button></a>
									</div>
								</div>
							</div>
						</div>
						<!-------------end Lean Kanban------------->
                        
                        <!-------------start Okaloa flowlab workshop------------->
                        <div class="item">
                            <img src="inc/assets/img/homeslides/patrick-steyaert.jpg" alt="Patrick Steyaert" width="100%" class="dekstopFeature">
                            <img src="inc/assets/img/homeslides/patrick-steyaert-tablet.jpg" alt="Patrick Steyaert" width="100%" class="tabFeature" style="display:none">
                            <div class="col-sm-11 col-sm-offset-1 col-xs-12 caption-feature-slider1">
                                <div class="col-sm-6 col-sm-offset-6 col-xs-6 col-xs-offset-6 padd0">
                                    <div class="col-sm-10 col-xs-12 headingMain paddRight">
                                        <h2 class=slider-title1>Okaloa Flowlab Workshop</h2>
                                        <h5 class=slider-title2>23 September 2018</h5>
                                    </div>
                                    <div class="col-sm-12 col-xs-12 featureDetails paddRight">
                                        <h1 class=name_speaker>Patrick Steyaert</h1>
                                        <ul>
                                            <li>(Principal Coach and Trainer)</li>
                                            <li>Founder, Okaloa</li>
                                        </ul>
                                    </div>
                                    <div class="col-sm-12 col-xs-12 knowMore paddRight">
                                        <a href=events/okaloa-flowlab-workshop-patrick-steyaert-bengaluru-23-september-2018/ >
                                        <button class="btn">KNOW MORE</button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-------------end Okaloa flowlab workshop-------------> 
                        
                        <!-------------start Kanban Management Professional (KMP II) Workshop------------->
                        <div class="item">
                            <img src="inc/assets/img/homeslides/alexei-zheglov.jpg" alt="Alexei Zheglov" width="100%" class="dekstopFeature">
                            <img src="inc/assets/img/homeslides/alexei-zheglov-tablet.jpg" alt="Alexei Zheglov" width="100%" class="tabFeature" style="display:none">
                            <div class="col-sm-11 col-sm-offset-1 col-xs-12 caption-feature-slider1">
                                <div class="col-sm-6 col-sm-offset-6 col-xs-6 col-xs-offset-6 padd0">
                                    <div class="col-sm-10 col-xs-12 headingMain paddRight">
                                        <h2 class=slider-title1>Kanban Management Professional (KMP II) Workshop</h2>
                                        <h5 class=slider-title2>24 - 25 September 2018</h5>
                                    </div>
                                    <div class="col-sm-12 col-xs-12 featureDetails paddRight">
                                        <h1 class=name_speaker>Alexei Zheglov</h1>
                                        <ul>
                                            <li>(Accredited Kanban Trainer)</li>
                                            <li>Founder, Lean A-to-Z Inc.</li>
                                        </ul>
                                    </div>
                                    <div class="col-sm-12 col-xs-12 knowMore paddRight">
                                        <a href=events/kanban-management-professional-alexei-zheglov-bengaluru-24-25-september-2018/ >
                                        <button class="btn">KNOW MORE</button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-------------end Kanban Management Professional (KMP II) Workshop-------------> 
                        
                        
                        <!-------------start KCP Workshop------------->
                        <div class="item">
                            <img src="inc/assets/img/homeslides/workshops.jpg" alt="KMM Workshop" width="100%" class="dekstopFeature">
                            <img src="inc/assets/img/homeslides/workshops-tablet.jpg" alt="KMM Workshop" width="100%" class="tabFeature" style="display:none">
                            <div class="col-sm-11 col-sm-offset-1 col-xs-12 caption-feature-slider1">
                                <div class="col-sm-6 col-sm-offset-6 col-xs-6 col-xs-offset-6 padd0">
                                    <div class="col-sm-10 col-xs-12 headingMain paddRight">
                                        <h2 class=slider-title1>Kanban Coaching Professional Masterclass</h2>
                                        <h5 class=slider-title2>24 - 28 September 2018</h5>
                                    </div>
                                    <div class="col-sm-11 col-xs-12 featureDetails paddRight dekstopView">
                                        <div class="col-sm-6 padding0">
                                        <h1 class=name_speaker>David J. Anderson</h1>
                                        <ul>
                                            <li>(Originator of the Kanban Method)</li>
                                            <li>Chairman of Lean Kanban Inc.</li>
                                        </ul>
                                            </div>
                                        <div class="col-sm-6 padding0">
                                            <h1 class="name_speaker">
                                                Teodora Bozheva
                                            </h1>
                                            <ul>
                                            <li>(Principal Trainer and Coach)</li>
                                            <li>Co-Founder, Berriprocess</li>
                                        </ul>
                                        </div>
                                    </div>
                                    <div class="col-sm-11 col-xs-12 featureDetails paddRight mobileView">
                                        <h1 class="name_speaker">David J. Anderson and Teodora Bozheva</h1>
                                        <ul>
                                            <li>Bengaluru</li>
                                            <li>India</li>
                                        
                                        </ul>
                                        
                                    </div>
                                    <div class="col-sm-12 col-xs-12 knowMore paddRight">
                                        <a href=events/kanban-coaching-professional-david-j-anderson-and-teodora-bozheva-bengaluru-24-28-september-2018/ >
                                        <button class="btn">KNOW MORE</button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-------------end KCP Workshop------------->
                        
                        <!-------------start KMM Workshop------------->
                        <div class="item">
                            <img src="inc/assets/img/homeslides/workshops.jpg" alt="KMM Workshop" width="100%" class="dekstopFeature">
                            <img src="inc/assets/img/homeslides/workshops-tablet.jpg" alt="KMM Workshop" width="100%" class="tabFeature" style="display:none">
                            <div class="col-sm-11 col-sm-offset-1 col-xs-12 caption-feature-slider1">
                                <div class="col-sm-6 col-sm-offset-6 col-xs-6 col-xs-offset-6 padd0">
                                    <div class="col-sm-10 col-xs-12 headingMain paddRight">
                                        <h2 class=slider-title1>Kanban Maturity Model Masterclass</h2>
                                        <h5 class=slider-title2>24 - 26 September 2018</h5>
                                    </div>
                                    <div class="col-sm-11 col-xs-12 featureDetails paddRight dekstopView">
                                        <div class="col-sm-6 padding0">
                                        <h1 class=name_speaker>David J. Anderson</h1>
                                        <ul>
                                            <li>(Originator of the Kanban Method)</li>
                                            <li>Chairman of Lean Kanban Inc.</li>
                                        </ul>
                                            </div>
                                        <div class="col-sm-6 padding0">
                                            <h1 class="name_speaker">
                                                Teodora Bozheva
                                            </h1>
                                            <ul>
                                            <li>(Principal Trainer and Coach)</li>
                                            <li>Co-Founder, Berriprocess</li>
                                        </ul>
                                        </div>
                                    </div>
                                    <div class="col-sm-11 col-xs-12 featureDetails paddRight mobileView">
                                        <h1 class="name_speaker">David J. Anderson and Teodora Bozheva</h1>
                                        <ul>
                                            <li>Bengaluru</li>
                                            <li>India</li>
                                        
                                        </ul>
                                        
                                    </div>
                                    <div class="col-sm-12 col-xs-12 knowMore paddRight">
                                        <a href=events/kanban-maturity-model-masterclass-david-j-anderson-and-teodora-bozheva-bengaluru-24-26-september-2018/ >
                                        <button class="btn">KNOW MORE</button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-------------end KMM Workshop-------------> 
                        
                        <!-------------start KLMM Workshop------------->
                        <div class="item">
                            <img src="inc/assets/img/homeslides/workshops.jpg" alt="KMM Workshop" width="100%" class="dekstopFeature">
                            <img src="inc/assets/img/homeslides/workshops-tablet.jpg" alt="KMM Workshop" width="100%" class="tabFeature" style="display:none">
                            <div class="col-sm-11 col-sm-offset-1 col-xs-12 caption-feature-slider1">
                                <div class="col-sm-6 col-sm-offset-6 col-xs-6 col-xs-offset-6 padd0">
                                    <div class="col-sm-10 col-xs-12 headingMain paddRight">
                                        <h2 class=slider-title1>Kanban Leadership Maturity Masterclass</h2>
                                        <h5 class=slider-title2>27 - 28 September 2018</h5>
                                    </div>
                                    <div class="col-sm-11 col-xs-12 featureDetails paddRight dekstopView">
                                        <div class="col-sm-6 padding0">
                                        <h1 class=name_speaker>David J. Anderson</h1>
                                        <ul>
                                            <li>(Originator of the Kanban Method)</li>
                                            <li>Chairman of Lean Kanban Inc.</li>
                                        </ul>
                                            </div>
                                        <div class="col-sm-6 padding0">
                                            <h1 class="name_speaker">
                                                Teodora Bozheva
                                            </h1>
                                            <ul>
                                            <li>(Principal Trainer and Coach)</li>
                                            <li>Co-Founder, Berriprocess</li>
                                        </ul>
                                        </div>
                                    </div>
                                    <div class="col-sm-11 col-xs-12 featureDetails paddRight mobileView">
                                        <h1 class="name_speaker">David J. Anderson and Teodora Bozheva</h1>
                                        <ul>
                                            <li>Bengaluru</li>
                                            <li>India</li>
                                        
                                        </ul>
                                        
                                    </div>
                                    <div class="col-sm-12 col-xs-12 knowMore paddRight">
                                        <a href=events/kanban-leadership-maturity-masterclass-david-j-anderson-and-teodora-bozheva-bengaluru-27-28-september-2018/ >
                                        <button class="btn">KNOW MORE</button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-------------end KLMM Workshop-------------> 
                        
                        
                        <!-------------start Certified LeSS Practitioner Workshop------------->
						<div class="item leanKanbanFeatureImage">
							<img src="inc/assets/img/homeslides/venkatesh-krishnamurthy.jpg" alt="Venkatesh Krishnamurthy" width="100%" class="dekstopFeature">
							<img src="inc/assets/img/homeslides/venkatesh-krishnamurthy-tablet.jpg" alt="Venkatesh Krishnamurthy" width="100%" class="tabFeature" style="display:none">
							<div class="col-sm-11 col-sm-offset-1 col-xs-12 caption-feature-slider1 caption-feature-leanagilegile1">
								<div class="col-sm-6 col-sm-offset-6 col-xs-6 col-xs-offset-6 padd0 ">
									<div class="col-sm-10 col-xs-12 headingMain leanagileheadingMain paddRight">
										<h2 class="slider-title1">Certified LeSS Practitioner Workshop</h2>
										<h5 class="slider-title2">05 - 07 October 2018 </h5>
									</div>
									<div class="col-sm-12 col-xs-12 featureDetails paddRight">
                                        <h1 class=name_speaker>Venkatesh Krishnamurthy</h1>
                                        <ul>
                                            <li>(Certified LeSS Trainer)</li>
                                            <li>Founder & Director "The Empirical Coach Pty Ltd</li>
                                        </ul>
                                    </div>
									<div class="col-sm-12 knowMore paddRight">
										<a href="events/certified-less-practitioner-workshop-venkatesh-krishnamurthy-bengaluru-05-07-october-2018/">
                                    <button class="btn">KNOW MORE</button></a>
									</div>
								</div>
							</div>
						</div>
						<!-------------end Certified LeSS Practitioner Workshop------------->
					</div>
				</div>
			</div>
		</section>
		<!---------------END FEATURE IMAGE-------------------->

		<!---------------START SERVICE SECTION-------------------->
		<section style="margin:0px">
			<div class="container">

				<div class="col-sm-12 ourServices">
					<h2 class="sectionTitle">Business Agility and Beyond</h2>
					<p class="ourServicesP">Leading the Change in Agile Transformation</p>
					<div class="col-sm-12 col-xs-12 serviceIcons padding0">
						<div class="col-sm-4 col-xs-12 images padding0">
							<div class="col-sm-12 col-sm-offset-0 col-xs-10 col-xs-offset-1 padd0">
								<img src="inc/assets/img/services/consulting.png" width="100%" alt="consulting">
							</div>
							<div class="col-sm-12 col-xs-12 padd0">
								<h3 class="sectionSubtitle">Consulting Services</h3>
								<p>
									Our Advisory provides cutting edge, Strategic, Leadership, Management and Transformation Consulting Services
								</p>
							</div>
						</div>
						<div class="col-sm-4 col-xs-12 images padding0">
							<div class="col-sm-12 col-sm-offset-0 col-xs-10 col-xs-offset-1  padd0">
								<img src="inc/assets/img/services/training.png" width="100%" alt="Training">
							</div>
							<div class="col-sm-12 col-xs-12 padd0">
								<h3 class="sectionSubtitle">Training Services</h3>
								<p>
									Our Academy provides a wide range of Professional Trainings and Services for Public and Corporate setups
								</p>
							</div>
						</div>
						<div class="col-sm-4 col-xs-12 images padding0">
							<div class="col-sm-12 col-sm-offset-0 col-xs-10 col-xs-offset-1 padd0">
								<img src="inc/assets/img/services/publishing.png" width="100%" alt="publishing">
							</div>
							<div class="col-sm-12 col-xs-12 padd0">
								<h3 class="sectionSubtitle">Publishing Services</h3>
								<p>
									A pioneering Information Database of Publishing Services, full of informative ideas from the brightest minds
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!---------------END SERVICE SECTION-------------------->

		<!---------------START AGILE TRANSFORMATION SECTION-------------------->
		<section class="agile">
			<div class="container">
				<div class="col-sm-8 col-xs-8 agileTransformation ">
					<h2 class="sectionTitle">Deliver Exceptional Business Results</h2>
					<p>World-Class Agile Transformation Coaching, Assessment, Training and Consulting</p>
					<a href="offerings/agile-transformation">
                                <button class="btn">KNOW MORE</button>
                            </a>
				</div>

				<div class="col-sm-4 col-xs-4 agileTransformationImage padding0">
					<img src="inc/assets/img/agile-transformation/agile-transformation.png" width="100%" alt="Agile Transformation">
				</div>



			</div>
		</section>
		<!---------------end AGILE TRANSFORMATION SECTION-------------------->

		<!---------------START ANIMAL POKER SECTION-------------------->
		<section class="animalPokerGame" id="animal-estimation-game">
			<div class="container">
				<div class="col-sm-12 col-xs-12 animalPockerCard padd0">
					<div class="col-sm-7 col-xs-7 animalPocker animalPockerTagLine spacing pull-right">
						<h2 class="sectionTitle">Improve Your Estimation Capabilities
                            <p>Try our Innovative Animal-Themed Estimation and Planning Game</p> 
							<a href="resources/game/animal-estimation-game/"><button class="btn">KNOW MORE</button></a>
						</h2>
					</div>
					<div class="col-sm-6 col-xs-6 animalPockerImage padding0">
						<img src="inc/assets/img/game/poker-card.png" width="100%" alt="Animal Pocker">
					</div>
				</div>
			</div>
		</section>
		<!---------------END ANIMAL POKER SECTION-------------------->

		<!----------START SPECIAL FEATURE TRAINING LISTING----------->
		<section class="safeSection">
			<div class="container">
				<div class="col-sm-6 col-xs-6 safeListing">
					<h2 class="sectionTitle">Become Certified on SAFe<sup>&reg;</sup></h2>
					<p>Get Trained from renowned Industry Experts</p>
					<a href="offerings/scaled-agile-framework/">
                        <button class="btn">KNOW MORE</button>
                    </a>
				</div>
				<div class="col-sm-6 col-xs-6 safeImage padding0">
					<img src="inc/assets/img/safe/safe.png" width="100%" alt="Training Listing">
				</div>
			</div>
		</section>
        <!----------end SPECIAL FEATURE TRAINING LISTING----------->

		<!-----------------------partner--------------------------->

		<!--
        <div class="col-sm-12 partner" style="height: 400px;
    background-color: #f30808;">
        
        
        </div>
-->

		<!------------------partner---------------->


		<!------------------start trainers---------------->
		<section style="margin:0!important" id="speakers">
			<div class="container">
				<div class="col-md-12 col-sm-12 col-xs-12 padding0">
					<div class="row ourTrainers">
						<h2 class="sectionTitle">Meet our Trainers</h2>
						<p>Thousand plus Professionals are already trained</p>
						<div class="col-md-4 col-sm-6 col-sm-12">
							<div class="trainer_div trainer_list">
								<img class="img-responsive img_trainer" src="inc/assets/img/trainer/trainer-bhaskar.png" alt="Bhaskar Rao" class=image_trainers>
								<div class="trainer_des trainer">
									<h4 class="trainer_name">Bhaskar Rao</h4>
									<h5 class="trainer_designation">
										SAFe<sup>&reg;</sup> Program Consultant (SPC4)
									</h5>
									<h5 class="trainer_designation">
										Lead Consultant
									</h5>
									<h5 class="trainer_designation">
										<strong class="innoroo">INNOVATION ROOTS</strong>
									</h5>
								</div>
							</div>
						</div>
						<div class="col-md-4 col-sm-6 col-sm-12">
							<div class="trainer_div trainer_list">
								<img class="img-responsive img_trainer" src="inc/assets/img/trainer/trainer-prashant.png" alt="Prashant M J" class="image_trainers">
								<div class="trainer_des trainer">
									<h4 class="trainer_name">Prashant M J</h4>
									<h5 class="trainer_designation">
										SAFe<sup>&reg;</sup> Program Consultant (SPC4)
									</h5>
									<h5 class="trainer_designation">
										Consultant
									</h5>
									<h5 class="trainer_designation">
										<strong class="innoroo">INNOVATION ROOTS</strong>
									</h5>
								</div>
							</div>
						</div>
						<div class="col-md-4 col-sm-6 col-sm-12">
							<div class="trainer_div trainer_list">
								<img class="img-responsive img_trainer" src="inc/assets/img/trainer/trainer-priyank.png" alt="Priyank Pathak" class=image_trainers>
								<div class="trainer_des trainer">
									<h4 class="trainer_name">Priyank Pathak</h4>
									<h5 class="trainer_designation">
										Agile & Continuous Delivery Consultant
									</h5>
									<h5 class="trainer_designation">
										Curator
									</h5>
									<h5 class="trainer_designation">
										<strong class="innoroo">INNOVATION ROOTS</strong>
									</h5>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!------------------end trainers---------------->
        
		<!---------------START TESTIMONIAL SECTION-------------------->
		<section class="testimoniColor">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 col-xs-12 ">
						<div class=wrapper_testimonial_head>
							<h2 class="sectionTitle">Testimonials</h2>
							<p class="ourServicesP">What Industry Professionals are Saying About Us</p>
						</div>
					</div>
					<div class="col-sm-12 col-xs-12 testimonialCarousel">
						<div class="col-sm-2 col-xs-2 testimonialcaret left">
							<i class="fa fa-caret-left caretLeft" aria-hidden="true"></i>
						</div>
						<div class="col-sm-8 col-xs-8">
							<div class="carousel" id="myCarousel" data-ride="carousel">
								<div class="items main-pos" id="1" data-target="#myCarousel" data-slide-to="0" class="active">
									<img src="inc/assets/img/testimonial/satyabrata-dash.jpg" width="100%" alt="Satyabrata Dash">
								</div>
								<div class="items right-pos" id="2" data-target="#myCarousel" data-slide-to="1">
									<img src="inc/assets/img/testimonial/karthik-jayaraj.jpg" width="100%" alt="Karthik Jayaraj">
								</div>

								<div class=" items left-pos" id="3" data-target="#myCarousel" data-slide-to="2">
									<img src="inc/assets/img/testimonial/sudipta-lahiri.jpg" width="100%" alt="Sudipta Lahiri">
								</div>
							</div>
						</div>
						<div class="col-sm-2 col-xs-2 testimonialcaret right">
							<i class="fa fa-caret-right caretRight" aria-hidden="true"></i>
						</div>
					</div>


					<div class="col-sm-12 col-xs-12 testimonialDetail carousel-inner padding0">
						<div class="col-sm-12 col-xs-12 padding0 padd0">
							<div class="col-sm-12 col-xs-12 firstTestimonial spacing ">

								<div class="col-sm-12 col-xs-12">
									<blockquote></blockquote><br>
									<div class="col-sm-11 col-sm-offset-1 col-xs-10 col-xs-offset-1 padding0">
										<p>I can't say enough as to how well-tailored the SAFe Agilist Workshop was for the entire two days. The course provided an outline of the scientific and methodical approach to human efficiency calculation and areas those would need focus in large scale product development. I would recommend the course to all agile enthusiasts in my sphere of influence to definitely register!</p>
									</div>
								</div>

								<div class="col-sm-5 testimonial">

									<h3>Satyabrata Dash</h3> <span>(Manager - GCS)</span>

									<h5>Pegasystems</h5>

								</div>
							</div>
							<div class="col-sm-12 col-xs-12 secondTestimonial spacing" style="display:none">
								<div class="col-sm-12 col-xs-12">
									<blockquote> </blockquote><br>
									<div class="col-sm-11 col-sm-offset-1 col-xs-10 col-xs-offset-1 padding0">
										<p>
											It was a good experience with the KMP I & II training and the Lean Kanban India conference as it gives lot of insights for us to accelerate the KANBAN in our organization. Also I was pleased with the 2016 conference to see the diversity of case studies of people from different geographical locations. I look forward for more events like this to explore."
										</p>
									</div>
								</div>
								<div class="col-sm-12 col-xs-12 testimonial">

									<h3>Karthik Jayaraj <span>(Team Leader)</span></h3>

									<h5>SKF Technologies India Pvt Ltd.</h5>

								</div>
							</div>
							<div class="col-sm-12 col-xs-12 thirdTestimonial spacing" style="display:none">
								<div class="col-sm-12 col-xs-12">
									<blockquote> </blockquote><br>
									<div class="col-sm-11 col-sm-offset-1 col-xs-10 col-xs-offset-1 padding0">
										<p>I have been associated with Innovation Roots for the last 4+ years. One thing that stands out in my interaction is their energy level. They have a sense of commitment and passion to spread the ecosystem of Lean/Agile development, they keep organizing various events at multiple platforms. I am sure their customers and partners benefit a lot from this high energy relationship."</p>
									</div>
								</div>
								<div class="col-sm-12 col-xs-12 testimonial">
									<h3>Sudipta Lahiri <span>(Head of Products)</span></h3>
									<h5>Digite Inc.</h5>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!---------------END TESTIMONIAL SECTION-------------------->

		<!---------------START CLIENTS SECTION-------------------->
		<section class="clientDivision">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 col-md-12">
						<div class="wrapper_testimonial_head">
							<h2 class="sectionTitle">Clients</h2>
							<p class="ourservicesP">Who Trust our Services</p>
						</div>
					</div>
				</div>
				<div class="col-sm-12 col-xs-12 ourCustomers">

					<div class="col-sm-2 col-xs-4">
						<img src="inc/assets/img/customers/customer-accenture.png" alt="accenture" width="100%">
					</div>
					<div class="col-sm-2 col-xs-4">
						<img src="inc/assets/img/customers/customer-cgi.png" alt="cgi" width="100%">
					</div>
					<div class="col-sm-2 col-xs-4 cliford">
						<img src="inc/assets/img/customers/customer-cliford-chance.png" alt="cliford" width="100%">
					</div>
					<div class="col-sm-2 col-xs-4">
						<img src="inc/assets/img/customers/customer-cognizant.png" alt="cognizant" width="100%">
					</div>
					<div class="col-sm-2 col-xs-4">
						<img src="inc/assets/img/customers/customer-evolvingSystem.png" alt="evolvingSystem" width="100%">
					</div>
					<div class="col-sm-2 col-xs-4">
						<img src="inc/assets/img/customers/customer-hp.png" alt="hp" width="100%">
					</div>
					<div class="col-sm-2 col-xs-4 clear">
						<img src="inc/assets/img/customers/customer-igate.png" alt="igate" width="100%">
					</div>
					<div class="col-sm-2 col-xs-4">
						<img src="inc/assets/img/customers/customer-infosys.png" alt="infosys" width="100%">
					</div>
					<div class="col-sm-2 col-xs-4">
						<img src="inc/assets/img/customers/customer-KPIT.png" alt="KPIT" width="100%">
					</div>
					<div class="col-sm-2 col-xs-4">
						<img src="inc/assets/img/customers/customer-LT-Infotech.png" alt="LT" width="100%">
					</div>
					<div class="col-sm-2 col-xs-4">
						<img src="inc/assets/img/customers/customer-mphasis.png" alt="mphasis" width="100%">
					</div>
					<div class="col-sm-2 col-xs-4">
						<img src="inc/assets/img/customers/customer-philips.png" alt="philips" width="100%">
					</div>
					<div class="col-sm-2 col-xs-4">
						<img src="inc/assets/img/customers/customer-premierBiosoft.png" alt="premierBiosoft" width="100%">
					</div>
					<div class="col-sm-2 col-xs-4">
						<img src="inc/assets/img/customers/customer-SG.png" alt="SG" width="100%">
					</div>
					<div class="col-sm-2 col-xs-4">
						<img src="inc/assets/img/customers/customer-SKF.png" alt="SKF" width="100%">
					</div>
					<div class="col-sm-2 col-xs-4">
						<img src="inc/assets/img/customers/customer-solarwind.png" alt="solarwind" width="100%">
					</div>
					<div class="col-sm-2 col-xs-4 sony">
						<img src="inc/assets/img/customers/customer-sony.png" alt="sony" width="100%">
					</div>
					<div class="col-sm-2 col-xs-4 sunLifeInsuarance">
						<img src="inc/assets/img/customers/customer-sunLifeInsuarance.png" alt="sunLifeInsuarance" width="100%">
					</div>

				</div>
			</div>
		</section>
		<!---------------START CLIENTS SECTION-------------------->

		<!---------------START MAP SECTION-------------------->
		<section class="mapSection">
			<div class="container">
				<div class="row hov mapContact padding0">
					<div class="col-sm-12 col-xs-12 officeMap padding0">
                        
						<div class="col-sm-7 col-xs-12 overlayOn padding0">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15555.04081161723!2d77.651443!3d12.923128!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xdd27628f4bc9dfb3!2sINNOVATION+ROOTS!5e0!3m2!1sen!2sin!4v1525149902963" width="100%" height="355" frameborder="0" style="border:0" allowfullscreen></iframe>
						</div>
						<div class="col-sm-7 col-xs-12 overlayMap padding0"></div>
						<div class="col-sm-5 col-xs-12 contactSiteDetails">
							<div class="col-sm-12">
								<ul>
									<li>BENGALURU OFFICE</li>
									<li>No. 2797, 3rd Floor,</li>
									<li>27th Main Road,</li>
									<li>Sector 1 HSR Layout</li>
									<li>Bengaluru, Karnataka,</li>
									<li>India - 560102</li>
								</ul>
							</div>
							<div class="col-sm-12 webPhoneIcon">
								<div class="col-sm-12 col-xs-12 padding0">
									<div class="col-sm-1 col-xs-1  padding0">
										<i class="material-icons">language</i>
									</div>
									<div class="col-sm-10 col-xs-10 padding0 space"><span>www.innovationroots.com</span>
									</div>
								</div>
								<div class="col-sm-12 col-xs-12 padding0">
									<div class="col-sm-1 col-xs-1 phone">
										<i class="material-icons phoneIcon">phone</i>
									</div>
									<div class="col-sm-10 col-xs-10 padding0 space">
										<span>+(91)-8041489100</span>
									</div>
								</div>
								<div class="col-sm-12 col-xs-12 padding0">
									<div class="col-sm-1 col-xs-1 padding0">
										<i class="material-icons">mail_outline</i>
									</div>
									<div class="col-sm-10 col-xs-10 padding0 space">
										<span>community@innovationroots.com</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!---------------START MAP SECTION-------------------->

		<?php include('includes/footer.php');?>


		<script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>


		<script type="text/javascript" src="inc/assets/js/jquery-1.11.1.min.js"></script>
		<script type="text/javascript" src="inc/assets/js/bootstrap.min.js"></script>
		<script type="text/javascript">
			$(".modal_trigger").leanModal({
				top: 200,
				overlay: 0.6,
				closeButton: ".modal_close"
			});
			$(function() {
				$("#login_form").click(function() {
					$(".social_login").hide();
					$(".user_login").show();
					return false
				});
				$("#register_form, .register_form").click(function() {
					var c = $(this).attr("data-url");
					var f = $(this).attr("data-event");
					var b = $(this).attr("data-location");
					var g = $(this).attr("data-dt");
					$("#data-url-redirect").val(c);
					$("#data-events").val(f);
					$("#data-location").val(b);
					$("#data-dt").val(g);
					$(".social_login").hide();
					$(".user_register").show();
					$(".header_title").text("Register");
					return false
				});
				$(".back_btn").click(function() {
					$(".user_login").hide();
					$(".user_register").hide();
					$(".social_login").show();
					$(".header_title").text("Login");
					return false
				})
			});

			function ValidateEmail(a) {
				var b = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
				return b.test(a)
			}

		</script>



		<!--<script>var captcha;function generateCaptcha(){var f=Math.floor((Math.random()*10));var e=Math.floor((Math.random()*10));var h=Math.floor((Math.random()*10));var g=Math.floor((Math.random()*10));captcha=f.toString()+e.toString()+h.toString()+g.toString();document.getElementById("captcha").value=captcha}function check(){if($("#name").val()==""){$("#invalidname").text("Name is required").css("color","red");return false}else{$("#invalidname").text("")}if(!ValidateEmail($("#email").val())){$("#invalidemail").text("Invalid Email").css("color","red");return false}else{$("#invalidemail").text("")}if($("#phone").val()==""){$("#invalidphone").text("Phone is required").css("color","red");return false}else{$("#invalidphone").text("")}var c=$("#registerForm").serialize();var f=false;$.ajax({type:"POST",url:"gcaptcha.php",async:false,data:c,success:function(a){if(a.localeCompare("failure")==0){$("#captchamsg").css("color","red");$("#captchamsg").show();f=false}else{$("#captchamsg").hide();f=true}}});if(f){var b=$(this).attr("data-url");var d=$("#data-url-redirect").val();var e=window.open(d,"_blank")}return f}</script>-->
		<script>
			jssor_1_slider_init = function() {
				var c = {
					$AutoPlay: true,
					$AutoPlaySteps: 4,
					$SlideDuration: 160,
					$SlideWidth: 200,
					$SlideSpacing: 3,
					$Cols: 4,
					$ArrowNavigatorOptions: {
						$Class: $JssorArrowNavigator$,
						$Steps: 4
					},
					$BulletNavigatorOptions: {
						$Class: $JssorBulletNavigator$,
						$SpacingX: 1,
						$SpacingY: 1
					}
				};
				var b = new $JssorSlider$("jssor_1", c);

				function a() {
					var d = b.$Elmt.parentNode.clientWidth;
					if (d) {
						d = Math.min(d, 809);
						b.$ScaleWidth(d)
					} else {
						window.setTimeout(a, 30)
					}
				}
				a();
				$Jssor$.$AddEvent(window, "load", a);
				$Jssor$.$AddEvent(window, "resize", a);
				$Jssor$.$AddEvent(window, "orientationchange", a)
			};

		</script>

		<script>
			$(document).ready(function() {
				if (!$.browser.webkit) {
					$('.wrapper').html('<p>Sorry! Non webkit users. :(</p>');
				}
			});

		</script>


		<!----Testimonial carousel----------->

		<script>
			var items = [];
			var startItem = 1;
			var position = 0;
			var itemCount = $('.carousel .items').length;
			var leftpos = itemCount;
			var resetCount = itemCount;



			function swap(action) {
				var direction = action;

				//moving carousel backwards
				if (direction == 'counter-clockwise') {

					var leftitem = $('.left-pos').attr('id') - 1;
					if (leftitem == 0) {
						leftitem = itemCount;
					}

					$('.right-pos').removeClass('right-pos').addClass('back-pos');
					$('.main-pos').removeClass('main-pos').addClass('right-pos');
					$('.left-pos').removeClass('left-pos').addClass('main-pos');
					$('#' + leftitem + '').removeClass('back-pos').addClass('left-pos');

					startItem--;
					if (startItem < 1) {
						startItem = itemCount;
					}
				}

				//moving carousel forward
				if (direction == 'clockwise' || direction == '' || direction == null) {

					function pos(positionvalue) {
						if (positionvalue != 'leftposition') {

							position++;


							if ((startItem + position) > resetCount) {
								position = 1 - startItem;
							}
						}


						if (positionvalue == 'leftposition') {

							position = startItem - 1;


							if (position < 1) {
								position = itemCount;
							}
						}

						return position;
					}

					$('#' + startItem + '').removeClass('main-pos').addClass('left-pos');
					$('#' + (startItem + pos()) + '').removeClass('right-pos').addClass('main-pos');
					$('#' + pos('leftposition') + '').removeClass('left-pos').addClass('right-pos');

					startItem++;
					position = 0;
					if (startItem > itemCount) {
						startItem = 1;
					}
				}
			}

			//if any visible items are clicked
			$('.items').click(function() {
				if ($(this).attr('class') == 'items left-pos') {
					swap('counter-clockwise');
				} else {
					swap('clockwise');
				}
			});



			//on carousel slide data also slides
			$('.carousel').on('slid.bs.carousel', function() {

				if ($("#1").hasClass("main-pos")) {

					$('.firstTestimonial').show();
					$('.secondTestimonial').hide();
					$('.thirdTestimonial').hide();
				}
				if ($("#2").hasClass("main-pos")) {

					$('.firstTestimonial').hide();
					$('.secondTestimonial').show();
					$('.thirdTestimonial').hide();
				}

				if ($("#3").hasClass("main-pos")) {

					$('.firstTestimonial').hide();
					$('.secondTestimonial').hide();
					$('.thirdTestimonial').show();
				}
			});

			//direction is clockwise if left caret clicked
			$('.caretLeft').click(function() {
				swap('clockwise');
				if ($("#1").hasClass("main-pos")) {
					$('.firstTestimonial').show();
					$('.secondTestimonial').hide();
					$('.thirdTestimonial').hide();
				}
				if ($("#2").hasClass("main-pos")) {
					$('.firstTestimonial').hide();
					$('.secondTestimonial').show();
					$('.thirdTestimonial').hide();
				}

				if ($("#3").hasClass("main-pos")) {
					$('.firstTestimonial').hide();
					$('.secondTestimonial').hide();
					$('.thirdTestimonial').show();
				}

			});


			//direction is counter-clockwise if right caret clicked
			$('.caretRight').click(function() {
				swap('counter-clockwise');

				if ($("#1").hasClass("main-pos")) {
					$('.firstTestimonial').show();
					$('.secondTestimonial').hide();
					$('.thirdTestimonial').hide();
				}
				if ($("#2").hasClass("main-pos")) {
					$('.firstTestimonial').hide();
					$('.secondTestimonial').show();
					$('.thirdTestimonial').hide();
				}

				if ($("#3").hasClass("main-pos")) {
					$('.firstTestimonial').hide();
					$('.secondTestimonial').hide();
					$('.thirdTestimonial').show();
				}

			});
            
            

		</script>


	</body>

</html>
