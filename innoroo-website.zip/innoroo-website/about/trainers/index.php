<!--Updated On 28-03-2018GA
	Meta tag updated
-->

<!DOCTYPE html>
<html lang="en">

<head>
	<title>INNOVATION ROOTS | About | Trainers | The most experienced Trainer profiles on Kanban | Agile | Advanced Scrum Master | SAFe</title>

	<!-- Title Tag Meta End -->

	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    
	<!-- OPEN GRAPH META TAG STARTS -->	
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->

	<!-- Description Tag Meta Start -->
	<!-- Updated on 27.12.17 PP -->
	<meta name="description" content="Our trainings on SAFe, Kanban, and Scrum methodologies are carried out by highly experienced individuals.">

	<!-- Description Tag Meta End -->


	<meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
	<meta name="ROBOTS" content="INDEX, FOLLOW">
	<link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
	<link href="../../inc/assets/css/bootstrap.min.css" rel="stylesheet" />
	<link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="../../inc/assets/css/main.css" rel="stylesheet" />
	<link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
	<script src="../inc/assets/js/modernizr.custom.83079.js"></script>
	<script>
		(function(d, e, j, h, f, c, b) {
			d.GoogleAnalyticsObject = f;
			d[f] = d[f] || function() {
				(d[f].q = d[f].q || []).push(arguments)
			}, d[f].l = 1 * new Date();
			c = e.createElement(j), b = e.getElementsByTagName(j)[0];
			c.async = 1;
			c.src = h;
			b.parentNode.insertBefore(c, b)
		})(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
		ga("create", "UA-100332682-2", "auto");
		ga("send", "pageview");

	</script>

	<!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
	<script type="text/javascript">
		document.oncontextmenu = new Function("return false");
		document.onselectstart = new Function("return false");
		if (window.sidebar) {
			document.onmousedown = new Function("return false");
			document.onclick = new Function("return true");

			document.oncut = new Function("return false");

			document.oncopy = new Function("return false");


			document.onpaste = new Function("return false");
		}

	</script>
</head>

<body>
	<?php include('../../includes/header.php');?>
	<section class="page-cover-half gmap">
		<div class="container">
			<div class="page_center_caption">
				<h1 class="main_title">Trainers &amp; Partners</h1>
				<div class="text_center_hr"></div>
				<h2 class="heading_sub_page">Meet our Experts
				</h2>
			</div>
		</div>
	</section>
	<section class="team_section" style="margin:0!important" id="speakers">
		<div class="container">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="row">
					<div class="col-md-4 col-sm-6 col-sm-12">
						<div class="trainer_div">
							<img class="img-responsive img_trainer" src="../../inc/assets/img/trainer/trainer-bhaskar.png" alt="Bhaskar Rao" class="image_trainers">
							<div class="trainer_des">
								<h4 class="trainer_name">Bhaskar Rao</h4>
								<h5 class="trainer_designation">
									SAFe Program Consultant (SPC4)
								</h5>
								<h5 class="trainer_designation">
									Lead Consultant
								</h5>
								<h5 class="trainer_designation">
									INNOVATION ROOTS
								</h5>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 col-sm-12">
						<div class="trainer_div">
							<img class="img-responsive img_trainer" src="../../inc/assets/img/trainer/trainer-ansley.png" alt="Brett Ansley" class="image_trainers">
                                <div class="trainer_des">
                                    <h4 class="trainer_name">Brett Ansley</h4>
                                    <h5 class="trainer_designation">
                                        Agile Kanban Coach 
                                    </h5>
                                    <h5 class="trainer_designation">
                                        Executive Coach & Mentor
                                    </h5>
                                    <h5 class="trainer_designation">
                                        Brett Ansley Consulting
                                    </h5>
                                </div>
						</div>
					</div>

					<div class="col-md-4 col-sm-6 col-sm-12">
						<div class="trainer_div">
							<img class="img-responsive img_trainer" src="../../inc/assets/img/trainer/trainer-kesiew.jpg" alt="K E Siew" class="image_trainers">
							<div class="trainer_des">
								<h4 class="trainer_name">K E Siew</h4>
								<h5 class="trainer_designation">
									Certified Scrum Trainer
								</h5>
								<h5 class="trainer_designation">
									Agile Coach
								</h5>
								<h5 class="trainer_designation">
									Qumility Consulting
								</h5>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 col-sm-12">
						<div class="trainer_div">
							<img class="img-responsive img_trainer" src="../../inc/assets/img/trainer/trainer-mikeb.jpg" alt="Mike Burrows" class="image_trainers">
							<div class="trainer_des">
								<h4 class="trainer_name">Mike Burrows</h4>
								<h5 class="trainer_designation">
									Author, "Kanban from the Inside"
								</h5>
								<h5 class="trainer_designation">
									Founder
								</h5>
								<h5 class="trainer_designation">
									Agendashift
								</h5>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 col-sm-12">
						<div class="trainer_div">
							<img class="img-responsive img_trainer" src="../../inc/assets/img/trainer/trainer-mikel.jpg" alt="Mike Leber" class="image_trainers">
							<div class="trainer_des">
								<h4 class="trainer_name">Mike Leber</h4>
								<h5 class="trainer_designation">
									Accredited Kanban Trainer
								</h5>
								<h5 class="trainer_designation">
									Executive Consultant, Trainer
								</h5>
								<h5 class="trainer_designation">
									Agile Experts e.U
								</h5>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 col-sm-12">
						<div class="trainer_div">
							<img class="img-responsive img_trainer" src="../../inc/assets/img/trainer/trainer-prashant.png" alt="Prashant M J" class="image_trainers">
							<div class="trainer_des">
								<h4 class="trainer_name">Prashant M J</h4>
								<h5 class="trainer_designation">
									SAFe Program Consultant (SPC4)
								</h5>
								<h5 class="trainer_designation">
									Consultant
								</h5>
								<h5 class="trainer_designation">
									INNOVATION ROOTS
								</h5>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 col-sm-12">
						<div class="trainer_div">
							<img class="img-responsive img_trainer" src="../../inc/assets/img/trainer/trainer-priyank.png" alt="Priyank Pathak" class="image_trainers">
<div class="trainer_des">
<h4 class="trainer_name">Priyank Pathak</h4>
<h5 class="trainer_designation">
Agile & Continuous Delivery Consultant
</h5>
<h5 class="trainer_designation">
Curator
</h5>
<h5 class="trainer_designation">
INNOVATION ROOTS
</h5>
</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php include('../../includes/footer.php');?>
    
     <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>
    <!--end pure chat-->
    
	<script type="text/javascript" src="../../inc/assets/js/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="../../inc/assets/js/bootstrap.min.js"></script>
</body>

</html>
