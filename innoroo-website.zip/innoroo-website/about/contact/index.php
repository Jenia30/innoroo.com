<!--Updated On 28-03-2018GA
	Meta tag updated
-->


<!DOCTYPE html>
<html lang="en">

<head>
    <title>INNOVATION ROOTS | About | Contact | Contact us for soon to be available trainings on:Leading SAFe | Kanban | Scrum Master | Agile</title>

    <!-- Title Tag Meta End -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->

    <!-- Description Tag Meta Start -->
    <!-- Updated on 27.12.17 PP -->
    <meta name="description" content="Call us or visit our site for trainings on SAFe, Kanban, and Scrum!">
    <!-- Description Tag Meta End -->

    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
    <META NAME="ROBOTS" CONTENT="INDEX, FOLLOW"></META>
    <link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
    <link href="../../inc/assets/css/bootstrap.min.css" rel="stylesheet" />
    <link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../../inc/assets/css/main.css" rel="stylesheet" />
    <link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
    <script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>

    
	<script type="text/javascript">
		document.oncontextmenu = new Function("return false");
		document.onselectstart = new Function("return false");
		if (window.sidebar) {
			document.onmousedown = new Function("return false");
			document.onclick = new Function("return true");
			document.oncut = new Function("return false");
			document.oncopy = new Function("return false");
			document.onpaste = new Function("return false");
		}
	</script>

    <!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
</head>

<body>
    <?php include('../../includes/header.php');?>
    <section class="page-cover-half gmap">
        <div class="container">
            <div class="page_center_caption">
                <h1 class="main_title">Contact Us</h1>
                <div class="career_center_hr"></div>
                <h2 class="heading_sub_page">
                    Let&acute;s Get Together
                </h2>
            </div>
        </div>
    </section>
    <section class="contact-info-section">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="icon-text-block">
                        
                            
                            <div class="block-text">
                                <h6><strong>Registered Office</strong></h6>
                                <p class="footer_font_add">No 43, Van Marg,<br /> Banapura, Madhya Pradesh,<br> India - 461221</p>
                            </div>
                       
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="icon-text-block">
                        
                            <div class="block-text">
                                <h6><strong>Bengaluru Office</strong></h6>
                                <p class="footer_font_add">
                                    No. 2797, 3rd Floor, <br /> 27th Main Road, <br /> Sector 1 HSR Layout, <br />Bengaluru, Karnataka,<br> India - 560102
                                </p>
                            
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="icon-text-block">
                        
                            <div class="block-text">
                                <h6><strong>Phone</strong></h6>
                                <p class="footer_font_add">
                                    +(91) - 8041489100
                                    <br /> +(91) - 99999 85600
                                </p>
                            
                        </div>
                    </div>
                    <div class="icon-text-block">
                       
                            <div class="block-text">
                                <h6><strong>E-Mail</strong></h6>
                                <p class="footer_font_add">community@innovationroots.com</p>
                            </div>
                       
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="icon-text-block">
                        
                            <div class="block-text">
                                <h6><strong>Business Hours</strong></h6>
                                <p class="footer_font_add">
                                    9:00 - 18:00 IST
                                    <br /> Monday - Friday
                                </p>
                            </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h3>Send us a message</h3>
                    <p>
                        ...for anything which has <span class=playfair>Agile</span> in it
                    </p>
                </div>
                <div class="col-md-8">
                    <div id="formSuccess" class="alert alert-success" role="alert" style="display:none">
                        <p>
                            <strong>Thank You!</strong>&nbsp;Your message has been sent successfully.<br/>
                            <small>Someone from our team will respond to your query within 24 hrs.</small>
                        </p>
                    </div>
                    <div class="contact-form-wrapper">
                        <div id="mc_embed_signup">
                            <form action="https://innovationroots.us8.list-manage.com/subscribe/post?u=5d4e450716fe9c41f5afef8c0&amp;id=13766995e2" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
                                <div id="mc_embed_signup_scroll">

                                    <div class="form-group mc-field-group">
                                        <label for="mce-FNAME">First Name </label>
                                        <input type="text" value="" name="FNAME" class="required" id="mce-FNAME" placeholder="First Name*">
                                    </div>
                                    <div class="form-group mc-field-group">
                                        <label for="mce-EMAIL">Email Address 
</label>
                                        <input type="email" value="" name="EMAIL" class="required email" id="mce-EMAIL" placeholder="Email Address*">
                                    </div>
                                    <div class="form-group mc-field-group">
                                        <label for="mce-LNAME">Last Name </label>
                                        <input type="text" value="" name="LNAME" class="" id="mce-LNAME" placeholder="Last Name">
                                    </div>
                                    <div class="form-group mc-field-group">
                                        <label for="mce-SUBJECT">Subject  
</label>
                                        <input type="text" value="" name="SUBJECT" class="required" id="mce-SUBJECT" placeholder="Subject*">
                                    </div>
                                    <div class="form-group mc-field-group">
                                        <label for="mce-MESSAGE">Message 
</label>
                                        <textarea class="form-control required" name="MESSAGE" rows="5" id="mce-MESSAGE" placeholder="Message"></textarea>

                                    </div>
                                    <div class=checkbox>
                                        <label>
<input type=checkbox id=inputCheckbox name=newsletter> Sign Me up for Newsletter!
</label>
                                        <p class="help-block text-small">No Spam mails, We promise!</p>
                                    </div>
                                    <div id="form-group mce-responses" class="clear">
                                        <div class="response" id="mce-error-response" style="display:none"></div>
                                        <div class="response" id="mce-success-response" style="display:none"></div>
                                    </div>
                                    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                                    <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_5d4e450716fe9c41f5afef8c0_13766995e2" tabindex="-1" value=""></div>
                                    <div class="clear"><input type="submit" value="SUBMIT" name="subscribe" id="mc-embedded-subscribe" class="button btn"></div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php include('../../includes/footer.php');?>
    
     <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>
    <!--end pure chat-->
    
    <script type="text/javascript" src="../../inc/assets/js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="../../inc/assets/js/bootstrap.min.js"></script>

    <script type='text/javascript' src='//s3.amazonaws.com/downloads.mailchimp.com/js/mc-validate.js'></script>
    <script type='text/javascript'>
        (function($) {
            window.fnames = new Array();
            window.ftypes = new Array();
            fnames[1] = 'FNAME';
            ftypes[1] = 'text';
            fnames[0] = 'EMAIL';
            ftypes[0] = 'email';
            fnames[2] = 'LNAME';
            ftypes[2] = 'text';
            fnames[3] = 'SUBJECT';
            ftypes[3] = 'text';
            fnames[4] = 'MESSAGE';
            ftypes[4] = 'text';
        }(jQuery));
        var $mcj = jQuery.noConflict(true);

    </script>
</body>

</html>
