<!--Updated On 28-03-2018GA
	Meta tag updated
-->

<!DOCTYPE html>
<html lang="en">

<head>
	<title>INNOVATION ROOTS | About | Team | Highly experienced team </title>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    
	<!-- OPEN GRAPH META TAG STARTS -->	
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->
	
	<meta name="description" content="check out our latest team page and stay connected.">
	<meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
	<meta name="ROBOTS" content="INDEX, FOLLOW">
	<link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
	<link href="../../inc/assets/css/bootstrap.min.css" rel="stylesheet" />
	<link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="../../inc/assets/css/main.css" rel="stylesheet" />
	<link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
	<script src="../inc/assets/js/modernizr.custom.83079.js"></script>
	<script>
		(function(d, e, j, h, f, c, b) {
			d.GoogleAnalyticsObject = f;
			d[f] = d[f] || function() {
				(d[f].q = d[f].q || []).push(arguments)
			}, d[f].l = 1 * new Date();
			c = e.createElement(j), b = e.getElementsByTagName(j)[0];
			c.async = 1;
			c.src = h;
			b.parentNode.insertBefore(c, b)
		})(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
		ga("create", "UA-100332682-2", "auto");
		ga("send", "pageview");

	</script>

	<!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
	<script type="text/javascript">
		document.oncontextmenu = new Function("return false");
		document.onselectstart = new Function("return false");
		if (window.sidebar) {
			document.onmousedown = new Function("return false");
			document.onclick = new Function("return true");
			document.oncut = new Function("return false");
			document.oncopy = new Function("return false");
			document.onpaste = new Function("return false");
		}

	</script>
</head>

<body>
	<?php include('../../includes/header.php');?>
	<section class="page-cover_bg margin_training_list_media" style="margin:0!important">
		<div class="team-bg page_bg bg_overlay"></div>
		<div class="container">
			<div class="page_center_caption">
				<h1 class="main_title">Our Team</h1>
				<div class="text_center_hr"></div>
				<h2 class="heading_sub_page">We are Makers, Thinkers, Explorers and Creators</h2>
			</div>
		</div>
	</section>
	<section class="team_section" style="margin:0!important" id="speakers">
		<div class="container">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="row">
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="demo-card-square" style="margin-top:10px">
							<div class="mdl-card__title mdl-card--expand" style="background-color:#fff;padding:5%;position:relative">
								<div class="acme-card mdl-card mdl-shadow--2dp">
									<a><img class="img-responsive img_overlay" src="../../inc/assets/img/team/priyank.jpg" alt="priyank Pathak"></a>
								</div>
							</div>
							<div class="mdl-card__supporting-text" style="padding:10px 15px;min-height:106px">
								<a style="color:#000;text-decoration:none;line-height:20px"> <strong>Priyank Pathak </strong><br />Managing Consultant</a><br>
								<a href="https://www.linkedin.com/in/priyankdk"><i class="fa fa-linkedin fa_gen fa_linkedin_hover" aria-hidden="true"></i></a>
								<a href="https://twitter.com/priyankdk"> <i class="fa fa-twitter fa_gen fa_twitter_hover" aria-hidden="true"></i></a>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="demo-card-square" style="margin-top:10px">
							<div class="mdl-card__title mdl-card--expand" style="background-color:#fff;padding:5%;position:relative">
								<div class="acme-card mdl-card mdl-shadow--2dp">
									<a><img class="img-responsive img_overlay" src="../../inc/assets/img/team/bhaskar.jpg" alt="Bhaskar"></a>
								</div>
							</div>
							<div class="mdl-card__supporting-text" style="padding:10px 15px;min-height:106px">
								<a style="color:#000;text-decoration:none;line-height:20px"> <strong>Bhaskar Rao</strong><br />Lead Consultant</a><br>
								<a href="https://www.linkedin.com/in/bhaskar-rao-balabhadrapatruni-46508242"><i class="fa fa-linkedin fa_gen fa_linkedin_hover" aria-hidden="true"></i></a>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="demo-card-square" style="margin-top:10px">
							<div class="mdl-card__title mdl-card--expand" style="background-color:#fff;padding:5%;position:relative">
								<div class="acme-card mdl-card mdl-shadow--2dp">
									<a><img class="img-responsive img_overlay" src="../../inc/assets/img/team/prachi.jpg" alt="Prachi"></a>
								</div>
							</div>
							<div class="mdl-card__supporting-text" style="padding:10px 15px;min-height:106px">
								<a style="color:#000;text-decoration:none;line-height:20px"> <strong>Prachi Arora</strong><br />Lead Consultant</a><br>
								<a href="https://www.linkedin.com/in/prachia"><i class="fa fa-linkedin fa_gen fa_linkedin_hover" aria-hidden="true"></i></a>
								<a href="https://twitter.com/aroraprachi12"><i class="fa fa-twitter fa_gen fa_twitter_hover" aria-hidden="true"></i></a>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="demo-card-square" style="margin-top:10px">
							<div class="mdl-card__title mdl-card--expand" style="background-color:#fff;padding:5%;position:relative">
								<div class="acme-card mdl-card mdl-shadow--2dp">
									<a><img class="img-responsive img_overlay" src="../../inc/assets/img/team/noopur.jpg" alt="Noopur"></a>
								</div>
							</div>
							<div class="mdl-card__supporting-text" style="padding:10px 15px;min-height:106px">
								<a style="color:#000;text-decoration:none;line-height:20px"><strong>Noopur Pathak </strong><br />Consultant</a><br>
								<a href="https://www.linkedin.com/in/noopur-pathak-mba-prince2-csm-68811b20"> <i class="fa fa-linkedin fa_gen fa_linkedin_hover" aria-hidden="true"></i></a>
								<a href="https://twitter.com/NoopurPathak"> <i class="fa fa-twitter fa_gen fa_twitter_hover" aria-hidden="true"></i></a>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="demo-card-square" style="margin-top:10px">
							<div class="mdl-card__title mdl-card--expand" style="background-color:#fff;padding:5%;position:relative">
								<div class="acme-card mdl-card mdl-shadow--2dp">
									<a><img class="img-responsive img_overlay" src="../../inc/assets/img/team/prashant.jpg" alt="Prashant"></a>
								</div>
							</div>
							<div class="mdl-card__supporting-text" style="padding:10px 15px;min-height:106px">
								<a style="color:#000;text-decoration:none;line-height:20px"> <strong>Prashant MJ</strong><br />Consultant</a><br>
								<a href="https://www.linkedin.com/in/mjprashant"><i class="fa fa-linkedin fa_gen fa_linkedin_hover" aria-hidden=true></i></a>
								<a href="https://twitter.com/mjprashant"> <i class="fa fa-twitter fa_gen fa_twitter_hover" aria-hidden="true"></i></a>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="demo-card-square" style="margin-top:10px">
							<div class="mdl-card__title mdl-card--expand" style="background-color:#fff;padding:5%;position:relative">
								<div class="acme-card mdl-card mdl-shadow--2dp">
									<a><img class="img-responsive img_overlay" src="../../inc/assets/img/team/thriveni.jpg" alt="Thriveni"></a>
								</div>
							</div>
							<div class="mdl-card__supporting-text" style="padding:10px 15px;min-height:106px">
								<a style="color:#000;text-decoration:none;line-height:20px"> <strong>Thriveni Shetty</strong><br />Consultant</a><br>
								<a href="https://www.linkedin.com/in/thriveni-shetty-1b474220/ "> <i class="fa fa-linkedin fa_gen fa_linkedin_hover" aria-hidden="true"></i></a>
								<a href="https://twitter.com/tri03shetty"> <i class="fa fa-twitter fa_gen fa_twitter_hover" aria-hidden="true"></i></a>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="demo-card-square" style="margin-top:10px">
							<div class="mdl-card__title mdl-card--expand" style="background-color:#fff;padding:5%;position:relative">
								<div class="acme-card mdl-card mdl-shadow--2dp">
									<a><img class="img-responsive img_overlay" src="../../inc/assets/img/team/chirag.jpg" alt="chirag"></a>
								</div>
							</div>
							<div class="mdl-card__supporting-text" style="padding:10px 15px;min-height:106px">
								<a style="color:#000;text-decoration:none;line-height:20px"> <strong>Chirag G</strong><br />Associate - Marketing & Sales</a><br>
								<a href="https://www.linkedin.com/in/chirag-ghaghada-908a4a80"><i class="fa fa-linkedin fa_gen fa_linkedin_hover" aria-hidden="true"></i></a>
								<a href="https://twitter.com/ChiragSoni486"><i class="fa fa-twitter fa_gen fa_twitter_hover" aria-hidden="true"></i></a>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="demo-card-square" style="margin-top:10px">
							<div class="mdl-card__title mdl-card--expand" style="background-color:#fff;padding:5%;position:relative">
								<div class="acme-card mdl-card mdl-shadow--2dp">
									<a><img class="img-responsive img_overlay" src="../../inc/assets/img/team/bharath.jpg" alt="Bharat"></a>
								</div>
							</div>
							<div class="mdl-card__supporting-text" style="padding:10px 15px;min-height:106px">
								<a style="color:#000;text-decoration:none;line-height:20px"> <strong>Bharath Naik</strong><br />Associate - Finance & Accounts</a><br>
								<a href="https://www.linkedin.com/in/bharath-naik-ba31b5135"> <i class="fa fa-linkedin fa_gen fa_linkedin_hover" aria-hidden="true"></i></a>
								<a href="https://twitter.com/bnaik1679"> <i class="fa fa-twitter fa_gen fa_twitter_hover" aria-hidden="true"></i></a>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="demo-card-square" style="margin-top:10px">
							<div class="mdl-card__title mdl-card--expand" style="background-color:#fff;padding:5%;position:relative">
								<div class="acme-card mdl-card mdl-shadow--2dp">
									<a><img class="img-responsive img_overlay" src="../../inc/assets/img/team/santhosh.jpg" alt="santhosh"></a>
								</div>
							</div>
							<div class="mdl-card__supporting-text" style="padding:10px 15px;min-height:106px">
								<a style="color:#000;text-decoration:none;line-height:20px"> <strong>Santhosh Kumar</strong><br />Associate - Graphic Designer</a><br>
								<a href="https://www.linkedin.com/in/santhosh-kumar-08b706104"> <i class="fa fa-linkedin fa_gen fa_linkedin_hover" aria-hidden="true"></i></a>
								<a href="https://twitter.com/santhos77186587"> <i class="fa fa-twitter fa_gen fa_twitter_hover" aria-hidden="true"></i></a>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="demo-card-square" style="margin-top:10px">
							<div class="mdl-card__title mdl-card--expand" style="background-color:#fff;padding:5%;position:relative">
								<div class="acme-card mdl-card mdl-shadow--2dp">
									<a><img class="img-responsive img_overlay" src="../../inc/assets/img/team/Jenia.jpg" alt="Chaitra"></a>
								</div>
							</div>
							<div class="mdl-card__supporting-text" style="padding:10px 15px;min-height:106px">
								<a style="color:#000;text-decoration:none;line-height:20px"> <strong>Jenia Bhasin</strong><br />Trainee - Web Developer</a><br>
								<a href="https://www.linkedin.com/in/jenia-bhasin-06422b118"> <i class="fa fa-linkedin fa_gen fa_linkedin_hover" aria-hidden="true"></i></a>
								<a href="https://twitter.com/Jenia94"> <i class="fa fa-twitter fa_gen fa_twitter_hover" aria-hidden="true"></i></a>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="demo-card-square" style="margin-top:10px">
							<div class="mdl-card__title mdl-card--expand" style="background-color:#fff;padding:5%;position:relative">
								<div class="acme-card mdl-card mdl-shadow--2dp">
									<a><img class="img-responsive img_overlay" src="../../inc/assets/img/team/Sathish.k.jpg" alt="sathish"></a>
								</div>
							</div>
							<div class="mdl-card__supporting-text" style="padding:10px 15px;min-height:106px">
								<a style="color:#000;text-decoration:none; line-height:20px;"> <strong>K Sathish</strong><br />Associate - Digital Marketing</a><br>
								<a href="https://www.linkedin.com/in/sathish-innovationroots/"><i class="fa fa-linkedin fa_gen fa_linkedin_hover" aria-hidden="true"></i></a>
								<a href="https://twitter.com/sathish252045"> <i class="fa fa-twitter fa_gen fa_twitter_hover" aria-hidden="true"></i></a>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="demo-card-square" style=" margin-top:10px;">
							<div class="mdl-card__title mdl-card--expand " style="background-color:#fff; padding:5%; position:relative;">
								<div class="acme-card mdl-card mdl-shadow--2dp">
									<a><img class="img-responsive img_overlay" src="../../inc/assets/img/team/Alekya.jpg" alt="sathish"></a>
								</div>
							</div>
							<div class="mdl-card__supporting-text" style="padding: 10px 15px;min-height: 100px;">
								<a style="color:#000;text-decoration:none; line-height:20px;"> <strong>Alekya NR</strong><br />Trainee - Content Marketing</a><br>
								<a href="https://www.linkedin.com/in/alekya-n-r-610b58155/"> <i class="fa fa-linkedin fa_gen fa_linkedin_hover" aria-hidden="true"></i></a>
								<a href="https://twitter.com/NrAlekya"> <i class="fa fa-twitter fa_gen fa_twitter_hover" aria-hidden="true"></i></a>
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</section>
	<?php include('../../includes/footer.php');?>
    
     <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>
    <!--end pure chat-->
    
	<script type="text/javascript" src="../../inc/assets/js/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="../../inc/assets/js/bootstrap.min.js"></script>
</body>

</html>
