<!--Updated On 28-03-2018GA
	Meta tag updated
-->


<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="google-site-verification" content="2RxPEMEJ3Vw7pu7BJ9I-zgwbmiEK6uJM3Ulq8ImrBZE" />
    <title>INNOVATION ROOTS | About | Our Story</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="INNOVATION ROOTS was incorporated on 01 Aug 2013 as a private limited company with multiple offices at Banapura, MP, and Bengaluru, KA India. Aside from mjor Indian cities, it has a major Operational centers in abroad countries like Singapore, US, UK and large parts of Asia.">
    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
    <meta name="ROBOTS" content="INDEX, FOLLOW">
    
     <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->
    
    <link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../inc/assets/css/newsletter_form.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <!-- Icon Fonts -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../../inc/assets/css/main.css" rel="stylesheet" />
    <script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
    <script type="text/javascript" src="../../inc/assets/js/jquery-1.11.1.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">

    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>

    
	<script type="text/javascript">
            document.oncontextmenu = new Function("return false");
            document.onselectstart = new Function("return false");
            if (window.sidebar) {
                document.onmousedown = new Function("return false");
                document.onclick = new Function("return true");
                document.oncut = new Function("return false");
                document.oncopy = new Function("return false");
                document.onpaste = new Function("return false");
            }
        </script>

</head>

<body>
    <?php include('../../includes/header.php');?>

    <!--starts feature image section -->
    <section class="home-cover padding-top-section aboutRelative">
<!--        <div class="col-sm-12 col-xs-12 padding0 aboutUsFeatureImage">-->
<!--            <img src="../../inc/assets/img/about-us/about-us-feature-image.png" width="100%" alt="About Us">-->
            <div class="col-sm-12 col-xs-12 first-section">
                <div class="container">
                    <div class="col-md-10 col-sm-12 col-xs-12 padd0">
                        <i class="fa fa-quote-left" aria-hidden="true"></i>
                        <h2>"To have a great idea, have a lot of them". </h2>
                        <h3>- Thomas Edison</h3>
                    </div>
                </div>
            </div>
<!--        </div>-->
    </section>
    <!--End feature image section-->

    <!--starts our story seciton-->
    <section class="padding-section grey-section">
        <div class="container">
            <div class="col-sm-12 col-xs-12 padding0">
                <div class="col-sm-6 col-xs-12 storysofar">
                    <div class="col-sm-12 col-xs-12 storyInside">
                        <div class="col-sm-12 col-xs-12 innorooValues padd0">
                            <p class="margin0">Transforming Ideas <i class="fa fa-chevron-right" aria-hidden="true"></i> Values.</p>
                        </div>
                        <div class="col-sm-12 col-xs-12 padding0">
                            <p>Our journey started under the leadership of Priyank, who envisioned a platform for the creation of innovative solutions for enabling modern enterprises experience both Business Growth and Value Creation, as well as Individuals to experience improvement and empowerment towards delivering better services.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12 ourStory">
                    <p><strong>INNOVATION ROOTS</strong> was incorporated in 2013 - 2014 as a private limited company and has since spread its presence, with multiple offices at Banapura, MP, and Bengaluru, KA India. Aside from major Indian cities, it has a major Operational presence abroad, in countries like Singapore, US, UK and large parts of Asia.</p>
                </div>
            </div>
        </div>
    </section>
    <!--ends our story section-->
    
    <!--starts priyank section-->
    <section class="padding-section section5">
        <div class="col-sm-12 col-xs-12">
            <div class="container">
                <div class="col-sm-5 col-xs-12 section5-img">
                    <img src="../../inc/assets/img/about-us/priyank-pathak.png" width="100%" alt="Priyank Pathak">
                </div>
                <div class="col-sm-6 col-xs-12 section5-info padd0">
                    <div class="col-sm-12 col-xs-12 padd0">
                        <h2>“Creativity is our Hunger, Excellence is our Passion and Time is our Currency.” </h2>
                        <h5>- Priyank DK Pathak</h5>
                        <p>(Curator & Managing Consultant, <strong>INNOVATION ROOTS)</strong></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
   
    <!--ends priyank section-->

    <!--starts journeyman section-->
    <!--
	<section class="padding-section grey-section">
		<div class="container">
			<div class="col-sm-12 col-xs-12 padding0 coreValues">
				
				<div class="col-sm-6 col-xs-6 coreValuesPara">
					<p class="para-content">We uniquely associated using our Partner, Access, Educate and Execute (PAEE) approach with each customers as Journeyman to understand the specific requirements, and create & deliver valuable solutions. Core values APEIC.</p>
				</div>
				<div class="col-sm-5 col-xs-6 coreImage">
					<img src="../../inc/assets/img/about-us/apeic.png" width="100%">
				</div>
			</div>
		</div>
	</section>
-->
    <!--ends journeyman section-->

    <!--starts intellect section-->
    <!--
	<section class="padding-section">
		<div class="container">
			<div class="col-sm-12 col-md-12 col-xs-12 ipSection">
				<div class="col-sm-12 col-xs-12 padding0 selfSkillTitile">
					<img src="../../inc/assets/img/about-us/intellect.png" alt="Intellect">
					<h2 class="sectionTitle">IP/Unique Proposition </h2>
				</div>
				<p class="para-content">PostCard Flow Game, DIG Estimation Model, Animal Estimation Game, Consulting PAEE, LAPM Model, <strong>INNOVATION ROOTS’</strong> Agile Transformation Model and many creative ideology, games, white-paper articles, blogs and approaches are our value additions for the beautiful people of world.</p>
			</div>
		</div>
	</section>
-->
    <!--ends intellect section-->

    <!--starts expertise section-->
    <section class="padding-section grey-section">
        <div class="container">
            <div class="col-sm-12 col-xs-12 col-md-12 ">
                
                <div class="col-sm-12 col-xs-12 expertise">
                    <p class="para-content">Our field of expertise involves Agile Software Development methods (Agile, XP, FDD, Scrum), Scaling Agile Frameworks (LeSS, SAFe<sup>&reg;</sup>, DAD), Lean School of Thinking (Kanban, Lean Product Development, Startup, UI/UX, Design Architecture), Engineering Practices (DevOps, CI/CD, Test Automation), Digital Marketing (SEO, SEM, PPC, Analytics), Core Management Concepts (Behaviour, Leadership, Change Implementation) and ALM Tools (Rally, TFS, Jira, V1) & Technology. We are an official partner of CA Technologies (formerly known as Rally Software)  and guide customer organizing with RallyDev ALM tool to scale up Agility at enterprise level.</p>
                    <p class="para-content">A range of regular publications from our research lab on various popular Thoughts, Ideas, Concepts and Practices are available at www.innovationroots.com/blog. The 'Interview Series' featuring global Thought Leaders is among the most popular and followed Publications on our blog. 'Continuous Delivery and Agility Meet-Up', and 'Open for All - Agile Library at Bangalore' are knowledge sharing and community initiatives developed by us. We also support various community events by Agile Network India, Scaling Agile Institute and Lean Kanban India.</p>
                </div>
            </div>
        </div>
    </section>
    <!--ends expertise section-->

    <!--starts key achievements section-->
    <section class="padding-section sec10">
        <div class="container">
        </div>
        <div class="container">
            <div class="col-sm-12 col-xs-12 firstBlockAchievement">
                <div class="col-sm-3 col-xs-12 achieveNumber">
                    <h2>1000+</h2>
                    <h3>Enrolled Participants</h3>
                    <p>Across different subjects, courses, topics and trained for various skills.</p>
                </div>
                <div class="col-sm-3 col-xs-12 achieveNumber">
                    <h2>200+</h2>
                    <h3>Certified Trainers</h3>
                    <p>Moulding Enthusiastic and Ambitious Professionals as Certified Trainers.</p>
                </div>
                <div class="col-sm-3 col-xs-12 achieveNumber">
                    <h2>100+</h2>
                    <h3>Esteemed Clients</h3>
                    <p>Prestigious Customer base that extends beyond various domains, sizes and shores.</p>
                </div>
                <div class="col-sm-3 col-xs-12 achieveNumber">
                    <h2>24000+</h2>
                    <h3>Hours of Consulting</h3>
                    <p>Delivered via our list of seasoned experts, across the globe, over the last five years.</p>
                </div>
            </div>
                
            <div class="col-sm-12 col-xs-12 firstBlockAchievement">

                <div class="col-sm-3 col-xs-12 achieveNumber">
                    <h2>100+</h2>
                    <h3>Public Events</h3>
                    <p>Keeping the Agile community close-knit and thriving through Meetups, Webinars and Conferences.</p>
                </div>
                <div class="col-sm-3 col-xs-12 achieveNumber">
                    <h2>2000+</h2>
                    <h3>Overall Attendees</h3>
                    <p>Across Cities, Nations and Organizations, marking a presence at our Public Events.</p>
                </div>
                <div class="col-sm-3 col-xs-12 achieveNumber">
                    <h2>10000+</h2>
                    <h3>Strong Reader Base</h3>
                    <p> Enthusiastic, Passionate and Opinionated readers browse our publishing daily.</p>
                </div>
                <div class="col-sm-3 col-xs-12 achieveNumber">
                    <h2>100+</h2>
                    <h3>Design Resources</h3>
                    <p>Created to enable creative, visually respondent minds into bringing alive their visions.</p>
                </div>
            </div>
        </div>
    </section>
    <!--ends key achievements section-->


    <!--starts timeline section-->

    
<!--
	<section>

		<div class="timeline-container" id="timeline-1">
			<div class="timeline">
				
				<div class="timeline-item" data-text="FATHER OF THE TURKS">
					<div class="timeline__content"><img class="timeline__img" src="http://i.cdn.ensonhaber.com/resimler/diger/ataturk_3473.jpg" />
						<h2 class="timeline__content-title">2018</h2>
						<p class="timeline__content-desc">He was born in 1881 (probably in the spring) in Salonica, then an Ottoman city, now inGreece. His father Ali Riza, a customs official turned lumber merchant, died when Mustafawas still a boy. His mother Zubeyde, adevout and strong-willed woman, raised him and his sister.</p>
					</div>
				</div>

				<div class="timeline-item" data-text="BLOGS">
					<div class="timeline__content"><img class="timeline__img" src="../../inc/assets/img/about-us/blog-2017.png" />
						<h2 class="timeline__content-title">2017</h2>
						<p class="timeline__content-desc">First enrolled in a traditionalreligious school, he soon switched to a modern school. In 1893, he entered a military highschool where his mathematics teacher gave him the second name Kemal (meaning perfection)in recognition of young Mustafa's superior achievement.</p>
					</div>
				</div>
				<div class="timeline-item" data-text="AGILE GURUGRAM">
					<div class="timeline__content"><img class="timeline__img" src="../../inc/assets/img/about-us/agile-gurugram_2016.png" />
						<h2 class="timeline__content-title">2016</h2>
						<p class="timeline__content-desc">Second Generation Lean Product Development Workshop - Applying Principles of Flow with Donald Reinersten (Author of Lean Product Development Flow) on September 12-13, 2016 at Hotel IBIS, Bangalore.</p>
						<p class="timeline__content-desc" style="margin-top:20px">Inception of Open for All - Agile Library @Bangalore started on February 2016</p>
					</div>
				</div>
				<div class="timeline-item" data-text="LEANKANBAN INDIA">
					<div class="timeline__content"><img class="timeline__img" src="../../inc/assets/img/about-us/leankanban_2015.png" />
						<h2 class="timeline__content-title">2015</h2>
						<p class="timeline__content-desc">First Ever Accredited Kanban Training (AKT) in India with David J. Anderson (Creator of Kanban Method) on December 14-18, 2015 at Aloft, Cessna Business Park, Bangalore.</p>
						<p class="timeline__content-desc" style="margin-top:20px">Organized and Sponsored first edition of Lean Kanban India Conference on December 11-12, 2015 at Hotel Aloft, Cessna Business Park, Bangalore</p>
					</div>
				</div>
				<div class="timeline-item" data-text="FATHER OF THE TURKS">
					<div class="timeline__content"><img class="timeline__img" src="http://ataturk.istanbul.gov.tr/GalleryLibrary/12.jpg" />
						<h2 class="timeline__content-title">2014</h2>
						<p class="timeline__content-desc">In 1915, when Dardanelles campaign was launched, Colonel Mustafa Kemal became anational hero by winning successive victories and finally repelling the invaders.</p>
					</div>
				</div>
				<div class="timeline-item" data-text="INCEPTION">
					<div class="timeline__content"><img class="timeline__img" src="../../inc/assets/img/about-us/World%20map-02A-01.png" width="100%" alt="World Map" />
						<h2 class="timeline__content-title">2013</h2>
						<p class="timeline__content-desc">Inception of Scaling Agile Institute (formerly known as Scaling Agile India) Meetup on December 2013.</p>
					</div>
				</div>
			</div>
		</div>

	</section>
-->


    <!--ends timeline section-->

    <?php include('../../includes/footer.php');?>
    
     <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>
    <!--end pure chat-->

    <script>
        window.onscroll = function() {
            scrollFunction()
        };

        function scrollFunction() {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                document.getElementById("myBtn").style.display = "block";
            } else {
                document.getElementById("myBtn").style.display = "none";
            }
        }

        function topFunction() {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        }

    </script>

    <!--Starts Aboutus history JQuery-->
    <script>
        (function($) {
            $.fn.timeline = function() {
                var selectors = {
                    id: $(this),
                    item: $(this).find(".timeline-item"),
                    activeClass: "timeline-item--active",
                    img: ".timeline__img"
                };
                selectors.item.eq(0).addClass(selectors.activeClass);
                selectors.id.css(
                    "background-image",
                    "url(" +
                    selectors.item
                    .first()
                    .find(selectors.img)
                    .attr("src") +
                    ")"
                );
                var itemLength = selectors.item.length;
                $(window).scroll(function() {
                    var max, min;
                    var pos = $(this).scrollTop();
                    selectors.item.each(function(i) {
                        min = $(this).offset().top;
                        max = $(this).height() + $(this).offset().top;
                        var that = $(this);
                        if (i == itemLength - 2 && pos > min + $(this).height() / 2) {
                            selectors.item.removeClass(selectors.activeClass);
                            selectors.id.css(
                                "background-image",
                                "url(" +
                                selectors.item
                                .last()
                                .find(selectors.img)
                                .attr("src") +
                                ")"
                            );
                            selectors.item.last().addClass(selectors.activeClass);
                        } else if (pos <= max - 40 && pos >= min) {
                            selectors.id.css(
                                "background-image",
                                "url(" +
                                $(this)
                                .find(selectors.img)
                                .attr("src") +
                                ")"
                            );
                            selectors.item.removeClass(selectors.activeClass);
                            $(this).addClass(selectors.activeClass);
                        }
                    });
                });
            };
        })(jQuery);

        $("#timeline-1").timeline();

    </script>
    <!--Ends Aboutus history JQuery-->

    <!----scripts used------>
    <script type="text/javascript" src="../../inc/assets/js/bootstrap.min.js"></script>

</body>

</html>
