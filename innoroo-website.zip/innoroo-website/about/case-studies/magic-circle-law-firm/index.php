<!--Updated On 28-03-2018GA
	Meta tag updated
-->

<!DOCTYPE html>
<html lang="en">

<head>
    <title>INNOVATION ROOTS | About | Case Study | Magic Circle Law Firm | Best Law firm in the London</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Look at on how INNOVATION ROOTS has helped a UK-based multinational law office in setting up a guide to Agile.">
    <meta name=author content="Innovation Roots Softech Pvt. Ltd.">
    <meta name="ROBOTS" content="INDEX, FOLLOW">
    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->
    <link href="../../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
    <link href="../../../inc/assets/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../../../inc/assets/css/newsletter_form.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../../../inc/assets/css/main.css" rel="stylesheet" />
    <script src="../../../inc/assets/js/modernizr.custom.83079.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="../../../inc/assets/img/favicon.ico">

    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>

    

    <script type="text/javascript">
        document.oncontextmenu = new Function("return false");
        document.onselectstart = new Function("return false");
        if (window.sidebar) {
            document.onmousedown = new Function("return false");
            document.onclick = new Function("return true");
            document.oncut = new Function("return false");
            document.oncopy = new Function("return false");
            document.onpaste = new Function("return false");
        }

    </script>


</head>

<body>
    <?php include('../../../includes/header.php');?>

    <!--start registeration section-->
    <section class="padding-top-section home-cover case-study-firm">
        <div class="container cs-container">
            <div class="col-sm-12 col-md-12 col-xs-12 cs-section">
                <h2>How a Law Firm aligned IT to Business and benefited from Agile and SAFe<sup>&reg;</sup> Transformation?</h2>
                <h3>2013-2014</h3>
                <h3>Magic Circle Law Firm, UK & India</h3>
            </div>
        </div>
    </section>
    <!--end registeration section-->

    <!--start overview section-->
    <section class="cs-padding-section">
        <div class="container">
            <div class="col-sm-12 col-md-12 col-xs-12 businessChallenges">
                <h2 class="sectionTitle">Business Challenges</h2>
                <p>One of world's leading multinational law firm headquartered in London, United Kingdom, and which is a member of the "Magic Circle" of leading British law firms with offices across Europe, Asia, Middle East and America, was planning to implement new strategy to improve team's speed of delivery and cater better IT outcome to business.</p>
                <p>Since years, the company's IT teams were practicing various version of Agile concepts, to ameliorate delivery and streamline their development & release practices for more desirable business results. There was a need for improvement in the outcomes as per company's Business and IT leadership.</p>
                <p>The IT leadership team decided to identify ways to become more lean and agile at whole enterprise level. As part of their evaluation they came to a selection of Scaled Agile Framework (SAFe<sup>&reg;</sup>) and started looking for trusted and skilled provider for consulting services on SAFe<sup>&reg;</sup>.</p>
                <p>In the year 2013-2014, the company approached <strong class="innoroo">INNOVATION ROOTS</strong> to assess the current process and implement Agile and SAFe<sup>&reg;</sup> practices.</p>
                <p><strong class="innoroo">INNOVATION ROOTS</strong> started with planning for transformation using best practices of Lean-Agile and SAFe<sup>&reg;</sup>, define the steps for adapting Change in current process, identify the key challenges in adoption of Agile and SAFe practices, and harmonize the overall implementation with the expertise in Consultancy.</p>
            </div>
        </div>
    </section>
    <!--end overview section-->

    <!--start solution section-->
    <section class="cs-padding-section solution-section">
        <div class="container">
            <div class="col-sm-12 col-xs-12 col-md-12">
                <h2 class="sectionTitle">Solution</h2>
                <p>At first phase, <strong class="innoroo">INNOVATION ROOTS</strong> organised conversations with Leadership team and conducted an assessment program to identify the gaps in company's current business process and started to orchestrate a well-defined Scaled Agile based model to start.</p>
                <p>As an outcome of the assessment program, we found key challenges, which include</p>
                <ul>
                    <li>
                        <p>There was less clarity for Scrum Master and Product Owner roles, and there were exiting roles like Production Managers, and IT Support Management, with not clear responsibilities in agile teams</p>
                    </li>
                    <li>
                        <p>The team's understanding was very high level about the Portfolio and Vision</p>
                    </li>
                    <li>
                        <p>There were no structured Roadmap and Release plan in place for long term objectives</p>
                    </li>
                    <li>
                        <p>There were challenges in identifying Product backlog priority and sorting cross-team dependency</p>
                    </li>
                    <li>
                        <p>These was lack of visibility in Progress, addressing & resolving critical business issues</p>
                    </li>
                    <li>
                        <p>More focus was on development utilisation, rather than Capacity Planning and Priority driven delivery.</p>
                    </li>
                </ul>
                <p>Transformation started with, identifying the strategy and creating detail step-by-step plan for implementations. A cohesive team of IT, Business leadership and our expert Agile Coach drafted tactics to move to portfolio, value stream setup and launch the trains.  On the way to transformation, we  provided consulting on</p>
                <ul>
                    <li>
                        <p>Leadership education, and Value stream mapping to turn into a value-centric organization</p>
                    </li>
                    <li>
                        <p>Facilitation of Portfolio & Value Mapping and Product Vision</p>
                    </li>
                    <li>
                        <p>Roadmap and Release plan facilitation </p>
                    </li>
                    <li>
                        <p>Team-level Agile, SAFe<sup>&reg;</sup>, Scrum, and XP training to participants</p>
                    </li>
                    <li> 
                        <p>Role-based Scrum Master and Product Owner training</p>
                    </li>
                    <li>
                        <p>Agile, SAFe<sup>&reg;</sup>, and Scrum Ceremony mentoring and coaching</p>
                    </li>
                    <li>
                        <p>Conducting Scrum of Scrum, Inspect & Adapt and Continues Learning cycles</p>
                    </li>
                    <li>
                        <p>Rollout Transformation at enterprise level and at multiple portfolios & programs</p>
                    </li>
                    <li>
                        <p>Established Agile based Project Management Office facilitation and metrics</p>
                    </li>
                </ul>
            </div>
        </div>
    </section>
    <!--end solution section-->

    <!--start Outcomes section-->
    <section class="cs-padding-section">
        <div class="container">
            <div class="col-sm-12 col-xs-12 col-md-12 outcomesection">
                <h2 class="sectionTitle">Outcomes</h2>

                <p>This transformation program ran for a year and a half, while changing all programs to Agile, Scrum and SAFe<sup>&reg;</sup> ways of working in incrementals, and finally, this rolled out the transformation successfully at the  whole enterprise-level.</p>
                <ul>
                    <li>
                        <p>There was a great increase in understanding the Agile & SAFe<sup>&reg;</sup> concepts at teams and the enterprise</p>
                    </li>
                    <li>
                        <p>Teams gained clarity on their roles and responsibilities, and improved their contribution to deliver early and often high quality increments</p>
                    </li>
                    <li>
                        <p>Scrum Master, Product Management, Product Owners gained role clarity and focus on responsibilities, and effectively deliver value for enterprise </p>
                    </li>
                    <li>
                        <p>Teams transformed into a prioritization-driven work model along with an adaptive planning for multiple releases, which improved enterprises' confidence on teams and programs</p>
                    </li>
                    <li>
                        <p>A highly proficient and self-managing Lean-Agile competencies has established to support teams and programs practicing Agile, SAFe-Scrum Ceremonies. These Program-level practices, and the I&A workshop enabled continuous learning in teams, reflecting their performance, and synchronizes the teams behaviour accordingly.</p>
                    </li>
                </ul>
            </div>
        </div>
    </section>
    <!--end Outcomes section-->

    <!--start contact us section-->
    <section class="contact_us_bg_page no-margin-bottom margin_top_contact cs-contact">
        <div class="container">
            <div class="col-sm-12 col-xs-12">
                <div class="col-sm-12 col-xs-12">
                    <h2 class="contact_training_title1">Contact Us</h2>
                    <h4 class="contact_training_title2">To learn more about how we can help you assess your current Agile Practices & Teams and get coaching support.</h4>
                    <a href="../../../about/contact/" class="training_contact">Contact</a>
                </div>
            </div>
        </div>
    </section>
    <!--end contact us section-->
    <?php include('../../../includes/footer.php');?>
    
     <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>
    <!--end pure chat-->

</body>

</html>
