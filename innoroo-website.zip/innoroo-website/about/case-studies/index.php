<!DOCTYPE html>
<html lang="en">

<head>
    
    <!--Updated On 07-07-2018 MI
meta tag updated-->
    <title>INNOVATION ROOTS | About | Case Study | Best Casestudy in 2018 </title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!--Description Tag Meta Start-->
    <!--Updated for 07.07.18 version MI-->
    <meta name="description" content="Look at our client suceess stories and become further familiar with relating to us">
    <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
    <meta name="ROBOTS" content="INDEX, FOLLOW">
    <!-- OPEN GRAPH META TAG STARTS -->
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
    <link href="../../inc/assets/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="../../inc/assets/css/newsletter_form.css">
    <!-- Icon Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../../inc/assets/css/main.css" rel="stylesheet" />
    <script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">

    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>


<!--
    <script type="text/javascript">
        document.oncontextmenu = new Function("return false");
        document.onselectstart = new Function("return false");
        if (window.sidebar) {
            document.onmousedown = new Function("return false");
            document.onclick = new Function("return true");
            document.oncut = new Function("return false");
            document.oncopy = new Function("return false");
            document.onpaste = new Function("return false");
        }
    </script>
-->
    
</head>

<body>
    <?php include('../../includes/header.php');?>

    <!--starts feature image section here-->
     <section class="page-cover_bg">
            <div class="page_bg bg_overlay "></div>
                <div class="container">
                    <div class="page_center_caption" style="top: 55%">
                        <h1 class="text_center text_safe" style="text-transform: none !important;">Case Study</h1>
                         <div class=text_center_hr></div> 
                        <h3 class= "scrum_sub_title">Look how Innovation Roots Transformed Customer's Business</h3>
                    </div>
                </div>
        </section>
    <!--ends feature image section here-->

    <!--starts listing section here-->
    <section class="section-listing-page case-study" style="margin:0px ; background-color: #f2f2f2">
            <div class="container">
                <div class="row">

                <!--start Support Automation Product Company-->
                <div class="col-md-4 col-sm-6 col-xs-12 listing_training_page">
                    <div class="training-listcard-section" style="background-color: #fff">
                        <div class="row">
                            <div class="col-sm-12 col-xs-12">
                                <div class="case-study-image-new col-sm-12">
                                    <img src="../../inc/assets/img/case-study/support-automation-company.png" class="img-responsive  csimage" alt="Automation Company">
                                </div>
                                <div class="col-sm-12 col-xs-12 caseProduct Automation">
                                    <p class="listing-training-topic cs-card">
                                        How a Support Automation Product Company Increased Productivity?
                                    </p>
                                    <a href="../case-studies/niche-it-support-automation-product-company/">
                                        <button class="btn card-btn">KNOW MORE</button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end Support Automation Product Company-->

                <!--start UK based Law Firm-->
                <div class="col-md-4 col-sm-6 col-xs-12 listing_training_page">
                    <div class="training-listcard-section" style="background-color: #fff">
                        <div class="row">
                            <div class="col-sm-12 col-xs-12">
                                <div class="case-study-image-new col-sm-12">
                                    <img src="../../inc/assets/img/case-study/uk-based-law-firm.png" class="img-responsive csimage" alt="Law Firm">
                                </div>
                                <div class="col-sm-12 col-xs-12 caseProduct firm">
                                    <p class="listing-training-topic cs-card">
                                        How a Law Firm aligned IT to Business and benefited from Agile and SAFe<sup>&reg;</sup> Transformation?
                                    </p>
                                    <a href="../case-studies/magic-circle-law-firm/">
                                        <button class="btn card-btn">KNOW MORE</button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end UK based Law Firm-->

                <!--start solar wind-->
                <div class="col-md-4 col-sm-6 col-xs-12 listing_training_page">
                    <div class="training-listcard-section" style="background-color: #fff">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="case-study-image-new col-sm-12">
                                    <img src="../../inc/assets/img/case-study/uk-based-it-netwok-management-company.png" class="img-responsive csimage" alt="Network Managemet">
                                </div>
                                <div class="col-sm-12 caseProduct networkManagement">
                                    <p class="listing-training-topic cs-card">
                                        How did an IT Product Company gain Business Agility in Product Development?
                                    </p>
                                    <a href="../case-studies/leading-it-network-management-product-company/">
                                        <button class="btn card-btn">KNOW MORE</button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!--end solar wind-->
                <!-- <div class="col-md-4 col-sm-6 col-xs-12 listing_training_page">
                        <div class="training-listcard-section" style="background-color: #fff">
                            <div class="row">
                            <div class="col-sm-12">
                                <div class="case-study-image-new col-sm-12">
                                    <img src="../../inc/assets/img/case-study/retail-giant%C2%A0-in-uk.png" class="img-responsive csimage" alt="Retail Giant">
                                </div>
                                <div class="col-sm-12 caseProduct retail">
                                <p class="listing-training-topic cs-card">
                                    Retail Gaint in UK
                                </p>
                                <a href="#">
                                        <button class="btn card-btn">KNOW MORE</button>
                                    </a>
                            </div>
                            </div>
                            </div>
                            
                        </div>
                    </div>
                   
                    <div class="col-md-4 col-sm-6 col-xs-12 listing_training_page">
                        <div class="training-listcard-section" style="background-color: #fff">
                            <div class="row">
                            <div class="col-sm-12">
                                <div class="case-study-image-new col-sm-12">
                                    <img src="../../inc/assets/img/case-study/leader-in-software-and-contact-center.png" class="img-responsive csimage" alt="Leader Software and Contact">
                                </div>
                                <div class="col-sm-12 caseProduct contactCentre">
                                <p class="listing-training-topic cs-card">
                                    A leader in Software and Contact Center
                                </p>
                                <a href="#">
                                        <button class="btn card-btn">KNOW MORE</button>
                                    </a>
                            </div>
                            </div>
                            </div>
                            
                        </div>
                    </div>
                     <div class="col-md-4 col-sm-6 col-xs-12 listing_training_page">
                        <div class="training-listcard-section" style="background-color: #fff">
                            <div class="row">
                            <div class="col-sm-12">
                                <div class="case-study-image-new col-sm-12">
                                    <img src="../../inc/assets/img/case-study/ge-transportation-systems.png" class="img-responsive csimage" alt="Global Leader">
                                </div>
                                <div class="col-sm-12 caseProduct locomotive">
                                <p class="listing-training-topic cs-card">
                                    Global Leader in Locomotives and Services
                                </p>
                                <a href="#">
                                        <button class="btn card-btn">KNOW MORE</button>
                                    </a>
                            </div>
                            </div>
                            </div>
                            
                        </div>
                    </div>
					
					<div class="col-md-4 col-sm-6 col-xs-12 listing_training_page">
                        <div class="training-listcard-section" style="background-color: #fff">
                            <div class="row">
                            <div class="col-sm-12">
                                <div class="case-study-image-new col-sm-12">
                                    <img src="../../inc/assets/img/case-study/ge-transportation-systems.png" class="img-responsive csimage" alt="Global Leader">
                                </div>
                                <div class="col-sm-12 caseProduct financialLeader">
                                <p class="listing-training-topic cs-card">
                                    Global Financial Leader
                                </p>
                                <a href="#">
                                        <button class="btn card-btn">KNOW MORE</button>
                                    </a>
                            </div>
                            </div>
                            </div>
                            
                        </div>
                    </div>
					<div class="col-md-4 col-sm-6 col-xs-12 listing_training_page">
                        <div class="training-listcard-section" style="background-color: #fff">
                            <div class="row">
                            <div class="col-sm-12">
                                <div class="case-study-image-new col-sm-12">
                                    <img src="../../inc/assets/img/case-study/ge-transportation-systems.png" class="img-responsive csimage" alt="Global Leader">
                                </div>
                                <div class="col-sm-12 caseProduct telecom">
                                <p class="listing-training-topic cs-card">
                                    Telecom Service Product
                                </p>
                                <a href="#">
                                        <button class="btn card-btn">KNOW MORE</button>
                                    </a>
                            </div>
                            </div>
                            </div>
                            
                        </div>
                    </div>
					<div class="col-md-4 col-sm-6 col-xs-12 listing_training_page">
                        <div class="training-listcard-section" style="background-color: #fff">
                            <div class="row">
                            <div class="col-sm-12">
                                <div class="case-study-image-new col-sm-12">
                                    <img src="../../inc/assets/img/case-study/ge-transportation-systems.png" class="img-responsive csimage" alt="Global Leader">
                                </div>
                                <div class="col-sm-12 caseProduct paymentGateway">
                                <p class="listing-training-topic cs-card">
                                    Global Payment Gateway Leader
                                </p>
                                <a href="#">
                                        <button class="btn card-btn">KNOW MORE</button>
                                    </a>
                            </div>
                            </div>
                            </div>
                            
                        </div>
                    </div>
					<div class="col-md-4 col-sm-6 col-xs-12 listing_training_page">
                        <div class="training-listcard-section" style="background-color: #fff">
                            <div class="row">
                            <div class="col-sm-12">
                                <div class="case-study-image-new col-sm-12">
                                    <img src="../../inc/assets/img/case-study/ge-transportation-systems.png" class="img-responsive csimage" alt="Global Leader">
                                </div>
                                <div class="col-sm-12 caseProduct clinical">
                                <p class="listing-training-topic cs-card">
                                    Clinical Trial Company
                                </p>
                                <a href="#">
                                        <button class="btn card-btn">KNOW MORE</button>
                                    </a>
                            </div>
                            </div>
                            </div>
                            
                        </div>
                    </div>
					<div class="col-md-4 col-sm-6 col-xs-12 listing_training_page">
                        <div class="training-listcard-section" style="background-color: #fff">
                            <div class="row">
                            <div class="col-sm-12">
                                <div class="case-study-image-new col-sm-12">
                                    <img src="../../inc/assets/img/case-study/ge-transportation-systems.png" class="img-responsive csimage" alt="Global Leader">
                                </div>
                                <div class="col-sm-12 caseProduct leaderCard">
                                <p class="listing-training-topic cs-card">
                                    American Leader in Card
                                </p>
                                <a href="#">
                                        <button class="btn card-btn">KNOW MORE</button>
                                    </a>
                            </div>
                            </div>
                            </div>
                            
                        </div>
                    </div>
					<div class="col-md-4 col-sm-6 col-xs-12 listing_training_page">
                        <div class="training-listcard-section" style="background-color: #fff">
                            <div class="row">
                            <div class="col-sm-12">
                                <div class="case-study-image-new col-sm-12">
                                    <img src="../../inc/assets/img/case-study/ge-transportation-systems.png" class="img-responsive csimage" alt="Global Leader">
                                </div>
                                <div class="col-sm-12 caseProduct bankofAmerica">
                                <p class="listing-training-topic cs-card">
                                    Leading Bank of US
                                </p>
                                <a href="#">
                                        <button class="btn card-btn">KNOW MORE</button>
                                    </a>
                            </div>
                            </div>
                            </div>
                            
                        </div>
                    </div>
					<div class="col-md-4 col-sm-6 col-xs-12 listing_training_page">
                        <div class="training-listcard-section" style="background-color: #fff">
                            <div class="row">
                            <div class="col-sm-12">
                                <div class="case-study-image-new col-sm-12">
                                    <img src="../../inc/assets/img/case-study/ge-transportation-systems.png" class="img-responsive csimage" alt="Global Leader">
                                </div>
                                <div class="col-sm-12 caseProduct mphasis">
                                <p class="listing-training-topic cs-card">
                                   Leading Services MNC Devops
                                </p>
                                <a href="#">
                                        <button class="btn card-btn">KNOW MORE</button>
                                    </a>
                            </div>
                            </div>
                            </div>
                            
                        </div>
                    </div>
					<div class="col-md-4 col-sm-6 col-xs-12 listing_training_page">
                        <div class="training-listcard-section" style="background-color: #fff">
                            <div class="row">
                            <div class="col-sm-12">
                                <div class="case-study-image-new col-sm-12">
                                    <img src="../../inc/assets/img/case-study/ge-transportation-systems.png" class="img-responsive csimage" alt="Global Leader">
                                </div>
                                <div class="col-sm-12 caseProduct sabre">
                                <p class="listing-training-topic cs-card">
                                   Leading Travel Portal
                                </p>
                                <a href="#">
                                        <button class="btn card-btn">KNOW MORE</button>
                                    </a>
                            </div>
                            </div>
                            </div>
                            
                        </div>
                    </div>
-->

            </div>
        </div>
    </section>
    <!--listing section ends here-->

    <?php include('../../includes/footer.php');?>
    
     <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>
    <!--end pure chat-->
</body>

</html>
