<!--Updated On 28-03-2018GA
	Meta tag updated
-->

<!DOCTYPE html>
<html lang="en">

<head>
	<title>INNOVATION ROOTS | About | Careers</title>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- OPEN GRAPH META TAG STARTS -->
	<meta property="og:title" content="INNOVATION ROOTS" />
	<meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
	<meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
	<meta property="og:url" content="www.innoroo.com" />
	<!-- OPEN GRAPH META TAG ENDS -->
	<meta name="description" content="Check out the currently open jobs.">
	<meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
	<meta name="ROBOTS" content="INDEX, FOLLOW">
	<link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
	<link href="../../inc/assets/css/bootstrap.min.css" rel="stylesheet" />
	<link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="../../inc/assets/css/main.css" rel="stylesheet" />
	<link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">
	<script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
	<script>
		(function(d, e, j, h, f, c, b) {
			d.GoogleAnalyticsObject = f;
			d[f] = d[f] || function() {
				(d[f].q = d[f].q || []).push(arguments)
			}, d[f].l = 1 * new Date();
			c = e.createElement(j), b = e.getElementsByTagName(j)[0];
			c.async = 1;
			c.src = h;
			b.parentNode.insertBefore(c, b)
		})(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
		ga("create", "UA-100332682-2", "auto");
		ga("send", "pageview");

	</script>
	<!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->
	<script type='text/javascript' data-cfasync='false'>
		window.purechatApi = {
			l: [],
			t: [],
			on: function() {
				this.l.push(arguments);
			}
		};
		(function() {
			var done = false;
			var script = document.createElement('script');
			script.async = true;
			script.type = 'text/javascript';
			script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
			document.getElementsByTagName('HEAD').item(0).appendChild(script);
			script.onreadystatechange = script.onload = function(e) {
				if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
					var w = new PCWidget({
						c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
						f: true
					});
					done = true;
				}
			};
		})();

	</script>

	<script type="text/javascript">
		document.oncontextmenu = new Function("return false");
		document.onselectstart = new Function("return false");
		if (window.sidebar) {
			document.onmousedown = new Function("return false");
			document.onclick = new Function("return true");

			document.oncut = new Function("return false");

			document.oncopy = new Function("return false");


			document.onpaste = new Function("return false");
		}

	</script>
</head>

<body>
	<?php include('../../includes/header.php');?>
	<section class="page-cover-half">
		<div class="container">
			<div class="page-cover-bg career-bg opacity-2"></div>
			<div class="page_center_caption">
				<h1 class="main_title">Careers</h1>
				<div class="career_center_hr"></div>
				<h2 class="heading_sub_page">We are Hiring</h2>
			</div>
		</div>
	</section>
	<section class="section">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="page-cover-para">We are currently hiring Agile Coaches in Bangalore. The selected applicants will be joining as a Consultant with our high performing team which is engaged in executing Agile Transformation for the Global Customers.</p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="job-section">
						<div class="row">
							<div class="col-md-3">
								<div class="label">Current Openings</div>
							</div>
							<div class="col-md-9">
								<div class="job-content">
									<div class="panel-group" id="accordion">
										<div class="panel panel-default">
											
											<div class="panel-heading">
												<h4 class="panel-title">
													<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">Enterprise Agile Coach (EAC)</a>
												</h4>
											</div>
											<div id="collapseOne" class="panel-collapse collapse in">
												<div class="panel-body">
													<p>We are looking for applicants who have passion & experience in coaching Agile and Lean concepts within a scaled environment.</p>
													<ul class="unstyled">
														<li>
															<strong>Location:</strong>&nbsp;Bengaluru
														</li>
														<li>
															<strong>Job Type:</strong>&nbsp; Full time and Part time(Long Term).
														</li>
													</ul>
													<p><strong>What will you do?</strong></p>
													<ul>
														<li>Working with clients and maintaining client relationships through collaboration with other Agile Coaches.</li>
														<li>Develop technical expertise and emotional intelligence to guide customers in launching agile teams, programs and portfolios in large organizations</li>
														<li>Develop our own training material in close partnership with INNOROO's expert Agile Coaches and deliver training to customer teams both in-person and remotely</li>
														<li>Lead and mentor technical teams</li>
														<li>Coach, teach and guide people in various roles in project and product-driven organizations</li>
														<li>Drive result in organization change and influence people to appreciate Agile ways of working</li>
														<li>Facilitation and leading of planning meetings, reviews, and retrospective</li>
													</ul>
													<p><strong>What are we looking for?</strong></p>
													<ul>
														<li>Prior experience in coaching Agile teams with methods such as Scrum, SAFe, Kanban, XP, and Lean in a scaled environment is essentials</li>
														<li>Excellent presentation skills,to be able to deliver due training to batches of all sizes</li>
														<li>In-depth knowledge about Agile principles and practices and passion to excel</li>
														<li>Experienced in leading consulting engagements from end-to-end agile transformation perspective. It may include but not limited to training & course deck production, contact writing, approach creation, coaching teams on the job and leadership mentoring</li>
														<li>SAFe Program Consultant (SPC) and/or Certified Scrum Professional (CSP) is preferred</li>
														<li>10+ years or more experience in technology/software organizations</li>
														<li>5+ years of experience with leading and coaching Agile teams</li>
														<li>Expertise in leading & communicating at all levels of an organisation - from C suite down to all levels of the delivery team</li>
														<li>Experience and knowledge of HP ALM tool and JIRA is strongly preferred</li>
														<li>Training experience on Agile, Scrum and Kanban with standard content and tailored context to customer's need</li>
														<li>Open to travel to different customer sites</li>
													</ul>
													<h6>Does it excite you?</h6>
													<p>Please apply with your profile at <a href="mailto:careers@innovationroots.com">careers@innovationroots.com</a></p>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="job-content">
									<div class="panel-group" id="accordion">
										<div class="panel panel-default">
											<div class="panel-heading">
												<h4 class="panel-title">
													<a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">Web Developer </a>
												</h4>
											</div>
											<div id="collapseTwo" class="panel-collapse collapse in">
												<div class="panel-body">
													<ul class="unstyled">
														<li>
															<strong>Experience:</strong>&nbsp;1 to 3 years
														</li>
														<li>
															<strong>Location:</strong>&nbsp;Bengaluru
														</li>
														<li>
															<strong>Job Type:</strong>&nbsp; Full time
														</li>
													</ul>
													<p><strong>What will you do?</strong></p>
													<ul>
														<li>Collaborate with business stakeholders and customers to discover business goals and devise the scope of work </li>
														<li>Develop in-depth understanding and strategize plan of action to deliver customer's requirement/value </li>
														<li>Propose layouts, navigation and functionality for web development project(s) </li>
														<li>Design, Build and Test Websites & Web applications based on cross-browser compatibility, general web functions and standards </li>
														<li>Maintaining, updating and adding new features to website as and when required by business stakeholders and customers </li>
														<li>Communicate with clients and colleagues to troubleshoot and optimize solutions </li>
														<li>Create solutions on search engine optimization (SEO) to develop high ranking websites </li>
														<li>Provide support on Digital Channel and Platforms to empower Digital Marketing efforts </li>
														<li>Continuously learn new technologies to enhance self and company's capabilities to deliver next generation solutions </li>
														<li>Manage to release features based on business priority and implement feedbacks to ensure fit-for-purpose solutions </li>
													</ul>
													<p><strong>What are we looking for?</strong></p>
													<ul>
														<li>
															In-depth working experience on HTML5, CSS3, JavaScript, jquery
														</li>
														<li>
															Must know one or more server-side programming languages such as Java, PHP or .Net
														</li>
														<li>
															Experience to create crowdsourcing platforms, e-commerce solution, social networking website, community & conference web portals, blog posting applications etc.
														</li>
														<li>
															Working experience on almost all types of website features like responsive, payment gateway, user profile management, blogging, mailer etc.
														</li>
														<li>
															Creative skills to turn clients ideas into workable and valuable solutions Working experience on Flash and similar tools to develop vector graphics and rich internet applications Develop websites that interact with popular database systems like MySQL, SQL Server & Oracle
														</li>
													</ul>
													<h6>Does it excite you?</h6>
													<p>Please apply with your profile at <a href="mailto:careers@innovationroots.com">careers@innovationroots.com</a></p>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="job-content">
									<div class="panel-group" id="accordion">
										<div class="panel panel-default">
											<div class="panel-heading">
												<h4 class="panel-title">
													<a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">Content Writer</a>
												</h4>
											</div>
											<div id="collapseThree" class="panel-collapse collapse in">
												<div class="panel-body">
													<ul class="unstyled">
														<li>
															<strong>Experience:</strong>&nbsp;0 to 2 years
														</li>
														<li>
															<strong>Location:</strong>&nbsp;Bengaluru
														</li>
														<li>
															<strong>Job Type:</strong>&nbsp; Full time
														</li>
													</ul>
													<p><strong>What will you do?</strong></p>
													<ul>
														<li>Have clear idea of the competitors and the target audience</li>
														<li> Create, develop and manage research-based content related to business for website, blog and other company web properties</li>
														<li>Ensure content compliance to Digital Marketing standards</li>
														<li>Continuous monitoring of efficacy of content and communication</li>
														<li>Continuously innovating refreshing content delivery</li>
														<li>Develop highly effective, original and targeted content for the promotion and marketing communications</li>
														<li>Proof read copy to check spelling and grammar, amend, revise or redevelop campaign in response to feedback from the creative manager</li>
														<li>Develop content marketing ideas and concepts, present ideas to colleagues and creative manager</li>
														<li>Social Media Marketing and day-to-day management of the brand presence on Google+. LinkedIn, Facebook, Twitter, YouTube and other channels</li>
														<li>Database Management for the use of sales teams</li>
														<li>Network with other experts and thought leaders inside and outside the company to stay abreast of trends and identify new ideas for content</li>
														<li>Find new ways to go to market that drive attention</li>
														<li>Track monthly growth over social media channels and share with the team</li>
													</ul>
													<p><strong>What are we looking for?</strong></p>
													<ul>
														<li> Expert written and verbal communication skills </li>
														<li> A knack for editing and proof reading with good research skills </li>
														<li> Ability to work in highly charged environment without compromising on quality </li>
														<li> Innovative, enthusiastic and a quick thinker </li>
														<li> Proficiency in Microsoft Office </li>
														<li> Good to have exposure to Digital Marketing Practices </li>
														<li> Knowledge of SEO practices; SEO-centered writing experience is preferable </li>
														<li> Possess innovative spirit and a willingness to think and execute outside of the box </li>
														<li> Good interpersonal skills </li>
													</ul>
													<h6>Does it excite you?</h6>
													<p>Please apply with your profile at <a href="mailto:careers@innovationroots.com">careers@innovationroots.com</a></p>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="job-content">
									<div class="panel-group" id="accordion">
										<div class="panel panel-default">
											<div class="panel-heading">
												<h4 class="panel-title">
													<a data-toggle="collapse" data-parent="#accordion" href="#collapseFour">Sales and Marketing Executive</a>
												</h4>
											</div>
											<div id="collapseFour" class="panel-collapse collapse in">
												<div class="panel-body">
													<ul class="unstyled">
														<li>
															<strong>Experience:</strong>&nbsp;0 to 2 years
														</li>
														<li>
															<strong>Location:</strong>&nbsp;Bengaluru
														</li>
														<li>
															<strong>Job Type:</strong>&nbsp; Full time
														</li>
													</ul>
													<p><strong>What will you do?</strong></p>
													<p style="margin-top:10px">Sales</p>
													<ul>
														<li> Gather market and customer information </li>
														<li>Identify and network with prospective clients, generating business from existing accounts and achieve profitability and increase sales growth</li>
														<li>Have sound knowledge of company offerings and services</li>
														<li>Prospect the potential customers</li>
														<li> Perform customer identification and customer profiling as per the company activity</li>
														<li> Approach (via mail, call etc.) the prospects</li>
														<li>Cold calling to arrange meetings with potential customers to prospect for new business</li>
														<li> Perform need assessment of the prospects</li>
														<li> Tailor the presentation to the audience, and keep it interactive</li>
														<li>Listen to customer requirements and present appropriately to make a sale</li>
														<li>Make accurate, rapid cost calculations and provide customer with quotations</li>
														<li>Negotiate the terms of an agreement and close sales</li>
														<li>Follow up with the customers to maintain and grow business relationship</li>
														<li>Review your own sales performance, aim to meet or exceed targets</li>
														<li>Create monthly status report based on competition analysis</li>
														<li> Discuss future buying trends with reporting manager</li>
														<li> Attend team meetings and share best practices with colleagues</li>
														<li>Represent the company at trade exhibitions, conferences, events, and demonstrations</li>
													</ul>
													<p>Marketing</p>
													<ul>
														<li> Create awareness about the company offerings in the market place</li>
														<li>Liaising with other departments to understand marketing requirements</li>
														<li> Communicate with target audiences and managing customer relationships</li>
														<li> Manage production of marketing materials, including leaflets, poster, flyers, newsletters, and e-newsletters</li>
														<li> Arrange the effective distribution of marketing materials</li>
														<li> Maintain and update customer database</li>
														<li> Organize and attend events such as conferences, seminars, exhibitions</li>
														<li> Source and secure sponsorships</li>
														<li> Manage budgets</li>
														<li> Contribute to develop marketing plan and strategy</li>
														<li> Actively use social media channels to spread the word around and broaden the customer base.</li>
													</ul>
													<p><strong>What are we looking for?</strong></p>
													<ul>
														<li>Excellent written and verbal communication skills</li>
														<li> The ability and desire to sell</li>
														<li> A positive, confident and determined approach </li>
														<li> Resilience and the ability to cope with rejection</li>
														<li>Good interpersonal skills</li>
														<li>The skills to work both independently and as a part of a team</li>
														<li>Capable to flourish in a competitive environment</li>
														<li> A good level of numeracy and analytical skills</li>
													</ul>
													<h6>Does it excite you?</h6>
													<p>Please apply with your profile at <a href="mailto:careers@innovationroots.com">careers@innovationroots.com</a></p>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php include('../../includes/footer.php');?>
</body>

</html>
