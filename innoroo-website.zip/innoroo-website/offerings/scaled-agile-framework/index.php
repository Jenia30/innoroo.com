<!DOCTYPE html>
<html lang="en">

<head>

	<!--Updated On 07-07-2018 MI
meta tag updated
-->


	<title>INNOVATION ROOTS | Offerings | Scaled Agile Framework | One of the best training and certifications on Scaled Agile Framework trainings </title>
	<meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Description Tag Meta Start -->
	<!-- Updated 07.07.18 Version MI -->
    <meta name="description" content="This two-day course teaches the Lean-Agile principles and practices of the Scaled Agile Framework® (SAFe®). You'll learn how to execute and release value. Regsiter here to learn more !">
    
    
	<!-- OPEN GRAPH META TAG STARTS -->	
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->
    
	<meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
	<META NAME="ROBOTS" CONTENT="INDEX, FOLLOW"></META>
	<link href="../../inc/assets/css/normalize-3.0.2.css" rel="stylesheet" />
	<link href="../../inc/assets/css/bootstrap.min.css" rel="stylesheet" />
	<link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="../../inc/assets/css/main.css" rel="stylesheet" />
	<script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
	<link rel="shortcut icon" type="image/x-icon"href="../../inc/assets/img/favicon.ico">
	<script>
		(function(d, e, j, h, f, c, b) {
			d.GoogleAnalyticsObject = f;
			d[f] = d[f] || function() {
				(d[f].q = d[f].q || []).push(arguments)
			}, d[f].l = 1 * new Date();
			c = e.createElement(j), b = e.getElementsByTagName(j)[0];
			c.async = 1;
			c.src = h;
			b.parentNode.insertBefore(c, b)
		})(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
		ga("create", "UA-100332682-2", "auto");
		ga("send", "pageview");

	</script>
	<!--[if lt IE 9]>
<script src=//html5shiv.googlecode.com/svn/trunk/html5.js></script>
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script>
<![endif]-->

	<script type="text/javascript">
		document.oncontextmenu = new Function("return false");
		document.onselectstart = new Function("return false");
		if (window.sidebar) {
			document.onmousedown = new Function("return false");
			document.onclick = new Function("return true");

			document.oncut = new Function("return false");

			document.oncopy = new Function("return false");


			document.onpaste = new Function("return false");
		}

	</script>

</head>

<body>
	<div class="modal fade" id=cformModal tabindex=-1 role=dialog aria-labelledby=myModalLabel aria-hidden=true>
		<div class=modal-dialog>
			<div class=modal-content>
				<div class=modal-header>
					<button type=button class=close data-dismiss=modal><span aria-hidden=true>&times;</span><span class=sr-only>Close</span></button>
					<h4 class=modal-title id=myModalLabel>Send us your query</h4>
				</div>
				<div class=modal-body>
					<div id=formSuccess class="alert alert-success" role=alert style=display:none>
						<p>
							<strong>Thank You!</strong>&nbsp;Your message has been sent successfully.<br/>
							<small>Someone from our team will respond to your query within 24 hrs.</small>
						</p>
					</div>
					<div class=contact-form-wrapper>
						<div class=contact-form>
							<form id=ir_contactForm role=form method=post action=../../inc/assets/mail/contact_mail.php>
								<div class=form-group>
									<label for=inputName class=sr-only>Your Name</label>
									<input type=text class=form-control id=inputName name=name placeholder=Name* required>
								</div>
								<div class=form-group>
									<label for=inputEmail class=sr-only>Your Email</label>
									<input type=email class=form-control id=inputEmail name=email placeholder=Email* required>
								</div>
								<div class=form-group>
									<label for=inputSubject class=sr-only>Subject Line</label>
									<input type=text class=form-control id=inputSubject name=subject placeholder=Subject* required>
								</div>
								<div class=form-group>
									<label for=inputMessage class=sr-only>Your Message</label>
									<textarea class=form-control name=message rows=5 id=inputMessage placeholder=Message*></textarea>
								</div>
								<div class=checkbox>
									<label>
<input type=checkbox id=inputCheckbox name=newsletter> Sign Me up for Newsletter!
</label>
									<p class="help-block text-small">No Spam mails, We promise!</p>
								</div>
								<button type=button class="btn btn-warning" onclick=$(ir_contactForm).resetForm()>Reset</button>
								<button type=submit name=formSubmit class="btn ibtn-success pull-right">Submit</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php include('../../includes/header.php');?>
	<section class="page-cover_bg">
		<div class="safe_bg page_bg bg_overlay"></div>
		<div class="container">
			<div class="page_center_caption">
				<h1 class="main_title" style="text-transform:none!important">Scaled Agile Framework(SAFe<sup><small style="color:#000">&reg;</small></sup>)</h1>
				<div class="text_center_hr"></div>
				<h2 class="heading_sub_page">Scale Agile SAFely at Enterprise</h2>
			</div>
		</div>
	</section>
	<section class="trianing_list_bg" style="margin:0!important">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
					<div class="training_listcard">
						<div class="row">
							<div class="col-md-5 col-xs-5 img_hover_training">
								<div class="hovereffect_training">
									<img class="img-responsive img_training" src="../../inc/assets/img/safe/safe-team.png" alt="SPC">
									<div class="overlay">
										<a href="../../training/safe-for-teams/">
											<p class="info">View</p>
										</a>
									</div>
								</div>
							</div>
							<div class="col-md-7 col-xs-7">
								<p class="training_topic">
									SAFe&reg; 4.5 for Teams
								</p>
								<p class="training_topic_sub">
									2 Day course 
								</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
					<div class="training_listcard">
						<div class="row">
							<div class="col-md-5 col-xs-5 img_hover_training">
								<div class="hovereffect_training">
									<img class="img-responsive img_training" src="../../inc/assets/img/safe/safe-sasm.png" alt="SPC">
									<div class="overlay">
										<a href="../../training/safe-advanced-scrum-master/">
											<p class="info">View</p>
										</a>
									</div>
								</div>
							</div>
							<div class="col-md-7 col-xs-7">
								<p class="training_topic">
									SAFe&reg; 4.0 Advanced Scrum Master
								</p>
								<p class="training_topic_sub">
									2 Day course 
								</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
					<div class="training_listcard">
						<div class="row">
							<div class="col-md-5 col-xs-5 img_hover_training">
								<div class="hovereffect_training">
									<img class="img-responsive img_training" src="../../inc/assets/img/safe/safe-leadingsafe.png" alt="SPC">
									<div class="overlay">
										<a href="../../training/leading-safe/">
											<p class="info">View</p>
										</a>
									</div>
								</div>
							</div>
							<div class="col-md-7 col-xs-7">
								<p class="training_topic">
									Leading SAFe&reg; 4.5
								</p>
								<p class="training_topic_sub">
									2 Day course 
								</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
					<div class="training_listcard">
						<div class="row">
							<div class="col-md-5 col-xs-5 img_hover_training">
								<div class="hovereffect_training">
									<img class="img-responsive img_training" src="../../inc/assets/img/safe/safe-pmpo.png" alt=SPC>
									<div class="overlay">
										<a href="../../training/safe-product-owner-product-manager/">
											<p class="info">View</p>
										</a>
									</div>
								</div>
							</div>
							<div class="col-md-7 col-xs-7">
								<p class="training_topic">
									SAFe&reg; 4.5 Product Owner/Product Manager
								</p>
								<p class="training_topic_sub">
									2 Day course 
								</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-6 col-xs-12 margin_training_list_media">
					<div class="training_listcard">
						<div class="row">
							<div class="col-md-5 col-xs-5 img_hover_training">
								<div class="hovereffect_training">
									<img class="img-responsive img-training" src="../../inc/assets/img/safe/safe-ssm.png" alt="SPC">
									<div class="overlay">
										<a href="../../training/safe-scrum-master/">
											<p class="info">View</p>
										</a>
									</div>
								</div>
							</div>
							<div class="col-md-7 col-xs-7">
								<p class="training_topic">
									SAFe&reg; 4.0 Scrum Master
								</p>
								<p class="training_topic_sub">
									2 Day course 
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php include('../../includes/footer.php');?>
    
     <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>
    <!--end pure chat-->
    
    
	<script type="text/javascript" src="../../inc/assets/js/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="../../inc/assets/js/bootstrap.min.js"></script>
</body>

</html>
