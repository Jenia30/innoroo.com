<!--Updated On 28-03-2018GA
meta tag updated
-->

<!DOCTYPE html>
<html lang="en">
<head>
    <title>INNOVATION ROOTS | Offerings | Agile Transformation | Agile Transformation Services</title>
    <meta charset="utf-8">
    <meta http-equiv=X-UA-Compatible content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Transform your business to agile by taking the best Agile Transformation courses that start from the Agile Basics to the Advanced Agile.">
    
	<!-- OPEN GRAPH META TAG STARTS -->	
    <meta property='og:title' content='INNOVATION ROOTS' />
    <meta property="og:image" content="http://innovationroots.com/inc/assets/img/agile-transformation/agile-transformation.png" />
    <meta property="og:description" content="Agile Software Development Training, Certification and Consulting Experts" />
    <meta property="og:url" content="www.innoroo.com" />
    <!-- OPEN GRAPH META TAG ENDS -->
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    

     <meta name="author" content="Innovation Roots Softech Pvt. Ltd.">
       <meta name="ROBOTS" content="INDEX, FOLLOW">
       <link href="../../inc/assets/css/normalize-3.0.2.css rel=stylesheet" />
       <link href="../../inc/assets/css/bootstrap.min.css rel=stylesheet" />
	<link type="text/css" rel="stylesheet" href="../../inc/assets/css/newsletter_form.css" />
       <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
       <!-- Icon Fonts -->
       <link rel="stylesheet href=https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../../inc/assets/css/main.css" rel=stylesheet />
       <!-- <link href=inc/assets/css/010218-main.css rel=stylesheet /> -->
       <script src="../../inc/assets/js/modernizr.custom.83079.js"></script>
       <link rel="shortcut icon" type="image/x-icon" href="../../inc/assets/img/favicon.ico">

    <script>
        (function(d, e, j, h, f, c, b) {
            d.GoogleAnalyticsObject = f;
            d[f] = d[f] || function() {
                (d[f].q = d[f].q || []).push(arguments)
            }, d[f].l = 1 * new Date();
            c = e.createElement(j), b = e.getElementsByTagName(j)[0];
            c.async = 1;
            c.src = h;
            b.parentNode.insertBefore(c, b)
        })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
        ga("create", "UA-100332682-2", "auto");
        ga("send", "pageview");

    </script>
        <script type="text/javascript">
        document.oncontextmenu = new Function("return false");
        document.onselectstart = new Function("return false");
        if (window.sidebar) {
            document.onmousedown = new Function("return false");
            document.onclick = new Function("return true");

            document.oncut = new Function("return false");

            document.oncopy = new Function("return false");


            document.onpaste = new Function("return false");
        }

    </script>
    
    
</head>
<body>
    
        <?php include('../../includes/header.php');?>
        

        <!--banner image section ends here-->
        <section class="grey_bg agile-cover_bg center" style="background-color: #d5d5d5">
            <div class="container center-container">
                <div class="col-sm-12 col-md-12 col-xs-12">
                    <div class="col-md-6 col-sm-7 col-xs-12 center-text">
                        <div class="agile_main_div" >
                            <h1 class="main_title">Enterprise Transformation </h1>
                            <h2 class="heading_sub_page">Unleash the potential within, Move to new horizons and change the paradigm. </h2>

                        </div>

                    </div>
                    <div class="col-md-6 col-sm-5 col-xs-12 f-img-section">
                        <img src="../../inc/assets/img/agile-transformation/agile-transformation.png" class="img-responsive agile_img_main" alt="Enterprise Transformation image">
                    </div>
                </div>
            </div>
        </section>
        <!--banner image section ends here-->

        <!--listing section starts here-->
        <section class="section-listing-page" style="margin:0px ; background-color: #fff">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-sm-6 col-xs-12 listing_training_page">
                        <div class="training-listcard-section">
                            <div class="row">
                                <div class="col-md-5 col-xs-5 ag-training">
                                    <div class="hovereffect_training">
                                        <img src="../../inc/assets/img/agile-transformation/agile-overview.png" class="img-responsive img-training-list" alt="agile basics image">
                                        <div class="overlay">
                                            <a href="../../training/agile-basics-training/">
                                                <p class="info">View</p>
                                            </a>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-md-7 col-xs-7 detail_sec">
                                    <p class="listing-training-topic">Agile Basics</p>
                                    <p class="listing-sub-training-topic">Overview of Agile methods</p>
                                    <p class="listing-sub-training-topic">Half-Day Course</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12 listing_training_page">
                        <div class="training-listcard-section">
                            <div class="row">
                                <div class="col-md-5 col-xs-5 ag-training" style="">
                                    <div class="hovereffect_training">
                                        <img src="../../inc/assets/img/agile-transformation/agile-essentials.png" class="img-responsive img-training-list" alt="agile essentials">
                                        <div class="overlay">
                                            <a href="../../training/agile-essentials-training/">
                                                <p class="info">View</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xs-7 detail_sec">
                                    <p class="listing-training-topic">Agile Essentials</p>
                                    <p class="listing-sub-training-topic">Introduction to Agile methods</p>
                                    <p class="listing-sub-training-topic">1 Day Course</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12 listing_training_page">
                        <div class="training-listcard-section">
                            <div class="row">
                                <div class="col-md-5 col-xs-5 ag-training">
                                    <div class="hovereffect_training">
                                        <img src="../../inc/assets/img/agile-transformation/agile-foundation.png" class="img-responsive img-training-list" alt="agile foundation image">
                                        <div class="overlay">
                                            <a href="../../training/agile-foundation-training/">
                                                <p class="info">View</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-xs-7 detail_sec">
                                    <p class="listing-training-topic">Agile Foundation</p>
                                    <p class="listing-sub-training-topic">Hands on Agile methods</p>
                                    <p class="listing-sub-training-topic">2 Days Course</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12 listing_training_page">
                        <div class="training-listcard-section">
                            <div class="row">
                                <div class="col-md-5 col-xs-5 ag-training">
                                    <div class="image-hover-effect">
                                        <img src="../../inc/assets/img/agile-transformation/agile-advance.png" class="img-responsive img-training-list" alt="agile advanced image">
                                        
                                    </div>
                                </div>
                                <div class="col-md-7 col-xs-7 detail_sec">
                                    <p class="listing-training-topic">Advanced Agile</p>
                                    <p class="listing-sub-training-topic">Expertise on Agile methods</p>
                                    <p class="listing-sub-training-topic">3 Days Course</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>
        <!--listing section ends here-->

        <?php include('../../includes/footer.php');?> 
    
     <!--start pure chat-->
    <script type='text/javascript' data-cfasync='false'>
			window.purechatApi = {
				l: [],
				t: [],
				on: function() {
					this.l.push(arguments);
				}
			};
			(function() {
				var done = false;
				var script = document.createElement('script');
				script.async = true;
				script.type = 'text/javascript';
				script.src = 'https://app.purechat.com/VisitorWidget/WidgetScript';
				document.getElementsByTagName('HEAD').item(0).appendChild(script);
				script.onreadystatechange = script.onload = function(e) {
					if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
						var w = new PCWidget({
							c: '7d592219-43cf-498a-98c8-a1ef1d5e678f',
							f: true
						});
						done = true;
					}
				};
			})();

		</script>
    <!--end pure chat-->
     
       <script type=text/javascript src=../../inc/assets/js/jquery-1.11.1.min.js></script>
       <script type=text/javascript src=../../inc/assets/js/bootstrap.min.js></script>
</body>
</html>